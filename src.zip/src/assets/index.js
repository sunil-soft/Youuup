export const path = "./Home/";
export const path2 = "./reg/";


export const newIcon = {
   about_us: require(path + "aboutus.png"),
   Edit: require(path + "edit.png"),
   Blankradiobutton: require(path + "blankradiobutton.png"),
   radioButton: require(path + "radiobutton.png"),
   Tickcheckbox: require(path + "Tickcheckbox.png"),
   Checkbox: require(path2 + "Checkbox.png"),
   checkedcheck: require(path2 + "checkedcheck.png"),
};
