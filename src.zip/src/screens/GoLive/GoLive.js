import AsyncStorage from '@react-native-async-storage/async-storage';
import axios from "axios";
import { useEffect, useRef, useState } from 'react';

import { Dimensions, Image, ImageBackground, PermissionsAndroid, StatusBar, StyleSheet, TouchableOpacity, View } from 'react-native';
import RtcEngine, {
  ChannelProfile, ClientRole, RtcLocalView, VideoMirrorMode
} from 'react-native-agora';
import { useSelector } from "react-redux";
import { Header } from "../../components/Header";
import { getUser } from "../../selectors/UserSelectors";

const APIBASEURL='https://youuup.es/mobile-api/'


// import 'react-native-get-random-values';
//import requestCameraAndAudioPermission from './Permission';

const SCREEN_HEIGHT = Dimensions.get('window').height;
const SCREEN_WIDTH = Dimensions.get('window').width;

//export default function livevideoNew( props ) {
 export default   Golive = (props) => {
   const { navigation, route } = props;
   const user = useSelector(getUser);
  // const { type } = route.params;
 //  const isBroadcaster = route.params.type === 'create';
   const isBroadcaster ='create';

  //const isBroadcaster = 'create';
  const channelId = user?.userinfo?.user.name;

  const [joined, setJoined] = useState(false);
  const [isBroadcastersts, setisBroadcaster] = useState('');
  const [peerIds, setpeerids] = useState([]);
  const [callmutests, setcallmutestatus] = useState(false);

  

  const AgoraEngine = useRef();

  useEffect(() => {
       if (Platform.OS === 'android') getPermission();
       AsyncStorage.getItem('auth_token').then(async (datatoken) => { 
        console.log(datatoken)
       axios({
         url: APIBASEURL+"user/generate-live-token",
         method: "POST",
         data: {"channelName": user?.userinfo?.user.name, 'uid':0},
         headers: {
           Accept: "application/json",
           Authorization:"Bearer "+datatoken,
         },
       })
       .then((response) => {
       // console.log('response3223', response.data?.token)
       // setTimeout(() => {

       init().then(() =>
       {
        //  AgoraEngine.current.enableVideo(),
        //  AgoraEngine.current.startPreview(),
        //AgoraEngine.current.joinChannel(response.data?.token, channelId, null,0 )
       // setTimeout(() => {
         //  AgoraEngine.current.enableLocalVideo(true),
         // AgoraEngine.current.startPreview(),
          AgoraEngine.current.joinChannelWithUserAccount(response.data?.token,channelId,"16",null )
         // AgoraEngine.current.enableLocalVideo(true)
       // }, 500);
       }

        
  
      // AgoraEngine.current.joinChannel('0066e80f1084211439492a257f8f4b41539IADdBrbVkds0nKX6t3VqDJZIgG68Kgm7QIQeo1iBaJiLa1iNuxPUgD5IIgCMSZgLfR8tZAQAAQAN3CtkAgAN3CtkAwAN3CtkBAAN3Ctk', channelId, null, 0),
       );
     // }, 500)

        })
       .catch(function (error) {
      //   init().then(() =>
      //   setTimeout(() => {
      //    AgoraEngine.current.joinChannel('0066e80f1084211439492a257f8f4b41539IABYGl1ZZj46aBmsQH690cT8XHpmjKYHoJ+5eilVS9ExiAx+f9gAAAAAIgAcTzssVVAtZAQAAQDlDCxkAgDlDCxkAwDlDCxkBADlDCxk', channelId, null, 0)
   
      //   }, 500)
      //  // AgoraEngine.current.joinChannel('0066e80f1084211439492a257f8f4b41539IADdBrbVkds0nKX6t3VqDJZIgG68Kgm7QIQeo1iBaJiLa1iNuxPUgD5IIgCMSZgLfR8tZAQAAQAN3CtkAgAN3CtkAwAN3CtkBAAN3Ctk', channelId, null, 0),
      //   );
         console.log("error11", error);
       });

      });
   
    const uid = isBroadcaster ? 1 : 0;
   // init()

    return () => {
      AgoraEngine.current?.leaveChannel();

      AsyncStorage.getItem('auth_token').then(async (datatoken) => { 
        axios({
          url: APIBASEURL+"user/end-live-stream",
          method: "POST",
          data: {"channelName":user?.userinfo?.user.name},
          headers: {
            Accept: "application/json",
            Authorization:"Bearer "+datatoken,
          },
        })
        .then((response) => {
          console.log('enduser',response)
    
        })
        .catch(function (error) {
    
        });
 
       });
     // AgoraEngine.current.destroy();
    };
  }, []);

  const endcall = async() => 
  {
    try {
      AgoraEngine.current?.leaveChannel();
      props.navigation.goBack()
     // setRemoteUid(0);
    //  setIsJoined(false);
      console.log('You left the channel');
  } catch (e) {
      console.log(e);
  }
  }

  
  const callmute = async(status) => 
  {
    try {
      AgoraEngine.current?.enableLocalAudio(!status);
      setcallmutestatus(!status)
    
  } catch (e) {
      console.log(e);
  }
  }
  const init = async () => {
    AgoraEngine.current = await RtcEngine.create('6e80f1084211439492a257f8f4b41539');
    AgoraEngine.current.enableVideo();
    AgoraEngine.current.setChannelProfile(ChannelProfile.LiveBroadcasting);
    if (isBroadcaster)
      AgoraEngine.current?.startPreview();
      AgoraEngine.current.setClientRole(ClientRole.Broadcaster);
      AgoraEngine.current.enableVideo();
      AgoraEngine.current.enableLocalAudio(false);
      
    AgoraEngine.current.addListener(
      'JoinChannelSuccess',
      (channelId, uid, elapsed) => {
        console.log('JoinChannelSuccess', channelId, uid, elapsed);
        setJoined(true);
      },
    );
    AgoraEngine.current.addListener(
        'UserJoined',
        (uid, elapsed) => {
          console.log('UserJoined', uid, elapsed);
         
        setpeerids(peerIds => [...peerIds,uid]);
    
         // setJoined(true);
        },
     );
  };
 
  const getPermission = async () => {
    if (Platform.OS === 'android') {
        await PermissionsAndroid.requestMultiple([
            PermissionsAndroid.PERMISSIONS.RECORD_AUDIO,
            PermissionsAndroid.PERMISSIONS.CAMERA,
        ]);
    }
};
  const onSwitchCamera = () => AgoraEngine.current.switchCamera();

  return (
    <ImageBackground
      style={{ flex: 1,  }}
      resizeMode={"stretch"}
      backgroundColor={'black'}
      source={require("../../assets/images/editprofileback.png")}
    >
    
      <StatusBar translucent backgroundColor="transparent" />
      <Header back={true} {...props} title='Live' />
        
      {/* {!joined ? (
        <>
          <ActivityIndicator
            size={60}
            color="#222"
            style={styles.activityIndicator}
          />
          <Text style={styles.loadingText}>
            {'Joining Stream, Please Wait'}
          </Text>
        </>
      ) : ( */}
        <>
          {isBroadcaster && ( 
            <>
           <RtcLocalView.SurfaceView
               style={styles.fullscreen}
               channelId={channelId}
               uid={user?.userinfo?.user.id}
               mirrorMode={VideoMirrorMode.Enabled} 
              
            />
            </>
         ) }
          {/* <Text style={{color:"white"}}>{peerIds.length}Joined</Text> */}
        <View style={{flexDirection:'row',justifyContent:'space-around'}}>
          <TouchableOpacity style={styles.buttonstyle} onPress={()=>callmute(callmutests)}>
              <Image style={{height:60,width:60}} source={!callmutests?require("../../assets/Home/New/unmute.png"):require("../../assets/Home/New/mute.png")} />
          </TouchableOpacity> 
           <TouchableOpacity style={styles.buttonstyle} onPress={()=>endcall()}>
              <Image style={{height:60,width:60}} source={require("../../assets/Home/New/callcancel.png")} />

          </TouchableOpacity> 
        </View>
        </>
    </ImageBackground>
  );
}

const styles = StyleSheet.create({
  loadingText: {
    fontSize: 18,
    color: '#222',
  },
  fullscreen: {
    width: SCREEN_WIDTH,
    height: SCREEN_HEIGHT+40,
  },
  buttonstyle: {
    position:'relative',
    zIndex:100000,
    bottom:70,
  },
});