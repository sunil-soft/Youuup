// import AsyncStorage from '@react-native-async-storage/async-storage';
import { FONTS } from "@/theme/fonts";
import { useEffect, useState } from "react";
import { ActivityIndicator, FlatList, Image, ImageBackground, StatusBar, Text, TouchableOpacity, View } from "react-native";
import { KeyboardAwareScrollView } from 'react-native-keyboard-aware-scroll-view';

import { WebView } from 'react-native-webview';
import { useDispatch, useSelector } from "react-redux";
import { Header } from "../../components/Header";
import { getUser } from "../../selectors/UserSelectors";
// import { FONTS } from "../../theme/fonts";
import { faq } from "../../actions/UserActions";
import { styles } from "./FAQStyles";

const FAQ = (props) => {
  const dispatch = useDispatch();
  const { navigation, route } = props;
  const [animating, setAnimating] = useState(false);
  const [showanswer, setshowanswer] = useState('');
  
  const user = useSelector(getUser);

  useEffect(() => {
    dispatch(faq());

    }, []);
 
  return (
    <ImageBackground
      style={{ flex: 1,  }}
      resizeMode={"stretch"}
      backgroundColor={'black'}
      source={require("../../assets/images/editprofileback.png")}
    >
    
      <StatusBar translucent backgroundColor="transparent" />
      <Header back={true} {...props} title='Preguntas' />
     <KeyboardAwareScrollView>
      <View style={styles.mainContainer}>
      <WebView source={{ uri: 'https://reactnative.dev/' }} style={{ flex: 1 }} />
      <FlatList
        data={user && user?.Faq}
         renderItem={({item}) => 
         <View style={{marginTop:10, marginLeft:20,marginRight:7,backgroundColor:"white",padding:10,borderRadius:10,}}>
         <View style={{flexDirection:'row',justifyContent:"space-between",alignItems:'center', }}>
          <Text style={{color:'black', fontFamily:FONTS.PoppinsMedium,paddingLeft:5}}>
          {item.question}
          </Text>
          {showanswer==item.id ?
          <TouchableOpacity onPress={()=>setshowanswer('')}>
           <Image
           //  style={{width:10,height:40}}
            source={require("../../assets/reg/uparrow.png")}
             />
            </TouchableOpacity>
            :
            <TouchableOpacity onPress={()=>setshowanswer(item.id)}>
            <Image
            //  style={{width:10,height:40}}
             source={require("../../assets/reg/downarrow.png")}
              />
             </TouchableOpacity>
         }
         </View>
         {showanswer==item.id &&
         <View style={{padding:10}}>
           <Text style={{color:"black"}}> {item.ans}</Text>
         </View>
         }
       </View>
        }
      />   
      
      </View>
          {animating == true && (
           <ActivityIndicator
            animating
           color={'white'}
           size="large"
           style={styles.activityIndicator}
           />
           )} 
      </KeyboardAwareScrollView>
   </ImageBackground>
  );
};

export default FAQ;
