// import AsyncStorage from '@react-native-async-storage/async-storage';
import { FONTS } from "@/theme/fonts";
import { useEffect, useState } from "react";
import { ActivityIndicator, Alert, Image, ImageBackground, Linking, StatusBar, Text, TouchableOpacity, View } from "react-native";
import { KeyboardAwareScrollView } from 'react-native-keyboard-aware-scroll-view';
import { NAVIGATION } from "../../constants";

import { useDispatch, useSelector } from "react-redux";
import { Header } from "../../components/Header";
import { getUser } from "../../selectors/UserSelectors";
// import { FONTS } from "../../theme/fonts";
//import { aboutus } from "../../actions/UserActions";
import { logout } from "../../actions/UserActions";
import { styles } from "./AboutUsStyles";

const AboutUs = (props) => {
  const dispatch = useDispatch();
  const { navigation, route } = props;
  const [animating, setAnimating] = useState(false);
  const user = useSelector(getUser);

  useEffect(() => {
   // dispatch(aboutus());
   // console.log('user22',user.userinfo?.user?.user_type_id)
   

    }, []);
    const logoutUser = () => {
      Alert.alert('', '¿Quieres cerrar sesión?', [
     //   { text: 'OK', onPress: () => dispatch(logout()) },
        { text: 'Sí', onPress: () => dispatch(logout())   },
        {
          text: 'Cancelar',
          onPress: () => console.log('Cancel Pressed'),
          style: 'cancel',
        },
      ]);
    };
  return (
    <ImageBackground
      style={{ flex: 1,  }}
      resizeMode={"stretch"}
      backgroundColor={'black'}
      source={require("../../assets/images/editprofileback.png")}
    >
    
      <StatusBar translucent backgroundColor="transparent" />
      <Header back={true} {...props} title='Información' />
      <KeyboardAwareScrollView>
      <View style={styles.mainContainer}>
      <View style={{marginTop:100,marginLeft:20,marginRight:7}}>
      <Text style={{color:'white',fontFamily:FONTS.PoppinsRegular}}>
      {/* {user.Aboutus?.about_us} */}
      </Text>
    <View style={{marginTop:10, flexDirection:"row",marginLeft:15,marginRight:15, alignContent:'center',alignItems:'center'}}>
     
     <View style={{width:'70%'}}>
      <TouchableOpacity  
        onPress={()=>props.navigation.navigate(NAVIGATION.ContactUs)}
        >
      <Text style={{color:'white',fontSize:16,fontWeight:"600",fontFamily:FONTS.PoppinsRegular}}>Contacto y sugerencias</Text>
      </TouchableOpacity>
      </View>
      <View style={{width:'30%',justifyContent:"center",alignItems:'center',alignContent:'center'}}>
       <TouchableOpacity 
        onPress={()=>props.navigation.navigate(NAVIGATION.ContactUs)}
        style={{width:120, padding:8,paddingLeft:10,paddingRight:10,justifyContent:'center',alignContent:"center",alignItems:'flex-end'}}>
        <Image style={{tintColor:'white'}} source={require("../../assets/images/backbutton.png")} />
       </TouchableOpacity>
      </View>
     </View>
     <View style={{marginTop:10, flexDirection:"row",marginLeft:15,marginRight:15, alignContent:'center',alignItems:'center'}}>
      <View style={{width:'70%'}}>
       <TouchableOpacity       
         onPress={()=>props.navigation.navigate(NAVIGATION.Privacy,{pageshow:1})}
       >
       <Text style={{color:'white',fontSize:16,fontWeight:"600",fontFamily:FONTS.PoppinsRegular}}>Política de privacidad</Text>
       </TouchableOpacity>
      </View>
      <View style={{width:'30%',justifyContent:"center",alignItems:'center',alignContent:'center'}}>
       <TouchableOpacity 
         onPress={()=>props.navigation.navigate(NAVIGATION.Privacy,{pageshow:1})}
         style={{width:120, padding:8,paddingLeft:10,paddingRight:10,justifyContent:'center',alignContent:"center",alignItems:'flex-end'}}>
        <Image style={{tintColor:'white'}} source={require("../../assets/images/backbutton.png")} />
       </TouchableOpacity>
     </View>
     </View>

     <View style={{marginTop:10, flexDirection:"row",marginLeft:15,marginRight:15, alignContent:'center',alignItems:'center'}}>
      <View style={{width:'70%'}}>
       <TouchableOpacity
        onPress={()=>props.navigation.navigate(NAVIGATION.Terms)}
        > 
       <Text style={{color:'white',fontSize:16,fontWeight:"600",fontFamily:FONTS.PoppinsRegular}}>Condiciones de uso</Text>
       </TouchableOpacity>
      </View>
      <View style={{width:'30%',justifyContent:"center",alignItems:'center',alignContent:'center'}}>
       <TouchableOpacity 
        onPress={()=>props.navigation.navigate(NAVIGATION.Terms)}
        style={{width:120, padding:8,paddingLeft:10,paddingRight:10,justifyContent:'center',alignContent:"center",alignItems:'flex-end'}}>
        <Image style={{tintColor:'white'}} source={require("../../assets/images/backbutton.png")} />
       </TouchableOpacity>
     </View>
     </View>

     <View style={{marginTop:10, flexDirection:"row",marginLeft:15,marginRight:15, alignContent:'center',alignItems:'center'}}>
      <View style={{width:'70%'}}>
       <TouchableOpacity 
        onPress={()=>props.navigation.navigate(NAVIGATION.Privacy,{pageshow:2})}
       >
       <Text style={{color:'white',fontSize:16,fontWeight:"600",fontFamily:FONTS.PoppinsRegular}}>Política de cookies</Text>
       </TouchableOpacity>
      </View>
      <View style={{width:'30%',justifyContent:"center",alignItems:'center',alignContent:'center'}}>
       <TouchableOpacity 
        onPress={()=>props.navigation.navigate(NAVIGATION.Privacy,{pageshow:2})}
        style={{width:120, padding:8,paddingLeft:10,paddingRight:10,justifyContent:'center',alignContent:"center",alignItems:'flex-end'}}>
        <Image style={{tintColor:'white'}} source={require("../../assets/images/backbutton.png")} />
       </TouchableOpacity>
     </View>
     </View>

     <View style={{marginTop:10, flexDirection:"row",marginLeft:15,marginRight:15, alignContent:'center',alignItems:'center'}}>
      <View style={{width:'70%'}}>
       <TouchableOpacity 
        onPress={()=>props.navigation.navigate(NAVIGATION.Socialinfo)}
       >
       <Text style={{color:'white',fontSize:16,fontWeight:"600",fontFamily:FONTS.PoppinsRegular}}>Información Social y Fiscal</Text>
       </TouchableOpacity>
      </View>
      <View style={{width:'30%',justifyContent:"center",alignItems:'center',alignContent:'center'}}>
       <TouchableOpacity 
        onPress={()=>props.navigation.navigate(NAVIGATION.Socialinfo)}
        style={{width:120, padding:8,paddingLeft:10,paddingRight:10,justifyContent:'center',alignContent:"center",alignItems:'flex-end'}}>
        <Image style={{tintColor:'white'}} source={require("../../assets/images/backbutton.png")} />
       </TouchableOpacity>
     </View>
     </View>

   
     <View style={{marginTop:10, flexDirection:"row",marginLeft:15,marginRight:15, alignContent:'center',alignItems:'center'}}>
      <View style={{width:'70%'}}>
       <TouchableOpacity
       onPress={()=>props.navigation.navigate(NAVIGATION.AboutDetail)}
       >
       <Text style={{color:'white',fontSize:16,fontWeight:"600",fontFamily:FONTS.PoppinsRegular}}>Sobre nosotros</Text>
       </TouchableOpacity>
      </View>
      <View style={{width:'30%',justifyContent:"center",alignItems:'center',alignContent:'center'}}>
       <TouchableOpacity 
       onPress={()=>props.navigation.navigate(NAVIGATION.AboutDetail)}
       style={{width:120, padding:8,paddingLeft:10,paddingRight:10,justifyContent:'center',alignContent:"center",alignItems:'flex-end'}}>
        <Image style={{tintColor:'white'}} source={require("../../assets/images/backbutton.png")} />
       </TouchableOpacity>
     </View>
     </View>
     {user.userinfo?.user?.user_type_id==3 &&
     <View style={{marginTop:10, flexDirection:"row",marginLeft:15,marginRight:15, alignContent:'center',alignItems:'center'}}>
      <View style={{width:'70%'}}>
       <TouchableOpacity onPress={()=>props.navigation.navigate(NAVIGATION.Membership)}>
       <Text style={{color:'white',fontSize:16,fontWeight:"600",fontFamily:FONTS.PoppinsRegular}}>Membresia</Text>
       </TouchableOpacity>
      </View>
      <View style={{width:'30%',justifyContent:"center",alignItems:'center',alignContent:'center'}}>
       <TouchableOpacity 
        onPress={()=>props.navigation.navigate(NAVIGATION.Membership)}    
        style={{width:120, padding:8,paddingLeft:10,paddingRight:10,justifyContent:'center',alignContent:"center",alignItems:'flex-end'}}>
        <Image style={{tintColor:'white'}} source={require("../../assets/images/backbutton.png")} />
       </TouchableOpacity>
     </View>
     </View>
  }

     <View style={{marginTop:10, flexDirection:"row",marginLeft:15,marginRight:15, alignContent:'center',alignItems:'center'}}>
      <View style={{width:'70%'}}>
       <TouchableOpacity 
       onPress={()=>Linking.openURL('https://youuup.com/#contact')}
       //onPress={()=>props.navigation.navigate(NAVIGATION.FAQ)}
       >
       <Text style={{color:'white',fontSize:16,fontWeight:"600",fontFamily:FONTS.PoppinsRegular}}>Preguntas</Text>
       </TouchableOpacity>
      </View>
      <View style={{width:'30%',justifyContent:"center",alignItems:'center',alignContent:'center'}}>
       <TouchableOpacity 
     //  onPress={()=>props.navigation.navigate(NAVIGATION.FAQ)}
       onPress={()=>Linking.openURL('https://youuup.com/#contact')}
        style={{width:120, padding:8,paddingLeft:10,paddingRight:10,justifyContent:'center',alignContent:"center",alignItems:'flex-end'}}>
        <Image style={{tintColor:'white'}} source={require("../../assets/images/backbutton.png")} />
       </TouchableOpacity>
     </View>
     </View>

     <View style={{marginTop:10, flexDirection:"row",marginLeft:15,marginRight:15, alignContent:'center',alignItems:'center'}}>
      <View style={{width:'70%'}}>
       <TouchableOpacity 
      // onPress={()=>Linking.openURL('https://youuup.com/#contact')}
       onPress={()=>props.navigation.navigate(NAVIGATION.Tutorial)}
       >
       <Text style={{color:'white',fontSize:16,fontWeight:"600",fontFamily:FONTS.PoppinsRegular}}>Tutorial</Text>
       </TouchableOpacity>
      </View>
      <View style={{width:'30%',justifyContent:"center",alignItems:'center',alignContent:'center'}}>
       <TouchableOpacity 
        onPress={()=>props.navigation.navigate(NAVIGATION.Tutorial)}
        style={{width:120, padding:8,paddingLeft:10,paddingRight:10,justifyContent:'center',alignContent:"center",alignItems:'flex-end'}}>
        <Image style={{tintColor:'white'}} source={require("../../assets/images/backbutton.png")} />
       </TouchableOpacity>
     </View>
     </View>

     {/* <View style={{marginTop:50, flexDirection:"row",marginLeft:15,marginRight:15, alignContent:'center',alignItems:'center'}}>
      <View style={{width:'70%'}}>
       <TouchableOpacity        
          onPress={() =>logoutUser()}
            >
       <Text style={{color:'white',fontSize:16,fontWeight:"600",fontFamily:FONTS.PoppinsRegular}}>Salir</Text>
       </TouchableOpacity>
      </View>
      <View style={{width:'30%',justifyContent:"center",alignItems:'center',alignContent:'center'}}>
       <TouchableOpacity 
        onPress={() =>logoutUser()}   
       style={{width:120, padding:8,paddingLeft:10,paddingRight:10,justifyContent:'center',alignContent:"center",alignItems:'flex-end'}}>
        <Image style={{tintColor:'white'}} source={require("../../assets/images/backbutton.png")} />
       </TouchableOpacity>
     </View>
     </View> */}


      </View>
      </View>
          {animating == true && (
           <ActivityIndicator
            animating
           color={'white'}
           size="large"
           style={styles.activityIndicator}
           />
           )} 
           </KeyboardAwareScrollView>
   </ImageBackground>
  );
};

export default AboutUs;
