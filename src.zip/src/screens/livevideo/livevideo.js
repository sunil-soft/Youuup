// import AsyncStorage from '@react-native-async-storage/async-storage';
import { Component } from 'react';
import { PermissionsAndroid, Platform, ScrollView, Text, TouchableOpacity, View } from 'react-native';
// Import the RtcEngine class and view rendering components into your project.
import RtcEngine, { ChannelProfile, ClientRole, RtcLocalView, RtcRemoteView, VideoRenderMode } from 'react-native-agora';
// Import the UI styles.
//import styles from './components/Style'
import { styles } from "./livevideoStyles";
const requestCameraAndAudioPermission = async () =>{
    try {
        const granted = await PermissionsAndroid.requestMultiple([
            PermissionsAndroid.PERMISSIONS.CAMERA,
            PermissionsAndroid.PERMISSIONS.RECORD_AUDIO,
        ])
        if (
            granted['android.permission.RECORD_AUDIO'] === PermissionsAndroid.RESULTS.GRANTED
            && granted['android.permission.CAMERA'] === PermissionsAndroid.RESULTS.GRANTED
        ) {
            console.log('You can use the cameras & mic')
        } else {
            console.log('Permission denied')
        }
    } catch (err) {
        console.warn(err)
    }
}



// const livevideo = (props) => {
//   const dispatch = useDispatch();
//   const { navigation, route } = props;
//   const [animating, setAnimating] = useState(false);
//   const [showanswer, setshowanswer] = useState('');
//   const user = useSelector(getUser);
//   useEffect(() => {
//     //dispatch(faq());
// //        const profile = {
// //         appID : 1506456192,
// //         scenario : 0
// //         };
        
// //         ZegoExpressEngine.createEngineWithProfile(profile)

// //         let roomConfig = {};
// // roomConfig.token = "04AAAAAGQkLHIAEDN6bGF4dm1tYWJyMjMwYWIAoNkfz5eEqbvkNZsGiIcRrffKUkAU9NK7bCt/yGW5Bw2mncsdC1Ez+71PbL6/3csSbh9Kquqy+wm7kYNtmVh3552H0BwdsCZm0vKwWfBbGAasawiiJngYPAR12MZ0e/QPkacEgp5Z3RZq/V+BdLxOVFWDv+6uQ39IHyfXBYbGYBwx2cG7I9LuuJdoapZljzyKaKK5BTQ9bmnmTQhikswOMZ4=";
// // // log in to a room
// // ZegoExpressEngine.instance().loginRoom('room1', {'userID': '1', 'userName': 'user1'}, roomConfig);
//    getPermission()
//     }, []);
//     const agoraEngineRef = useRef<IRtcEngine>(1) // Agora engine instance
//     const [isJoined, setIsJoined] = useState(false) // Indicates if the local user has joined the channel
//     const [isHost, setIsHost] = useState(true); // Client role
//     const [remoteUid, setRemoteUid] = useState(0) // Uid of the remote user
//     const [message, setMessage] = useState(''); // Message to the user


//     function showMessage(msg: string) {
//         setMessage(msg);
//     }
//     const setupVideoSDKEngine = async () => {
//       try {
//       // use the helper function to get permissions
//       if (Platform.OS === 'android') { await getPermission()};
//       agoraEngineRef.current = createAgoraRtcEngine();
//       const agoraEngine = agoraEngineRef.current;
//       agoraEngine.registerEventHandler({
//           onJoinChannelSuccess: () => {
//               showMessage('Successfully joined the channel ' + channelName);
//               setIsJoined(true);
//           },
//           onUserJoined: (_connection, Uid) => {
//               showMessage('Remote user joined with uid ' + Uid);
//               setRemoteUid(Uid);
//           },
//           onUserOffline: (_connection, Uid) => {
//               showMessage('Remote user left the channel. uid: ' + Uid);
//               setRemoteUid(0);
//           },
//       });
//       agoraEngine.initialize({
//           appId: appId,
//           channelProfile: ChannelProfileType.ChannelProfileLiveBroadcasting,
//       });
//       agoraEngine.enableVideo();
//       } catch (e) {
//           console.log(e);
//       }
//    };
//     const getPermission = async () => {
//       if (Platform.OS === 'android') {
//           await PermissionsAndroid.requestMultiple([
//               PermissionsAndroid.PERMISSIONS.RECORD_AUDIO,
//               PermissionsAndroid.PERMISSIONS.CAMERA,
//           ]);
//       }
//   };
//   const join = async () => {
    
//     if (isJoined) {
//         return;
//     }
//     try {
//         agoraEngineRef.current?.setChannelProfile(
//             ChannelProfileType.ChannelProfileLiveBroadcasting,
//         );
//         if (isHost) {
//             agoraEngineRef.current?.startPreview();
//             agoraEngineRef.current?.joinChannel(token, channelName, uid, {
//                 clientRoleType: ClientRoleType.ClientRoleBroadcaster});
//         } else {
//           alert(isJoined)
//             agoraEngineRef.current?.joinChannel(token, channelName, uid, {
//                 clientRoleType: ClientRoleType.ClientRoleAudience});
//         }
//     } catch (e) {
//         console.log('e',e);
//     }
// };
// const leave = () => {
//   try {
//       agoraEngineRef.current?.leaveChannel();
//       setRemoteUid(0);
//       setIsJoined(false);
//       showMessage('You left the channel');
//   } catch (e) {
//       console.log(e);
//   }
// };
//   return (
//     <SafeAreaView style={styles.main}>

// {/* <ZegoUIKitPrebuiltLiveStreaming
//                 appID={1506456192}
//                 appSign={1506456192}
//                 userID={1}
//                 userName={'test'}
//                 liveID={'112'}

//                 config={{
//                     ...HOST_DEFAULT_CONFIG,
//                     onLeaveLiveStreaming: () => { alert('leave') }
//                 }}
//             /> */}
//     <Text style={styles.head}>
//         Agora Interactive Live Streaming Quickstart
//     </Text>
//     <View style={styles.btnContainer}>
//         <Text onPress={join} style={styles.button}>
//             Join
//         </Text>
//         <Text onPress={leave} style={styles.button}>
//             Leave
//         </Text>
//     </View>
//     <View style={styles.btnContainer}>
//         <Text>Audience</Text>
//         <Switch
//             onValueChange={switchValue => {
//                 setIsHost(switchValue);
//                 if (isJoined) {
//                 leave();
//                 }
//             }}
//             value={isHost}
//         />
//         <Text>Host</Text>
//     </View>
//   <ScrollView
//         style={styles.scroll}
//         contentContainerStyle={styles.scrollContainer}>
//         {isJoined && isHost ? (
//         <React.Fragment key={0}>
//             <RtcSurfaceView canvas={{uid: 0}} style={styles.videoView} />
//             <Text>Local user uid: {uid}</Text>
//         </React.Fragment>
//         ) : (
//             <Text>{isHost ? 'Join a channel' : ''}</Text>
//         )}
//         {isJoined && !isHost && remoteUid !== 0 ? (
//             <React.Fragment key={remoteUid}>
//                 <RtcSurfaceView
//                     canvas={{uid: remoteUid}} style={styles.videoView} />
//                 <Text>Remote user uid: {remoteUid}</Text>
//             </React.Fragment>
//         ) : (
//             <Text>{isJoined && !isHost ? 'Waiting for a remote user to join' : ''}</Text>
//         )}
//         <Text style={styles.info}>{message}</Text>
//     </ScrollView>
// </SafeAreaView>
//   );
// };

// export default livevideo;

// Define a Props interface.
interface Props {
}

// Define a State interface.
interface State {
    appId: string,
    channelName: string,
    token: string,
    joinSucceed: boolean,
    peerIds: number[],
}

// Create an App component, which extends the properties of the Pros and State interfaces.
export default class livevideo extends Component<Props, State> {
     _engine= RtcEngine
    // _engine= RtcEngine.instance()
    // Add a constructor，and initialize this.state. You need:
    // Replace yourAppId with the App ID of your Agora project.
    // Replace yourChannel with the channel name that you want to join.
    // Replace yourToken with the token that you generated using the App ID and channel name above.
    constructor(props) {
        super(props)
        this.state = {
            appId: '6e80f1084211439492a257f8f4b41539',
            channelName: 'test',
            token: '007eJxTYCjXc3Q6OE0275pnQG62gqDAvP6gupYfFT6LOTinKM70WKLAYJZqYZBmaGBhYmRoaGJsaWJplGhkap5mkWaSZGJoamx5vkA1pSGQkUHuai4rIwMEgvgsDCWpxSUMDAAe7Bs/',
            joinSucceed: true,
            peerIds: [],
        }
        if (Platform.OS === 'android') {
            requestCameraAndAudioPermission().then(() => {
                console.log('requested!')
            })
        }
    }

    componentDidMount() {
        this.init()
    }
     getPermission = async () => {
        if (Platform.OS === 'android') {
            await PermissionsAndroid.requestMultiple([
                PermissionsAndroid.PERMISSIONS.RECORD_AUDIO,
                PermissionsAndroid.PERMISSIONS.CAMERA,
            ]);
        }
    };
    // Pass in your App ID through this.state, create and initialize an RtcEngine object.
    init = async () => {
        const {appId} = this.state
        this._engine = await RtcEngine.create(appId)
        // Enable the video module.
        await this._engine.enableVideo()
        // Enable the local video preview.
        await this._engine.startPreview()
        // Set the channel profile as live streaming.
        await this._engine.setChannelProfile(ChannelProfile.LiveBroadcasting)
        // Set the usr role as host.
        await this._engine.setClientRole(ClientRole.Broadcaster)
    
        // Listen for the UserJoined callback.
        // This callback occurs when the remote user successfully joins the channel.
        this._engine.addListener('UserJoined', (uid, elapsed) => {
            console.log('UserJoined', uid, elapsed)
            const {peerIds} = this.state
            if (peerIds.indexOf(uid) === -1) {
                this.setState({
                    peerIds: [...peerIds, uid]
                })
            }
        })
    
        // Listen for the UserOffline callback.
        // This callback occurs when the remote user leaves the channel or drops offline.
        this._engine.addListener('UserOffline', (uid, reason) => {
            console.log('UserOffline', uid, reason)
            const {peerIds} = this.state
            this.setState({
                // Remove peer ID from state array
                peerIds: peerIds.filter(id => id !== uid)
            })
        })
    
        // Listen for the JoinChannelSuccess callback.
        // This callback occurs when the local user successfully joins the channel.
        this._engine.addListener('JoinChannelSuccess', (channel, uid, elapsed) => {
            console.log('JoinChannelSuccess', channel, uid, elapsed)
            this.setState({
                joinSucceed: true
            })
        })
    }
    startCall = async () => {
        await this._engine?.joinChannel(this.state.token, this.state.channelName, null, 0)
    }
    _renderVideos = () => {
        const {joinSucceed} = this.state
        return joinSucceed ? (
            <View style={styles.fullView}>
                <RtcLocalView.SurfaceView
                    style={styles.max}
                    channelId={this.state.channelName}
                    renderMode={VideoRenderMode.Hidden}/>
                {this._renderRemoteVideos()}
            </View>
        ) : null
    }
    _renderRemoteVideos = () => {
        const {peerIds} = this.state
        return (
            <ScrollView
                style={styles.remoteContainer}
                contentContainerStyle={{paddingHorizontal: 2.5}}
                horizontal={true}>
                    <Text>{JSON.stringify(peerIds)}</Text>
                {peerIds.map((value, index, array) => {
                    return (
                        <RtcRemoteView.SurfaceView
                            style={styles.remote}
                            uid={value}
                            channelId={this.state.channelName}
                            renderMode={VideoRenderMode.Hidden}
                            zOrderMediaOverlay={true}/>
                    )
                })}
            </ScrollView>
        )
    }
    endCall = async () => {
        await this._engine?.leaveChannel()
        this.setState({peerIds: [], joinSucceed: false})
    }
    render() {
        return (
            <View style={styles.max}>
                <View style={styles.max}>
                    <View style={styles.buttonHolder}>
                        <TouchableOpacity
                            onPress={this.startCall}
                            style={styles.button}>
                            <Text style={styles.buttonText}> Start Call </Text>
                        </TouchableOpacity>
                        <TouchableOpacity
                            onPress={this.endCall}
                            style={styles.button}>
                            <Text style={styles.buttonText}> End Call </Text>
                        </TouchableOpacity>
                    </View>
                    {this._renderVideos()}
                </View>
            </View>
        )
    }
    // Other code. See step 5 to step 10.
}
