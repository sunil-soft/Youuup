import AsyncStorage from '@react-native-async-storage/async-storage';
import { useEffect, useState } from "react";
import { Dimensions, Image, ImageBackground, StatusBar, Text, TouchableOpacity, View } from "react-native";

export function Intro({ navigation,onDone  }) {
  const [autoplay, setAutoplay] = useState(true);
  const [isScrollingOff, setIsScrollingOff] = useState(true);
  const [paused, setPaused] = useState(false);
  useEffect(() => {
  AsyncStorage.setItem('isFirstTimeOpen', 1)
}, []);

  // const Slide = ({ img, title, text }) => {
  //   return (
  //     <View style={{ flex: 1 }}>
  //       <ImageBackground style={{ flex: 1 }} source={img}>
  //         <View
  //           style={{
  //             paddingVertical: verticalScale(50),
  //             paddingHorizontal: scale(20),
  //           }}
  //         >
  //           <Text style={[TextStyles.title, { color: "#43686A" }]}>
  //             {title}
  //           </Text>
  //           <Text style={[TextStyles.light, { color: "#738485" }]}>{text}</Text>
  //         </View>
  //       </ImageBackground>
  //     </View>
  //   );
  // };

  return (
    
    <ImageBackground  style={{ flex: 1 }}  source={require("../../assets/splash/introbag.png")}>
        <StatusBar translucent backgroundColor="transparent" />
      <View style={{flex:1}}>
      <View style={{justifyContent:"flex-start",flex:0.6,marginLeft:20,marginRight:20,marginTop:70,marginBottom:30}}>
        
      {/* <Video  
          resizeMode='cover'
            source={video}                  // the video file
            paused={paused}                  // make it start    
            style={{height:314,borderRadius:20}}  // any style you want
           // repeat={true}   
           onTouchStart={() =>
                 setPaused(!paused)
        }                // make it a loop
        /> */}
        <Image   style={{height:314,width:'100%', borderRadius:20}} source={require("../../assets/splash/welcome.gif")} />

        {/* {paused &&
        <TouchableOpacity style={{position:'relative',bottom:'45%',zIndex:9999999,}}  onPress={() =>  setPaused(false)}>
      <Image style={{ width:87,height:61,alignSelf:'center'}} source={require("../../assets/splash/Shape.png")} />
      </TouchableOpacity>
        } */}
      </View>
    <View style={{alignContent:'center',alignItems:'center', flex:0.4,width:'100%',}}>
     {/* <Text style={{color:'white',fontSize:28,fontWeight:'500'}}>Bienvenidos</Text> */}
     {/* <Image style={{marginTop:10}} source={require("../../assets/splash/Logo.png")} /> */}
     <Text style={{color:'white',fontSize:18,fontWeight:'500',width:'70%',lineHeight:25,marginTop:20,textAlign:'center'}}> La aplicación para crear, compartir y disfrutar de contenido real.</Text>
    <TouchableOpacity 
     onPress={() => onDone()}
    style={{backgroundColor:'#08DDFD',marginTop:20,padding:20,width:Dimensions.get("window").width-70,justifyContent:'center',alignContent:'center',alignItems:'center',borderRadius:25}}>
     <Text style={{color:"#000000",fontSize:15,fontWeight:'600'}}>Entrar</Text>
    </TouchableOpacity>
   </View>
        </View>
        </ImageBackground>
  );
}

export default Intro;
