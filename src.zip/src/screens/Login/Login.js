import { useEffect, useState } from "react";
import {
  ActivityIndicator,
  Image, ImageBackground,
  StatusBar, Text,
  TouchableOpacity, View
} from "react-native";

import { newIcon } from "@/assets";
import { geterror, getUser } from "@/selectors/UserSelectors";
import messaging from "@react-native-firebase/messaging";
import { showMessage } from "react-native-flash-message";
import { KeyboardAwareScrollView } from 'react-native-keyboard-aware-scroll-view';
import { moderateScale } from "react-native-size-matters";
import { useDispatch, useSelector } from "react-redux";
import { login, popupoff } from "../../actions/UserActions";
import { Button } from "../../components/Button";
import { Header } from "../../components/Header";
import { InputField } from "../../components/InputField";
import { NAVIGATION } from "../../constants";
import { COLOR } from "../../constants/colors/colors";
import { verticalScale } from "../../helper/Scale";
import { FONTS } from "../../theme/fonts";
import { TextStyles } from "../../theme/TextStyles";
import { styles } from "./Login.styles";
export function Login(props) {
  const { navigation, route } = props;
  const dispatch = useDispatch();
  const [email, setEmail] = useState("");
  const user = useSelector(getUser);
  const error = useSelector(geterror);
  const [showModal, setShowModal] = useState(true);
  const [animating, setAnimating] = useState(false);

  const [secureText, setsecureText] = useState(true);
  const [isActiveviewstatus, setisActiveviewstatus] = useState(2);
  const [password, setpassword] = useState('');
  const [hasPermission, setPermission] = useState(false);
  const [fcmtokendata, setfcmtoken] = useState(false);

  const [radioButtonActive, SetRadioButtonActive] = useState(
    false
  );
  var validRegex =
    /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9-]+(?:\.[a-zA-Z0-9-]+)*$/;

  // const getFCMToken = async () => {
  //   try {
  //     const token = await messaging().getToken();
  //     console.log('hgh', token);
  //   } catch (e) {
  //     console.log('ff', error);
  //   }
  // };

  useEffect(() => {
    requestUserPermission();
    if (hasPermission) {
      getFcmToken();
    } else {
      requestUserPermission();
    }
    // getFCMToken();
  }, []);

  const requestUserPermission = async () => {
    const authStatus = await messaging().requestPermission();
    const enabled =
      authStatus === messaging.AuthorizationStatus.AUTHORIZED ||
      authStatus === messaging.AuthorizationStatus.PROVISIONAL;

    if (enabled) {
      console.log('Authorization status:', authStatus);
      setPermission(true);
    }
  };

  const getFcmToken = async () => {
    console.log('Getting fcm token!!!');
    const fcmToken = await messaging().getToken();
    if (fcmToken) {
      console.log('Your Firebase Token is => ', fcmToken);
      //AsyncStorage.setItem('fcmToken', fcmToken);
      setfcmtoken(fcmToken)
    } else {
      console.log('Failed', 'No token received');
    }
  };
  const HideModal = () => {
    //  setShowModal(false);
    dispatch(popupoff())
  };
  const Validation = () => {
    if (!email.trim()) {
      showMessage({
        message: "El campo de correo electrónico es obligatorio",
        type: "danger",
      });
    } else if (!email.match(validRegex)) {
      showMessage({
        message: "Por favor ingrese una dirección de correo electrónico válida",
        type: "danger",
      });
    }
    else if (!password.trim()) {
      showMessage({
        message: "El campo de contraseña es obligatorio",
        type: "danger",
      });
    }
    else if (!radioButtonActive) {
      showMessage({
        message: "Por favor acepte los Términos y Condiciones",
        type: "danger",
      });
    }


    else {
      LoginAccountAuth();
      //setShowModal(true);
      // props.navigation.navigate("EditUserDetail");
    }
  };
  const LoginAccountAuth = async () => {
    setAnimating(true)
    setTimeout(() => { setAnimating(false) }, 1000)
    const fcmToken = await messaging().getToken();
    const data = {
      email: email,
      password: password,
      device_token: fcmToken
    };
    console.log('Login Request', data)
    dispatch(login(data));

  };

  return (
    <ImageBackground
      style={{ flex: 1, }}
      resizeMode={"stretch"}
      backgroundColor={'black'}
      source={require("../../assets/splash/bg.png")}
    >
      <StatusBar translucent backgroundColor="transparent" />
      <Header back={true} {...props} />
      <KeyboardAwareScrollView>
        <View style={{ marginTop: verticalScale(50), alignSelf: "center" }}>
          <Image resizeMode="center" source={require("../../assets/splash/Logo.png")} />
        </View>
        <View style={styles.loginContainer}>
          {/* <Text style={TextStyles.title}>Keep it Real</Text> */}
          <Text style={TextStyles.light}>
            La aplicación para crear, compartir y disfrutar de contenido real.</Text>
          <Text style={TextStyles.titlelogin}>Iniciar sesión </Text>
          <Text style={TextStyles.titlereg}>
            Dirección de correo electrónico registrado
          </Text>
          <InputField
            placeholderColor={"white"}
            //right={true}
            uri={require("../../assets/login/closeeye.png")}
            urii={require("../../assets/login/openeye.png")}
            placeholder={""}
            mainViewStyle={{ width: "90%" }}
            //title={"Email Address"}
            value={email}
            onChangeText={(text) => setEmail(text.replace(/\s/g, ''))}
          // onFocus={() => {
          //   setisActiveviewstatus(2)
          // }}
          //defaultValue={"toprady876@gmail.com"}
          // icon={"email"}
          // color={"#05A1AB"}
          />

          <Text style={TextStyles.titlereg}>
            Contraseña
          </Text>
          <View style={{ flexDirection: 'row', alignItems: "center", marginLeft: 25 }}>
            <InputField
              placeholderColor={"white"}
              placeholder={""}
              mainViewStyle={{ width: "95%" }}
              secureTextEntry={secureText}
              isActiveview={isActiveviewstatus}
              //title={"Email Address"}
              onChangeText={(text) => setpassword(text)}

            //defaultValue={"toprady876@gmail.com"}
            // icon={"email"}
            // color={"#05A1AB"}
            />
            <TouchableOpacity
              onPress={() => { setisActiveviewstatus(1), setsecureText(!secureText) }}
              style={{ position: 'relative', zIndex: 999999, right: 35, padding: 4, }} >
              <Image style={{ marginBottom: 5 }} source={secureText ? require("../../assets/login/closeeye.png") : require("../../assets/login/openeye.png")} />
            </TouchableOpacity>
          </View>
          <TouchableOpacity onPress={() => navigation.navigate(NAVIGATION.forgotpassword)} style={{ marginTop: 15, alignItems: "flex-start", marginRight: '40%' }}>
            <Text style={TextStyles.forgotlabel}>*Olvidé mi contraseña </Text>
          </TouchableOpacity>
          <View style={{ flexDirection: 'row', justifyContent: 'center', alignContent: 'center', alignItems: 'center', margin: 5, width: '72%' }}>
            <TouchableOpacity
              onPress={() => SetRadioButtonActive(!radioButtonActive)}
            >
              {radioButtonActive ? (
                <Image
                  style={{ width: 20, height: 20, marginRight: 10, marginTop: verticalScale(2) }}
                  source={newIcon.checkedcheck}
                />
              ) : (
                <Image
                  style={{ width: 20, height: 20, marginTop: verticalScale(2), marginRight: 10, }}
                  source={newIcon.Checkbox}
                />
              )}
            </TouchableOpacity>
            <Text style={[TextStyles.terms, { fontSize: 13 }]}>
              He leído y acepto <Text style={{ color: '#08DDFD' }} onPress={() => navigation.navigate(NAVIGATION.Privacy, { pageshow: 1 })}>La política de privacidad y</Text> las <Text onPress={() => navigation.navigate(NAVIGATION.Terms)} style={{ color: '#08DDFD' }}>Condiciones de uso.</Text>
            </Text>
            {/* <TouchableOpacity
          style={{backgroundColor:"red"}}
           //onPress={() => navigate(NAVIGATION.createaccount)}
           >
            <Text
              style={[
                TextStyles.light2,
                {
                  fontSize: 13,
                  color: COLOR.AppColor,
                  fontFamily: FONTS.PoppinsMedium,
                },
              ]}
            >La política de
            </Text>
            <Text
              style={[
                TextStyles.light2,
                {
                  fontSize: 13,
                  color: COLOR.AppColor,
                  fontFamily: FONTS.PoppinsMedium,
                },
              ]}
            >privacidad y las Condiciones de uso.
            </Text>
          </TouchableOpacity> */}
          </View>
          <Button
            style={{ marginTop: verticalScale(10) }}
            onPress={Validation}
            // onPress={() => navigate(NAVIGATION.otp)}
            title={"Acceso"}
          />
          <View style={styles.bottomView}>
            <Text style={[TextStyles.light2, { fontSize: 14 }]}>
              ¿No tienes cuenta?{""}
            </Text>
            <TouchableOpacity
              onPress={() => navigation.navigate(NAVIGATION.createaccount)}
            >
              <Text
                style={[
                  TextStyles.light2,
                  {
                    fontSize: 14,
                    color: COLOR.AppColor,
                    fontFamily: FONTS.PoppinsMedium,
                    marginLeft: moderateScale(5),
                  },
                ]}
              >
                Regístrate
              </Text>
            </TouchableOpacity>
          </View>
        </View>
        {animating == true && (
          <ActivityIndicator
            animating
            color={'white'}
            size="large"
            style={styles.activityIndicator}
          />
        )}
      </KeyboardAwareScrollView>
    </ImageBackground>
  );
}
export default Login;