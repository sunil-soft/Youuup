import {
  editprofileapi
} from "@/actions/UserActions";
import { getExtension } from "@/helper/GlobalMethods";
import AsyncStorage from '@react-native-async-storage/async-storage';
import axios from "axios";
import { useEffect, useState } from "react";
import { ActivityIndicator, Image, ImageBackground, Modal, Platform, StatusBar, Text, TouchableOpacity, View } from "react-native";
import { KeyboardAwareScrollView } from 'react-native-keyboard-aware-scroll-view';
import { Button } from "../../components/Button";

import { showMessage } from "react-native-flash-message";
import ImagePicker from "react-native-image-crop-picker";
import { check, PERMISSIONS, request, RESULTS } from "react-native-permissions";
import { moderateScale, scale, verticalScale } from "react-native-size-matters";
import { useDispatch, useSelector } from "react-redux";
import { Header } from "../../components/Header";
import { InputField } from "../../components/InputField";
import { getUser } from "../../selectors/UserSelectors";
import { FONTS } from "../../theme/fonts";
import { styles } from "./EditProfilestyles";

const EditProfile = (props) => {
  const dispatch = useDispatch();
  const user = useSelector(getUser);
  const [fullName, setFullName] = useState("");
  const [email, setemail] = useState("");
  const [email_collaboration, setemail_collaboration] = useState("");
  const [image, setImage] = useState();
  const [ImageUri, setImageUri] = useState();
  const [animating, setAnimating] = useState(false);
  const [isModalVisiblee, setModalVisiblee] = useState(false);
  const [biotext, setbiotext] = useState('');
  const [web, setweb] = useState("");
  const [instaurl, setinstaurl] = useState("");
  const [fburl, setfburl] = useState("");
  const [youtube, setyoutube] = useState("");
  const [nick_name, setnickname] = useState("");
  const [titulo1, settitulo1] = useState("");
  const [titulo2, settitulo2] = useState("");
  const [titulo3, settitulo3] = useState("");

  const [enlance1, setenlance1] = useState("");
  const [enlance2, setenlance2] = useState("");
  const [enlance3, setenlance3] = useState("");

  // var validRegex =
  //   /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9-]+(?:\.[a-zA-Z0-9-]+)*$/;
    var validRegex = /^[a-z0-9]+@[a-z]+\.[a-z]{2,3}$/;


  useEffect(() => {
    setFullName(user?.profileinfo?.name)
    setnickname(user?.profileinfo?.nick_name)
    setbiotext(user?.profileinfo?.bio)
    setemail(user?.profileinfo?.email)
    setemail_collaboration(user?.profileinfo?.email_collaboration)
    setweb(user?.profileinfo?.website_url)
    setinstaurl(user?.profileinfo?.instagram_url)
    setfburl(user?.profileinfo?.facebook_url)
    setyoutube(user?.profileinfo?.youtube_url)
    setImage(user?.profileinfo?.profile_photo)
    settitulo1(user?.profileinfo?.promotion_title_one)
    settitulo2(user?.profileinfo?.promotion_title_two)
    settitulo3(user?.profileinfo?.promotion_title_three)

    setenlance1(user?.profileinfo?.promotion_title_one_link)
    setenlance2(user?.profileinfo?.promotion_title_two_link)
    setenlance3(user?.profileinfo?.promotion_title_three_link)
    // setAddress(user?.profileinfo?.payload.user_profiles.address)
  }, []);
  const toggleModall = () => {
    setModalVisiblee(!isModalVisiblee);
  };

  const takeFromCamera = () => {
    setModalVisiblee(false);
    ImagePicker.openCamera({
      width: 300,
      height: 400,
      cropping: true,
      cropperToolbarWidgetColor: '#5A67FC',
      cropperActiveWidgetColor: '#5A67FC',
    }).then(image => {

      setImage(image.path);
      uploadImages(image);

    })
      .catch(error => {
        if (error.code === "E_NO_CAMERA_PERMISSION") {
          // alert(error);
          // Alert.alert(
          //   `Turn on camera permission .`,
          //   "",
          //   [
          //     { text: "Go to Settings", onPress: () => Linking.openURL('app-settings:') },
          //     { text: "Don't Use Photos", onPress: () => { } },
          //   ],
          // );
          // setModalVisiblee(false);
        }
      });



  }
  const chooseFromGallery = () => {
    setModalVisiblee(false);
    const response = check(
      Platform.select({
        ios: PERMISSIONS.IOS.CAMERA,
        android: PERMISSIONS.ANDROID.CAMERA,
      })
    );
    if (response !== RESULTS.GRANTED && response !== RESULTS.UNAVAILABLE) {
      request(Platform.OS === 'ios' ? PERMISSIONS.IOS.CAMERA : PERMISSIONS.ANDROID.CAMERA).then((result) => {
      });

    }
    else {
      request(Platform.OS === 'ios' ? PERMISSIONS.IOS.CAMERA : PERMISSIONS.ANDROID.CAMERA).then((result) => {
      });
    }

    ImagePicker.openPicker({
      mediaType: 'photo',
      cropping: true,
    }).then(async (image) => {
      console.log('image response => ', image);
      // setLocalURL(file.path);
      // setImageFile(file);
      setImage(image.path);
      uploadImages(image);
    })
      .catch(error => {
        if (error.code === "E_NO_LIBRARY_PERMISSION") {
          //setModalVisiblee(false);
          // Alert.alert(
          //   `Active el permiso de la biblioteca de fotos para permitir el acceso a su galería de fotos para cargar fotos`,
          //   "",
          //   [
          //     { text: "Ir a la configuración", onPress: () => Linking.openURL('app-settings:') },
          //     { text: "No use fotos", onPress: () => { } },
          //   ],
          // );
        }
      });
  };
  const Validation = () => {
    //alert(email_collaboration)
    // if (!image) {
    //   showMessage({
    //     message: "Profile Picture is mandatory",
    //     type: "danger",
    //   });
    // } 
    if (!fullName.trim()) {
   
      showMessage({
        message: "Por favor ingrese su nombre",
        type: "danger",
      });
    }
    else if (email_collaboration && !email_collaboration.match(validRegex)) {
      showMessage({
        message: "Ingrese un correo electrónico de colaboración válido.",
        type: "danger",
      });
    }
    // else if (!nick_name || !nick_name.trim()) {
    //   showMessage({
    //     message: "Por favor ingrese su nick nombre",
    //     type: "danger",
    //   });
    // }
    else {
      editprofile();
      //setShowModal(true);
      // props.navigation.navigate("EditUserDetail");
    }
  };
  const editprofile = async () => {

    const data = email_collaboration && email_collaboration!='' && email_collaboration != null ? {
      name: fullName,
     // nick_name: nick_name ? nick_name.trim() : '',
      //profile_photo: ImageUri?ImageUri:image,
      // address:address,
      email: email,
      email_collaboration:email_collaboration && email_collaboration.trim(),
      bio: biotext ? biotext.trim() : '',
      facebook_url: fburl?fburl.trim():'',
      instagram_url: instaurl?instaurl.trim():'',
      website_url: web?web.trim():'',
      youtube_url: youtube?youtube.trim():'',
      promotion_title_one: titulo1?titulo1.trim():'',
      promotion_title_one_link: enlance1?enlance1.trim():'',
      promotion_title_two: titulo2?titulo2.trim():'',
      promotion_title_two_link: enlance2?enlance2.trim():'',
      promotion_title_three: titulo3?titulo3.trim():'',
      promotion_title_three_link: enlance3?enlance3.trim():'',

    } : {
      name: fullName,
      //nick_name: nick_name?nick_name.trim():'',
      //profile_photo: ImageUri?ImageUri:image,
      // address:address,
      email: email,
    //  email_collaboration:email_collaboration,
      email_collaboration:email_collaboration ? email_collaboration.trim():"",
      bio: biotext ? biotext.trim(): '',
      facebook_url: fburl?fburl.trim():'',
      instagram_url: instaurl?instaurl.trim():'',
      website_url: web?web.trim():'',
      youtube_url: youtube?youtube.trim():'',
      promotion_title_one: titulo1?titulo1.trim():'',
      promotion_title_one_link: enlance1?enlance1.trim():'',
      promotion_title_two: titulo2?titulo2.trim():'',
      promotion_title_two_link: enlance2?enlance2.trim():'',
      promotion_title_three: titulo3?titulo3.trim():'',
      promotion_title_three_link: enlance3?enlance3.trim():'',
    };
    console.log(data)
    dispatch(editprofileapi(data));
  };
  const launchGallery = () => {
    ImagePicker.openPicker({
      width: 300,
      height: 400,
      hideBottomControls: true,
      cropping: true,
    }).then((image) => {
      console.log("imageInformation", image);

      setImage(image.path);
      //  setuploadImage(image);

      // uploadImages(image);
    });
  };

  const uploadImages = async (image) => {
    AsyncStorage.getItem('auth_token').then(async (datatoken) => {

      const formData = new FormData();

      const fileExtension = getExtension(image.path);
      const imageData = {
        uri:
          Platform.OS === "android"
            ? image.path
            : image.path.replace("file://", ""),

        type: image.mime,

        name: `profile_image_.${fileExtension}`,
      };

      console.log("check image data ", imageData);
      formData.append("file", imageData);
      formData.append("user_id", user && user?.userinfo?.user.id);
      console.log("check formData data ", formData);
      // dispatch(imageuploadServer(formData));
      axios({
        url: "https://youuup.es/mobile-api/user/update-profile-photo",

        method: "POST",

        data: formData,

        headers: {
          "Content-Type": "multipart/form-data",
          Accept: "application/json",
          Authorization: "Bearer " + datatoken,
        },
      })
        .then((resp) => {
          console.log("resp", resp);
          showMessage({
            message: "Tu imagen de perfil se actualizó con éxito",
            type: "success",
          });
          //  resolve(resp.data.payload.url);
          // setImageUri(resp.data.payload.url);
        })
        .catch((error) => console.error("opdioeueo", error));
    });


  };


  const PopUp2 = () => {
    return (

      <Modal transparent visible={isModalVisiblee}>
        <View
          style={{
            flex: 1,
            backgroundColor: "#000000aa",
            padding: 20,
            justifyContent: "center",
          }}
        >
          <View style={{
            backgroundColor: "white", backgroundColor: "#FFFFFF",
            padding: 20,
            borderRadius: moderateScale(20),
          }}>
            <Text
              style={{
                color: "#43686A",
                fontSize: moderateScale(20),
                fontFamily: FONTS.PoppinsSemiBold,
              }}
            >
              Cargar imagen
            </Text>
            <View
              style={{
                flexDirection: "row",
                alignItems: "center",
                marginTop: verticalScale(10),
              }}
            >
              <Image source={require("../../assets/Home/gallery.png")} />
              <TouchableOpacity onPress={chooseFromGallery}>
                <Text
                  style={{
                    color: "#738485",
                    fontFamily: FONTS.PoppinsRegular,
                    fontSize: moderateScale(18),

                    marginLeft: moderateScale(10),
                  }}
                >
                  Elegir de la galería
                </Text>
              </TouchableOpacity>
            </View>
            <View
              style={{
                flexDirection: "row",
                alignItems: "center",
                marginTop: verticalScale(10),
              }}
            >
              <Image
                style={{ width: scale(19), height: scale(15.2) }}
                source={require("../../assets/Home/photo-camera.png")}
              />
              <TouchableOpacity onPress={takeFromCamera}>
                <Text
                  style={{
                    color: "#738485",
                    fontFamily: FONTS.PoppinsRegular,
                    fontSize: moderateScale(18),
                    marginLeft: moderateScale(10),
                  }}
                >
                  Toma una foto
                </Text>
              </TouchableOpacity>
            </View>
            <TouchableOpacity
              style={{ justifyContent: "center", alignItems: "center" }}
              onPress={toggleModall}
            >
              <Text
                style={{
                  color: "#05A1AB",
                  marginTop: verticalScale(10),
                  fontFamily: FONTS.PoppinsMedium,
                  fontSize: moderateScale(16),
                }}
              >
                Cerrar
              </Text>
            </TouchableOpacity>
          </View>
        </View>
      </Modal>
    );
  };
  return (
    <ImageBackground
      style={{ flex: 1, }}
      resizeMode={"stretch"}
      backgroundColor={'black'}
      source={require("../../assets/images/editprofileback.png")}
    >

      <StatusBar translucent backgroundColor="transparent" />
      <Header back={true} {...props} title='Editar perfil' />
      {/* {showModal && <PopUp />} */}
      {isModalVisiblee && <PopUp2 />}
      <KeyboardAwareScrollView>
        <View style={styles.mainContainer}>
          <View style={{ alignContent: 'flex-end', marginTop: 80, alignSelf: "center", justifyContent: 'center', alignItems: 'center' }}>
            <View style={styles.picView}>
              {image ? (
                <Image
                  style={{
                    width: 131,
                    height: 130,
                    borderRadius: moderateScale(70),
                  }}
                  source={{ uri: image }}
                />
              ) : (
                <Image style={{
                  width: 131,
                  height: 130,
                  borderRadius: moderateScale(70),
                }} source={require("../../assets/images/profileback.png")} />

              )}
            </View>
            <TouchableOpacity onPress={toggleModall} style={{ padding: 5, zIndex: 99999, position: 'relative', bottom: 42, alignSelf: "flex-end", left: 15 }}>
              <Image source={require("../../assets/images/editpencil.png")} />
            </TouchableOpacity>
          </View>
          <View style={{ paddingLeft: 20, paddingRight: 20 }}>
            <Text style={{ color: '#08DDFD', fontSize: 17, fontFamily: FONTS.PoppinsMedium, fontWeight: '600' }}>
              Acerca de ti
            </Text>
            <View style={{ marginTop: 10 }}>

              {/* <Text style={styles.labal}>Nick</Text>
              <InputField
                onChangeText={(text) => {
                  setnickname(text);
                }}
                value={nick_name}
                color={"white"}
                mainViewStyle={{ width: "100%" }}
                placeholderColor={"white"}
              /> */}
              <Text style={styles.labal}>Nombre Ó Nick</Text>
              <InputField
                onChangeText={(text) => {
                  setFullName(text);
                }}
                value={fullName}
                color={"white"}
                mainViewStyle={{ width: "100%" }}
                placeholderColor={"white"}
              />
              {user && user?.userinfo?.user.user_type_id == 2 &&
                <>
                  <Text style={styles.labal}>Email personal</Text>
                  <InputField
                    onChangeText={(text) => {
                      setemail(text);
                    }}
                    editable={false}
                    value={email}
                    color={"white"}
                    mainViewStyle={{ width: "100%" }}
                    // icon={"account"}
                    placeholderColor={"white"}
                  />
                </>
              }

              {user && user?.userinfo?.user.user_type_id == 3 &&
                <>
                  <Text style={styles.labal}>Estado</Text>
                  <InputField
                    onChangeText={(text) => {
                      setbiotext(text);
                    }}
                    numberOfLines={5}
                    maxLength={100}
                    multiline={true}
                    value={biotext}
                    color={"white"}
                    mainViewStyle={{ width: "100%", height: 100 }}
                    // icon={"account"}
                    placeholderColor={"white"}
                  />
                </>
              }
            </View>
            {user && user?.userinfo?.user.user_type_id == 3 &&
              <>
                <View style={{ width: '100%', height: 0.5, backgroundColor: '#2A2A2A' }}>
                </View>
                <Text style={styles.labal}>Email personal</Text>
                <InputField
                  onChangeText={(text) => {
                    setemail(text);
                  }}
                  editable={false}
                  value={email}
                  color={"white"}
                  mainViewStyle={{ width: "100%" }}
                  // icon={"account"}
                  placeholderColor={"white"}
                />
                <Text style={styles.labal}>Email Colaboración</Text>
                <InputField
                  onChangeText={(text) => {
                    setemail_collaboration(text);
                  }}

                  value={email_collaboration}
                  color={"white"}
                  mainViewStyle={{ width: "100%" }}
                  // icon={"account"}
                  placeholderColor={"white"}
                />

                <Text style={styles.labal}>Web</Text>
                <InputField
                  onChangeText={(text) => {
                    setweb(text);
                  }}

                  value={web}
                  color={"white"}
                  mainViewStyle={{ width: "100%" }}
                  // icon={"account"}
                  placeholderColor={"white"}
                />
                <View style={{ width: '100%', height: 0.5, backgroundColor: '#2A2A2A', marginTop: 10 }}>
                </View>
                <Text style={{ color: '#08DDFD', fontSize: 17, fontFamily: FONTS.PoppinsMedium, fontWeight: '600' }}>
                  Redes sociales
                </Text>

                <Text style={styles.labal}>enlace de instagram</Text>
                <InputField
                  onChangeText={(text) => {
                    setinstaurl(text);
                  }}

                  value={instaurl}
                  color={"white"}
                  mainViewStyle={{ width: "100%" }}
                  // icon={"account"}
                  placeholderColor={"white"}
                />

                <Text style={styles.labal}>enlace de facebook</Text>
                <InputField
                  onChangeText={(text) => {
                    setfburl(text);
                  }}
                  value={fburl}
                  color={"white"}
                  mainViewStyle={{ width: "100%" }}
                  // icon={"account"}
                  placeholderColor={"white"}
                />
                <Text style={styles.labal}>enlace de youtube</Text>
                <InputField
                  onChangeText={(text) => {
                    setyoutube(text);
                  }}

                  value={youtube}
                  color={"white"}
                  mainViewStyle={{ width: "100%" }}
                  // icon={"account"}
                  placeholderColor={"white"}
                />
                <Text style={{ color: '#08DDFD', fontSize: 17, fontFamily: FONTS.PoppinsMedium, fontWeight: '600' }}>
                  Enlance a promoción
                </Text>
                <Text style={styles.labal}>Titulo1</Text>
                <InputField
                  onChangeText={(text) => {
                    settitulo1(text);
                  }}

                  value={titulo1}
                  color={"white"}
                  mainViewStyle={{ width: "100%" }}
                  // icon={"account"}
                  placeholderColor={"white"}
                />
                <Text style={styles.labal}>Enlace</Text>
                <InputField
                  onChangeText={(text) => {
                    setenlance1(text);
                  }}

                  value={enlance1}
                  color={"white"}
                  mainViewStyle={{ width: "100%" }}
                  // icon={"account"}
                  placeholderColor={"white"}
                />
                <Text style={styles.labal}>Titulo2</Text>
                <InputField
                  onChangeText={(text) => {
                    settitulo2(text);
                  }}

                  value={titulo2}
                  color={"white"}
                  mainViewStyle={{ width: "100%" }}
                  // icon={"account"}
                  placeholderColor={"white"}
                />
                <Text style={styles.labal}>Enlace</Text>
                <InputField
                  onChangeText={(text) => {
                    setenlance2(text);
                  }}

                  value={enlance2}
                  color={"white"}
                  mainViewStyle={{ width: "100%" }}
                  // icon={"account"}
                  placeholderColor={"white"}
                />
                <Text style={styles.labal}>Titulo3</Text>
                <InputField
                  onChangeText={(text) => {
                    settitulo3(text);
                  }}

                  value={titulo3}
                  color={"white"}
                  mainViewStyle={{ width: "100%" }}
                  // icon={"account"}
                  placeholderColor={"white"}
                />
                <Text style={styles.labal}>Enlace</Text>
                <InputField
                  onChangeText={(text) => {
                    setenlance3(text);
                  }}

                  value={enlance3}
                  color={"white"}
                  mainViewStyle={{ width: "100%" }}
                  // icon={"account"}
                  placeholderColor={"white"}
                />
              </>
            }
            <Button
              onPress={Validation}
              // onPress={() =>props.navigation.navigate("OTP",{data:{"email":'test@yopmail.com'}})}

              title={"Actualizar"}
            />
          </View>
        </View>
        {animating == true && (
          <ActivityIndicator
            animating
            color={'black'}
            size="large"
            style={styles.activityIndicator}
          />
        )}
      </KeyboardAwareScrollView>
    </ImageBackground>
  );
};

export default EditProfile;
