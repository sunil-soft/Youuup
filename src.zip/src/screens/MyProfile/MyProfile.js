import { Apiurl } from "@/constants/Apiurl";
import { useFocusEffect } from "@react-navigation/native";
//import moment from 'moment';
import AsyncStorage from '@react-native-async-storage/async-storage';
import axios from "axios";
import moment from 'moment/min/moment-with-locales';
import React, { useState } from "react";
import { Alert, FlatList, Image, Linking, StatusBar, Text, TouchableOpacity, View } from "react-native";
import { showMessage } from "react-native-flash-message";
import { KeyboardAwareScrollView } from 'react-native-keyboard-aware-scroll-view';
import { moderateScale, verticalScale } from "react-native-size-matters";
import { useDispatch, useSelector } from "react-redux";
import { Creatervideosapi, Myprofile } from "../../actions/UserActions";
import { Header } from "../../components/Header";
import { NAVIGATION } from "../../constants";
import { getUser } from "../../selectors/UserSelectors";
import { FONTS } from "../../theme/fonts";
import { styles } from "./MyProfile.styles";

moment.locale('es')

const DATA = [
  {
    id: 'bd7acbea-c1b1-46c2-aed5-3ad53abb28ba',
    title: 'First Item',
  },
  {
    id: '3ac68afc-c605-48d3-a4f8-fbd91aa97f63',
    title: 'Second Item',
  },
  {
    id: '58694a0f-3da1-471f-bd96-145571e29d72',
    title: 'Third Item',
  },
  {
    id: '58694a0f-3da1-471f-bd96-145571e29d72',
    title: 'Third Item',
  },
  {
    id: '58694a0f-3da1-471f-bd96-145571e29d72',
    title: 'Third Item',
  },
  {
    id: '58694a0f-3da1-471f-bd96-145571e29d72',
    title: 'Third Item',
  },
  {
    id: '58694a0f-3da1-471f-bd96-145571e29d72',
    title: 'Third Item',
  },
];
const MyProfile = (props) => {
  const dispatch = useDispatch();
  const user = useSelector(getUser);
  const { navigation, route } = props;
  const [showpromocion, setshowpromocion] = useState(false);

  // const userData = useSelector(getProfile);
  useFocusEffect(
    React.useCallback(() => {
      UserProfilee();
      console.log('dfd',user.profileinfo)
      // return () => unsubscribe;
    }, [])
  );
  const UserProfilee = () => {
    console.log(user)
    
    dispatch(Myprofile());
    const data = {
      "user_id": user?.userinfo?.user?.id,
      "video_type": 1,
      "offset": 0,
      "limit": 1000
    };
    dispatch(Creatervideosapi(data));
  };
  const deletevideo = (id) => {
    Alert.alert('', 'Desea eliminar su vídeo definitivamente?', [
      //   { text: 'OK', onPress: () => dispatch(logout()) },
      { text: 'Sí', onPress: () =>delete_video(id) },
      {
        text: 'Cancelar',
        onPress: () => console.log('Cancel Pressed'),
        style: 'cancel',
      },
    ]);
  }
  const delete_video = (id) => {
    AsyncStorage.getItem('auth_token').then(async (datatoken) => {
      if (datatoken) {
        axios({
          url: Apiurl + "video/delete-my-video",
          method: "POST",
          data: { "video_id": id },
          headers: {
            Accept: "application/json",
            Authorization: "Bearer " + datatoken,
          },
        })
          .then((response) => {
            showMessage({
              message: "Borrado exitosamente.",
              type: "success",
            });
            const data = {
              "user_id": user?.userinfo?.user?.id,
              "video_type": 1,
              "offset": 0,
              "limit": 1000
            };
            dispatch(Creatervideosapi(data));
          })
          .catch(function (error) {
           console.log(error)

          });
      }

    });
  };
  const formatCash = (n) => {
    if (n < 1e3) return n;
    if (n >= 1e3 && n < 1e6) return +(n / 1e3).toFixed(1) + "K";
    if (n >= 1e6 && n < 1e9) return +(n / 1e6).toFixed(1) + "M";
    if (n >= 1e9 && n < 1e12) return +(n / 1e9).toFixed(1) + "B";
    if (n >= 1e12) return +(n / 1e12).toFixed(1) + "T";
  };
  return (
    // <ScrollView>
    <View style={{ flex: 1, backgroundColor: "#181A1B" }}>
      <Header {...props} midle={true} />
      <StatusBar
        translucent
        barStyle="light-content"
        backgroundColor={"transparent"}
      />
      <KeyboardAwareScrollView>
        <View style={{ justifyContent: "center", alignItems: "center", marginTop: 100 }}>
          {user?.profileinfo?.profile_photo ?
            <Image style={{ width: 100, height: 100, borderRadius: moderateScale(50), }}
              source={{ uri: user.profileinfo.profile_photo }}
            />
            :
            <Image style={{ width: 100, height: 100, borderRadius: moderateScale(50), }}
              source={require("../../assets/images/profileback.png")}
            />
          }
          <Text style={{ fontSize: moderateScale(16), color: "#FFFFFF", marginTop: 5 }}>
            {/* {JSON.stringify( user?.profileinfo)}  */}
            {user?.profileinfo?.name}
          </Text>
          <Text style={styles.RadiologyStyle}>
           {user?.profileinfo?.bio}
          </Text>
        </View>

        <View style={{ flexDirection: 'row', justifyContent: "center", marginTop: 20 }}>
          <TouchableOpacity
            onPress={() => user && user?.profileinfo && user.profileinfo?.following_count > 0 ? navigation.navigate(NAVIGATION.Followerlist, { tabactivestatus: 1, usernameshow: user && user.profileinfo && user.profileinfo.name, creater_id: user?.profileinfo?.id }) : ''}
            style={{ marginRight: 10 }}>
            <Text style={styles.followtext}>{user?.profileinfo?.following_count}</Text>
            <Text style={styles.followtextlabel}>Siguiendo</Text>
          </TouchableOpacity>
          {user?.userinfo?.user.user_type_id == 3 &&
            <>
              <View style={{ backgroundColor: "#08DDFD", width: 0.5 }}>
              </View>
              <TouchableOpacity
                onPress={() => user && user.profileinfo && user.profileinfo?.followers_count > 0 ? navigation.navigate(NAVIGATION.Followerlist, { tabactivestatus: 2, usernameshow: user && user.profileinfo && user.profileinfo.name, creater_id: user?.profileinfo?.id }) : ''}
                style={{ marginRight: 15, marginLeft: 15 }}>
                <Text style={styles.followtext}>{user?.profileinfo?.followers_count}</Text>
                <Text style={styles.followtextlabel}>Seguidores</Text>
              </TouchableOpacity>
              <View style={{ backgroundColor: "#08DDFD", width: 0.5 }}>
              </View>
              <View style={{ marginLeft: 10 }}>
                <Text style={styles.followtext}>{user?.profileinfo?.i_like}</Text>
                <Text style={styles.followtextlabel}>Me gusta</Text>
              </View>
            </>
          }
        </View>

        <View style={{ flexDirection: 'row', justifyContent: "space-evenly", marginTop: 20, paddingLeft: 15, paddingRight: 15 }}>
          <TouchableOpacity onPress={() => navigation.navigate(NAVIGATION.EditProfile)} style={{ backgroundColor: '#08DDFD', borderRadius: 25, paddingLeft: 20, paddingRight: 20, padding: 5 }}>
            <Text style={{ color: '#000000', fontSize: 15, fontFamily: FONTS.PoppinsRegular, fontWeight: '600' }}>Editar</Text>
          </TouchableOpacity>
          {user?.userinfo?.user.user_type_id == 3 &&
            <>
              <TouchableOpacity
                onPress={() => user && user.profileinfo && user.profileinfo.website_url ? Linking.openURL(user && user.profileinfo && user.profileinfo.website_url) : ''}

                style={{ backgroundColor: '#08DDFD', borderRadius: 25, paddingLeft: 20, paddingRight: 20, padding: 5, justifyContent: 'center' }}>
                <Text style={{ color: '#000000', fontSize: 15, fontFamily: FONTS.PoppinsRegular, fontWeight: '600' }}>Web</Text>
              </TouchableOpacity>

              <TouchableOpacity
                onPress={() => user && user.profileinfo && user.profileinfo.facebook_url ? Linking.openURL(user?.profileinfo.facebook_url) : ''}
              >
                <Image source={require("../../assets/images/fbicn.png")} />
              </TouchableOpacity>
              <TouchableOpacity
                onPress={() => user && user.profileinfo && user.profileinfo.instagram_url ? Linking.openURL(user?.profileinfo.instagram_url) : ''}

              >
                <Image source={require("../../assets/images/insta.png")} />
              </TouchableOpacity>
              <TouchableOpacity
                onPress={() => user && user.profileinfo && user.profileinfo.youtube_url ? Linking.openURL(user?.profileinfo.youtube_url) : ''}
              >
                <Image source={require("../../assets/images/youtube.png")} />
              </TouchableOpacity>
            </>
          }
        </View>
        <View style={{ backgroundColor: '#2A2A2A', height: 0.5, marginTop: 20 }}>
        </View>
        {user?.userinfo?.user.user_type_id == 3 &&
          <View style={{ marginTop: 10, flexDirection: "row", justifyContent: 'space-around' }}>
            <TouchableOpacity style={styles.rowview} onPress={() => props.navigation.navigate('ChatUSerList')}>
              <Image source={require("../../assets/images/chaticonprof.png")} />
              <Text style={styles.label}>Mensaje</Text>
            </TouchableOpacity>
            <TouchableOpacity
              onPress={() => user && user.profileinfo && user.profileinfo.email?Linking.openURL('mailto:' + (user && user.profileinfo && user.profileinfo.email) + ''):''}

              style={styles.rowview}>
              <Image source={require("../../assets/images/emailiconprof.png")} />
              <Text style={styles.label}>Email</Text>
            </TouchableOpacity>
            <TouchableOpacity
              onPress={() => user && user.profileinfo && user.profileinfo.email_collaboration?Linking.openURL('mailto:' + (user && user.profileinfo && user.profileinfo.email_collaboration) + ''):''}

              style={styles.rowview}>
              <Image source={require("../../assets/images/emailiconprof.png")} />
              <Text style={styles.label}>Colaboración</Text>
            </TouchableOpacity>
          </View>
        }
        {user?.userinfo?.user.user_type_id == 3 &&
          <TouchableOpacity onPress={() => setshowpromocion(!showpromocion)} style={{ alignContent: 'center', justifyContent: 'center', alignItems: 'center', marginLeft: 20, marginRight: 20, marginTop: 10, backgroundColor: '#08DDFD', borderRadius: 10, paddingLeft: 20, paddingRight: 20, padding: 5 }}>
            <Text style={{ color: '#000000', fontSize: 15, fontFamily: FONTS.PoppinsMedium, fontWeight: '600' }}>Enlance a promoción</Text>
          </TouchableOpacity>
        }
        {showpromocion &&
          <View style={{ marginTop: 5, borderRadius: 10, minHeight: 50, backgroundColor: 'white', marginLeft: 20, marginRight: 20, paddingLeft: 15, paddingTop: 5 }}>
            {user && user.profileinfo && user?.profileinfo?.promotion_title_one && 
             <TouchableOpacity
             onPress={() => user && user.profileinfo && user.profileinfo.promotion_title_one_link ? Linking.openURL(user?.profileinfo.promotion_title_one_link) : ''}
              >
            <Text style={{ color: 'black', fontFamily: FONTS.PoppinsMedium }}>1. {user && user.profileinfo && user.profileinfo.promotion_title_one}</Text>
            </TouchableOpacity>
            }
            {user && user.profileinfo && user?.profileinfo?.promotion_title_two &&
             <TouchableOpacity
             onPress={() => user && user.profileinfo && user.profileinfo.promotion_title_two_link ? Linking.openURL(user?.profileinfo.promotion_title_two_link) : ''}
              >
             <Text style={{ color: 'black', fontFamily: FONTS.PoppinsMedium }}>2. {user && user.profileinfo && user.profileinfo.promotion_title_two}</Text>
             </TouchableOpacity>
            }
            {user && user.profileinfo && user?.profileinfo?.promotion_title_three &&
            <TouchableOpacity
            onPress={() => user && user.profileinfo && user.profileinfo.promotion_title_three_link ? Linking.openURL(user?.profileinfo.promotion_title_three_link) : ''}
             >
             <Text style={{ color: 'black', fontFamily: FONTS.PoppinsMedium }}>3. {user && user.profileinfo && user.profileinfo.promotion_title_three}</Text>
             </TouchableOpacity>
            }
            {user && user.profileinfo && !user?.profileinfo?.promotion_title_three && !user?.profileinfo?.promotion_title_two && !user?.profileinfo?.promotion_title_one && <Text style={{ color: 'black', fontFamily: FONTS.PoppinsMedium, textAlign: 'center' }}>Sin promoción</Text>
            }

          </View>
        }
        <View style={{ paddingLeft: verticalScale(10), paddingRight: verticalScale(10), width: '99%', flexDirection: 'row' }}>
          <View
            style={{
              marginTop: verticalScale(10),
             
              flexDirection: "row",
              width: "99%",
              marginRight: 10,
             // justifyContent:'space-around'
              //backgroundColor:"red",
             // alignSelf:'center'
            //  marginRight:10
            }}
          >
    

            {user && user?.userinfo?.user.user_type_id == 3 &&
              user?.creatervideos?.length > 0 ?
              <FlatList
                data={user && user.creatervideos}
                numColumns={3}
                renderItem={({ item,index }) =>
  //           <View>
  //             <View style={{width:"100%",  position:"absolute", zIndex:9999999,top:5,flexDirection:"row", justifyContent:"space-between",alignItems:'center',}}>
  //               <View 
  //               // onPress={() => deletenotify(item.id)} 
  //               style={{padding:5, alignSelf:'flex-end',flexDirection:'row',alignItems:'center'}}
  //                 >
  //                   <Text style={{ fontSize: 12, paddingLeft: 8, color: '#08DDFD', fontFamily: FONTS.PoppinsRegular }}>{moment.utc(item.upload_date).local().startOf('seconds').fromNow(true)}</Text>
  //                </View>
  //                <TouchableOpacity 
  //  onPress={() => delete_fav(item.id)} 
  //  style={{marginRight:5,marginTop:3}}
  // >
  //  <Image
  //   style={{height:24,width:24}}
  //   source={require("../../assets/images/crossdelete.png")}
  //   />
  //  </TouchableOpacity>
             
  //           </View>
  //           <TouchableOpacity onPress={()=>navigation.navigate(NAVIGATION.mainHome,{firstvideo_id:item.id})} style={{ width: '28%', borderRadius: moderateScale(15), margin: 8, marginTop: 7, backgroundColor: "transparent" }}>
  //               <View style={{ zIndex: 99999, position: 'relative', top: 25, marginLeft: 5 }}>
  //                 <Text style={{ fontSize: 12, paddingLeft: 3, color: '#08DDFD', fontFamily: FONTS.PoppinsRegular }}>{moment.utc(item.upload_date).local('es').startOf('seconds').fromNow(true)} </Text>
  //               </View>
  //               <View  style={styles.backgroundVideo}> 
  //                 <Image resizeMode="cover"  style={{width:105,height:153,borderRadius:15}} source={ item?.video_thumbnail=='null'?require("../../assets/Home/New/videothumb.png"):{ uri:Apiurl + item?.video_thumbnail} }/>
  //               </View>
  //              </TouchableOpacity>
  <View style={{flex:1}}>
<View style={{width:"100%",  position:"absolute", zIndex:9999999,top:5,flexDirection:"row", justifyContent:"space-between",alignItems:'center',}}>
   <View 
  // onPress={() => deletenotify(item.id)} 
   style={{padding:5, alignSelf:'flex-end',flexDirection:'row',alignItems:'center'}}
   >
     <Text style={{ fontSize: 12, paddingLeft: 8, color: '#08DDFD', fontFamily: FONTS.PoppinsRegular }}>{moment.utc(item.upload_date).local().startOf('seconds').fromNow(true)}</Text>
   </View>
   
  <TouchableOpacity 
   onPress={() => deletevideo(item.id)} 
   style={{marginRight:7,marginTop:3}}
  >
   <Image
    style={{height:22,width:22}}
    source={require("../../assets/images/crossdelete.png")}
    />
   </TouchableOpacity>
</View>
          <TouchableOpacity onPress={()=>
          {
          //  navigation.goBack()
           navigation.replace(NAVIGATION.Selfvideolist,{selfvideodata:user && user.creatervideos,startindex:index})
          }
          
          } 
            
            style={{  borderRadius: moderateScale(15), margin: 5, marginTop: 7, backgroundColor: "transparent" }}
            
            
            >
                {/* <View style={{ zIndex: 99999, position: 'relative', top: 25, marginLeft: 5 }}>
                  <Text style={{ fontSize: 12, paddingLeft: 3, color: '#08DDFD', fontFamily: FONTS.PoppinsRegular }}>{moment.utc(item.upload_date).local('es').startOf('seconds').fromNow(true)} </Text>
                </View> */}
                <View  style={styles.backgroundVideo}> 
                  <Image resizeMode="cover"  style={{width:'100%',height:153,borderRadius:15}} source={ item?.video_thumbnail=='null'?require("../../assets/Home/New/videothumb.png"):{ uri:Apiurl + item?.video_thumbnail} }/>
               </View>
            </TouchableOpacity>
  
  <View style={{position:"absolute", zIndex:9999999,bottom:5,flexDirection:"row",justifyContent:"flex-start",marginLeft:15,marginRight:4,alignItems:'center'}}>
  {item?.view_count>0 &&
  <View 
 // onPress={() => deletenotify(item.id)} 
style={{padding:5, alignSelf:'flex-end',right:5,flexDirection:'row',alignItems:'center'}}
  >
   <Image
   // style={{height:18,width:18}}
    source={require("../../assets/images/videoview.png")}
    />
    <Text style={{paddingTop:4, color:'white',paddingLeft:5,fontSize:12,fontFamily:FONTS.PoppinsRegular}}>{formatCash(item?.view_count)}</Text>
  </View>
     }

  </View>
</View>
                }
              />
              :
              <View style={{ width: "100%" }}>
                <Image resizeMode="cover" style={{ alignSelf: 'center' }} source={require("../../assets/images/defaultimage.png")} />
              </View>
            }
          </View>
        </View>

      </KeyboardAwareScrollView>
    </View>

  );
};

export default MyProfile;
