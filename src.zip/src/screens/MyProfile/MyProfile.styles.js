import { StyleSheet } from "react-native";
import { moderateScale, scale } from "react-native-size-matters";
import { verticalScale } from "../../helper/Scale";
import { FONTS } from "../../theme/fonts";

export const styles = StyleSheet.create({
  backImage: {
    position: "absolute",

    width: "100%",
    height: "42%",
    //   resizeMode: 'center',
  },

  MyprofileText: {
    fontSize: moderateScale(19),
    color: "#FFFFFF",
    fontFamily: FONTS.PoppinsSemiBold,
    marginLeft: verticalScale(10),
  },
  setstatusStyle: {
    color: "#FFFFFF",
    fontSize: moderateScale(14),
    fontFamily: FONTS.PoppinsRegular,
  },
  RadiologyStyle: {
    fontSize: moderateScale(11),
    color: "#FFFFFF",
    fontFamily: FONTS.PoppinsRegular,
    paddingTop:10,
   //textAlign:"center",
   paddingLeft:20,
   paddingRight:20,
  },
  gmailStyle: {
    fontSize: moderateScale(11),
    color: "#FFFFFF",
    fontFamily: FONTS.PoppinsRegular,
    marginTop: verticalScale(5),
  },
  adressStyle: {
    fontSize: scale(16),
    color: "#43686A",
    fontFamily: FONTS.PoppinsRegular,
    marginLeft: moderateScale(5),
  },
  overViewStyle: {
    fontSize: scale(16),
    color: "#43686A",
    fontFamily: FONTS.PoppinsSemiBold,
    marginTop: verticalScale(8),
  },
  followtext:
  {color:'#E6E6E6',textAlign:'center',fontSize:17},
  followtextlabel:
  {color:'#8C8D91',textAlign:'center',fontSize:12},
  label:
  {
    color:'#FFFFFF',
    paddingLeft:6
  },
  rowview:
  {
    flexDirection:'row',
    justifyContent:'center',
    alignContent:"center",
    alignItems:'center'
  },
  backgroundVideo: {
    width:"100%",
    height:153,
  //  borderRadius:50
  borderRadius: moderateScale(15),
  //margin:10,
 // marginTop:7,
  //backgroundColor:"white"
    // alignItems: "center",
   //   position: "absolute",
   //  height: 300,
   //   left: 0,
   //   top: 0,
   //   right: 0,
   //   bottom: 0,
 },
    
   
});
