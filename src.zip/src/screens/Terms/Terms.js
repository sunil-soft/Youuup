
import axios from "axios";
import { useEffect, useState } from "react";
import { ActivityIndicator, ImageBackground, StatusBar, View } from "react-native";
import { KeyboardAwareScrollView } from 'react-native-keyboard-aware-scroll-view';
import RenderHtml from 'react-native-render-html';
import { Header } from "../../components/Header";
import { styles } from "./TermsStyles";
const tagsStyles = {
  body: {
    whiteSpace: 'normal',
    color: 'white'
  },
  a: {
  //  color: 'green'
  }
};
const Terms = (props) => {
  const [animating, setAnimating] = useState(false);
  const [termsdata, settermsdata] = useState('');
  useEffect(() => {
    setAnimating(true)
      axios({
        url: "https://youuup.es/mobile-api/managepages/pages-list",
        method: "GET",
        headers: {
          Accept: "application/json",
         // Authorization: "Bearer " + datatoken,
        },
      })
        .then((response) => {
          setAnimating(false)
           console.log(response.data.result)
           var index = response.data.result.findIndex(img => img.page_url == 'termsofuse');
        // console.log()
         settermsdata(response.data.result[index].page_description)
           
          // if (response.data?.paymentStatus == false) {
          //   navigation.navigate(NAVIGATION.Membership)

          // }
          // setpaymentStatus(response.data?.paymentStatus)


        })
        .catch(function (error) {
          setAnimating(false)
          console.log("error", error);
        });
   
  }, []);
  const sourcehtml = {
    html: "<div><p style='color:white;'>"+termsdata+"</p></div>"
  
  };
  return (
    <ImageBackground
      style={{ flex: 1, }}
      resizeMode={"stretch"}
      
      source={require("../../assets/images/editprofileback.png")}
    >
      <StatusBar translucent backgroundColor="transparent" />
      <Header back={true} {...props} title='Condiciones de uso' />
      <KeyboardAwareScrollView>
        <View style={styles.mainContainer}>
          <View style={{ marginTop: 100, marginLeft: 20, marginRight: 7 }}>
            {/* <Text style={{ color: 'white', fontFamily: FONTS.PoppinsRegular, fontSize: 14 }}>
              Condiciones de uso{`\n`}
              El acceso y registro a Youuup en adelante, sitio Web/app, es libre y gratuito siempre que el usuario particular y/o creador de contenido acepte las condiciones de uso que se le muestren al entrar según la legislación vigente.{`\n`}
              Youuup se reserva el derecho de ofrecer sus servicios previo pago de cantidad económica fija y/o cuotas establecidas ó a establecer según se precise en el momento por Youuup con información previa, consentimiento y aceptación del propio usuario particular y/o creador de contenido, siendo libre de aceptar o rechazar, utilizar o seguir utilizando la aplicación Youuup en el presente o en el futuro.{`\n`}
              Si el usuario particular y/o creador de contenido se suscribe a cualquier servicio del Sitio Web/app lo hará aceptando las Condiciones de Uso y Política de Privacidad y Cookies que se le mostrarán.{`\n`}
              Las cookies son datos que se almacenan automáticamente y sin ser datos determinantes, al navegar se van a registrar las cookies de navegación, dando su consentimiento.{`\n`}
              Derecho cancelación, devolución y reembolso antes de 14 días hábiles en:{`\n`}
              <Text onPress={() => Linking.openURL('mailto:Info@bobili-bobili-solutions.com')}>Info@bobili-bobili-solutions.com{`\n`}</Text>
              Cancelación, modificación, eliminación de privacidad de datos en:{`\n`}
              <Text onPress={() => Linking.openURL('mailto:Info@bobili-bobili-solutions.com')}>Info@bobili-bobili-solutions.com{`\n`}</Text>
              Incluido en el pago de membresía por el uso de los servicios web/app, el 21 % de impuestos sobre el valor añadido (IVA).{`\n`}
              Lea y entienda que aceptando el pago de membresía usted está de acuerdo con las condiciones de uso del sitio web/app y la política de privacidad y que ha leído y entendido las condiciones.{`\n`}
              Veracidad de los datos{`\n`}
              El usuario particular y/o creador de contenido, reconoce que los datos suministrados son veraces y ciertos, comprometiéndose a notificar cualquier cambio o modificación que se produjera en los mismos.{`\n`}
              Modificación del servicio{`\n`}
              Youuup se reserva el derecho de modificar o eliminar los servicios que ofrece a través de la web/app.{`\n`}
              Características de la membresía{`\n`}
              Nombre del plan – Youuup app{`\n`}
              Características proporcionadas - La aplicación es gratuita durante 15 días naturales, al crear una nueva cuenta, después de eso, una vez que se haya actualizado la membresía, el creador de contenido podrá utilizar todos los servicios disponibles en Youuup, por un período de un mes completo. Sin permanencia.{`\n`}
              Los servicios al completo son gratuitos indefinidamente para los usuarios particulares.{`\n`}
              Precio único – 23 euros por mes. Sin permanencia ni otras comisiones.{`\n`}
              CLUF de aplicación con licencia - EULA{`\n`}
              <Text onPress={() => Linking.openURL('https://www.apple.com/legal/internet-services/itunes/dev/stdeula/')}>https://www.apple.com/legal/internet-services/itunes/dev/stdeula/{`\n`}</Text>
              Normas generales de uso:{`\n`}
              El Usuario particular y/o creador de contenido se obliga a utilizar este Sitio Web/app de forma diligente, correcta y respetuosa, en especial cuando publique opiniones y/o comentarios y/o contacte con otros usuarios y/o creadores de contenido.{`\n`}
              Asimismo, se obliga a un título meramente enunciativo a no realizar comentarios o acciones:{`\n`}
              Difamatorios, inexactos, falsos, abusivos, injuriosos, obscenos, irreverentes, ofensivos, insultantes, tácita o expresamente sexuales, amenazantes, acosadores, racistas, sexistas, discriminatorios por cualquier motivo , que atenten contra la moral, el orden público, los derechos fundamentales, la libertad pública, el honor, la intimidad o la imagen de terceros y en general la normativa vigente, y/o ilegales o infractores de derechos de terceros (por ejemplo, derechos de propiedad industrial e intelectual; derechos de privacidad o publicidad).{`\n`}
              Transmisores de correo basura, “SPAM”, mensajes con multas comerciales, “cartas en cadena” o mailings masivos no solicitados, falsos, engañosos o promuevan actividades ilegales o conducta grosera, amenazante, obscena, difamatoria o injuriosa.{`\n`}
              Que suministren información práctica sobre actividades ilegales.{`\n`}
              Que contengan datos de carácter personal sobre terceras personas que requieran el consentimiento del propietario o titular de los derechos.{`\n`}
              El Usuario particular y/o creador de contenido responderá frente a Sitio Web/app o frente a cualquier tercero, de daños y perjuicios que podrían causarse como consecuencia del incumplimiento de dicha obligación. Youuup no interviene los contenidos de los Usuarios particulares ni creadores de contenido.{`\n`}
              El contenido audio visual digital (vídeos) debe ser respetuoso, no ofensivo y de carácter transigente.{`\n`}
              Quedarán prohibidos los actos vandálicos, violentos o que inciten a la violencia.{`\n`}
              Quedará prohibida la publicación y reproducción de vídeos que tengan contenido de audio o visual de marca si no se tiene el permiso explícito de la marca o no es propiedad o propietario de la misma o de su contenido.{`\n`}
              Quedará prohibido la publicación y reproducción de vídeos de carácter o contenido sexual o porno gráfico en todo su amplio sentido conceptual y visual.{`\n`}
              Quedará prohibido la publicación y reproducción de vídeos con menores de edad si no hay una aceptación explícita de los tutores legales de dichos menores para publicación de esas imágenes o audios.{`\n`}
              Quedará prohibido la publicación y reproducción de vídeos que contengan o inciten al racismo.{`\n`}
              Quedará prohibido la publicación y reproducción de vídeos que contengan o inciten a la vulneración de cualquiera de los derechos humanos como se entienden y reconocen en un estado de derecho y sociedad que vivimos.{`\n`}
              Todo vídeo que sea publicado o reproducido que altere lo más mínimo las prohibiciones anteriores y las que se enumeran y marcan en política de privacidad y con ediciones de uso, serán eliminados sin previo aviso ni explicación y los perfiles que lo publiquen o promocionen serán Bloqueados sin objeciones ni derecho a réplica.{`\n`}
              Propiedad intelectual
              Mediante estas condiciones legales no se cede ningún derecho de propiedad intelectual o industrial sobre Youuup app y sus contenidos (fotografías, vídeos, creaciones, textos,...). Quedando expresamente prohibido al usuario la reproducción, transformación, distribución, comunicación pública, puesta a disposición, extracción, reutilización, reenvío o la utilización de cualquier naturaleza, por cualquier medio o procedimiento, de cualquiera de ellos, salvo en los casos en que esté legalmente permitido o autorizado por el titular de los correspondientes derechos.{`\n`}
              Obligaciones de Sitio Web/app{`\n`}
              Sitio Web/app es responsable de los servicios que presta por ella misma y de los contenidos directamente originados por la propia web/app e identificados con su correspondiente copyright.{`\n`}
              Youuup es una plataforma en formato app, enfocada al sector de servicios y entretenimiento.{`\n`}
              Youuup La aplicación para crear compartir y disfrutar de contenido real.{`\n`}
              Youuup no ofrece servicios directos de profesionales de servicios ni creadores de contenido, dejando claro que ningún profesional de Youuup ni ningún creador de contenido pertenece al equipo y/o empresa de Bobili-Bobili Solutions S.L.{`\n`}
              Sitio Web/app adoptará las medidas necesarias que permitan garantizar la seguridad y privacidad en las comunicaciones.{`\n`}
              Sitio Web/app se reserva el derecho a suspender temporalmente la prestación del servicio sin previo aviso al usuario particular y/o creador de contenido, siempre y cuando sea necesario para realizar operaciones de mantenimiento, actualización o mejora del servicio.{`\n`}
              Youuup se reserva el derecho a suspender la prestación del servicio gratuito sin previo aviso al usuario particular.{`\n`}
              Youuup se reserva el derecho a suspender la prestación del servicio de pago sin previa justificación al creador de contenido, dando un plazo máximo de 3 meses de servicio al usuario particular y creador de contenido, previo aviso hasta la finalización total y cierre de los servicios de Youuup app.{`\n`}
              Sitio Web/app no puede asegurar la disponibilidad y continuidad permanente del servicio Youuup debido a interrupciones, fallas, etc.{`\n`}
              En Bobili-Bobili Solutions S.L. Brindamos oportunidades personalizadas para crear, conectar, comunicarse, descubrir y compartir.{`\n`}
              Convencidos que cada persona es distinta, en nuestro esfuerzo por contribuir a fortalecer tus relaciones, queremos hacerlo por medio de experiencias compartidas que te interesen. Con esta finalidad, creamos sistemas y desarrollos cuyo objetivo es intentar definir qué cosas y personas os interesan a ti y a otros, a fin de utilizar esa información para ayudarte a crear, encontrar y compartir experiencias que te sean relevantes, como también unirte a ellas. Parte de este proceso conlleva destacar contenido, funciones, ofertas y perfiles que podrían interesarte, así como ofrecerte formas de experimentar, en función de lo que tú y otras personas hacéis tanto dentro como fuera de la Web/app.{`\n`}
              En Bobili-Bobili Solutions pretendemos que nuestro servicio sea lo más inclusivo y abierto posible, pero también que sea seguro y conforme a la ley. Por este motivo, si quieres formar parte de la app Youuup, es necesario que aceptes algunas restricciones:{`\n`}
              Debes tener al menos 18 años, edad mínima legal en España.{`\n`}
              No debe tener antecedentes que indiquen que se te ha prohibido utilizar algún aspecto de nuestro Servicio en virtud de la legislación aplicable o usar servicios relacionados con los pagos si aparece en una lista de personas o empresas con las que el comercio está prohibido o restringido.{`\n`}
              Tu cuenta no debe estar inhabilitado anteriormente a causa de una infracción de la ley o de cualquiera de nuestras políticas.{`\n`}
              No puedes haber sido condenado por delitos sexuales.{`\n`}
              No suplantes a otras personas ni proporciones información incorrecta.{`\n`}
              Aunque no es necesario que reveles tu identidad, debes facilitarnos información precisa y actualizada (incluidos los detalles de registro), que puede englobar ciertos datos personales. Asimismo, no puedes suplantar a ninguna otra persona o entidad ni crear una cuenta en nombre de otro usuario (a menos que cuentes con su permiso expreso).{`\n`}
              No realice actividades ilegales, engañosas o fraudulentas, ni con multas ilegales o no autorizadas.{`\n`}
              No puedes infringir estas Condiciones ni nuestras políticas (ni ayudar o animar a otras personas a hacerlo).{`\n`}
              Si publicas contenido de marca, debes cumplir nuestras Políticas de contenido de marca, en las que se indica la marca claramente debes ser propietario de dicha marca o tener permiso del propietario.{`\n`}
              Puede obtener información sobre cómo denunciar contenido o comportamientos inapropiados en nuestro servicio de "denuncia perfil"{`\n`}
              No realiza ninguna acción que interfiera con el Servicio o impida que funcione como está previsto.{`\n`}
              Dichas acciones incluyen el uso indebido de cualquier canal de denuncia, reclamación o apelación (por ejemplo, la interposición de denuncias o apelaciones fraudulentas o carentes de fundamento).{`\n`}
              Obligaciones del usuario particular y creador de contenido{`\n`}
              El usuario particular se obliga personalmente a no difamar a otros particulares y/o profesionales creadores de contenido, pudiendo caer en un delito de injurias y difamaciones y pudiera ser objeto de alguna acción legal por parte de otro usuario particular y/o profesional/creador de contenido, en este caso Youuup web/app pondrá a su disposición los requisitos que sean necesarios y solicitados por los propios usuarios particulares o profesionales/creadores de contenido que lo precisen.
              El usuario particular y/o publicitado se obliga personalmente a satisfacer los requisitos económicos que hayan sido fruto de cualquier servicio por parte de un profesional/creador de contenido que hayan contratado personal y fehacientemente.
              El profesional/creador de contenido se obliga personalmente a no difamar a otros particulares y/o creadores de contenido, pudiendo caer en un delito de injurias y difamaciones y pudiera ser objeto de alguna acción legal por parte de otro usuario particular y/o creador de contenido, en este caso Youuup web/app pondrá a su disposición los requisitos que sean necesarios y solicitados por los propios usuarios particulares o profesionales/creadores de contenido que lo precisen.
              El profesional/creador de contenido se obliga personalmente a satisfacer los requisitos económicos o de servicio que hayan sido fruto de cualquier servicio por parte de un usuario particular o profesional/creador de contenido y/o publicitado, de los que hayan sido contratados personal y fehacientemente.
              Youuup no entra ni entrará en los tratos y conversaciones que existan entre usuarios particulares y profesionales/creadores de contenido o entre creadores
              de contenido o entre publicitados y creadores de contenido.{`\n`}
              Youuup no tiene comisión ni actuación alguna económica entre usuarios particulares y profesionales/creadores de contenido y entre profesionales/creadores de contenido y entre publitados y creadores de contenido.
              Consideramos como usuario particular aquella persona mayor de 18 años que puede abrir cuenta de perfil y podrá visualizar vídeos e interactuar en ellos y entre otros perfiles, pero no podrá crear ni publicar contenido digital alguno en Youuup app.
              Consideramos como Creador de contenido/profesional aquella persona mayor de 18 años que puede abrir cuenta de perfil y podrá visualizar vídeos e interactuar en ellos y entre otros perfiles, y también podrá crear y publicar contenido digital en Youuup app. Así mismo podrá tratar y contratar directamente las colaboraciones publicitarias y/o divulgativas que les sean solicitadas por otros usuarios particulares y/o usuarios de marca.
              Consideramos como Usuario de Marca y publicitado,(y tratado como usuario particular) aquella persona, entidad o empresa, cuyo representante legal y de la cuenta de Youuup, sea mayor de 18 años que puede abrir cuenta de perfil y podrá visualizar vídeos e interactuar en ellos y entre otros perfiles, pero no podrá crear ni publicar contenido digital alguno en Youuup app.Asi mismo podrá pedir y contratar colaboraciones de carácter publicitario y/o divulgativo directamente con creadores de contenido dentro de Youuup app.
              El Usuario particular y/o Creador de contenido pueden hacer servir su derecho a eliminación de cuenta en Youuup app de inmediato, utilizando la sección de " eliminar cuenta " que encontrará en en el aparato de Menú de ajustes.
              Bobili-Bobili Solutions S.L es la propietaria de Youuup app y Youuup es una marca de Bobili-Bobili Solutions S.L y como tal están reservados todos los derechos de propiedad intelectual, comercial, de explotación y consumo. Mediante Copyright © y creative commons ©©
              En Youuup app esta reservado el derecho de admisión para cualquier usuario particular y/o creador de contenido. Pudiendo ejercer Youuup el derecho de eliminación directa e inminente de la cuenta sin previo aviso (pudiendo pedir explicaciones de lo acontecido vía email a <Text onPress={() => Linking.openURL('mailto:Info@youuup.com')}>Info@youuup.com</Text>) a cualquier usuario particular y/o creador de contenido.
              La descarga, registro y utilización de Youuup app por parte de usuarios particulares es de origen, manera y número en cantidad indefinido. Bajo derecho reservado de admisión.
              La descarga, registro y utilización de Youuup app por parte de creadores de contenido es de origen, manera y número en cantidad definida y determinada.Youuup tiene un número predeterminado de registros.Solo están los mejores. Bajo derecho reservado de admisión.
              Youuup es de carácter y uso prural y mundial.{`\n`}
              Youuup es una plataforma en formato aplicación móvil para los sistemas, android e ios, dedicada a entretener, divertir, formar e informar a la gente, a través de contenido audiovisual real. Nuestra misión es brindar una experiencia única a nuestros usuarios, ofreciendo contenido variado y de calidad, en distintas áreas de interés, por creadores de contenido audiovisual (CCA). Desde entretenimiento y humor, hasta noticias y educación, con promociones y colaboraciones reales. En Youuup encontrarás lo que estás buscando y mucho más. Nos esforzamos por ser una fuente confiable y objetiva de información, mientras que también nos aseguramos de mantener una atmósfera divertida y agradable para nuestros usuarios. Unete a nosotros y descubre todo lo que Youuup tiene para ofrecer al mundo y a tí en especial.
              Los creadores de contenido son selectos y determinados, sólo éstan los mejores. Youuup app es diferente y no habrás visto nada igual.
              Estudio, desarrollo y puesta en servicio de Youuup app a cargo de Bobili-Bobili Solutions S.L.{`\n`}

            </Text> */}
     <RenderHtml
     // contentWidth={500}
     customHTMLElementModels
      source={sourcehtml}
      tagsStyles={tagsStyles}
    />  
          </View>
        </View>
        {animating == true && (
          <ActivityIndicator
            animating
            color={'white'}
            size="large"
            style={styles.activityIndicator}
          />
        )}
      </KeyboardAwareScrollView>
    </ImageBackground>
  );
};

export default Terms;
