import { FONTS } from "@/theme/fonts";
import { useEffect, useState } from "react";
import { ActivityIndicator, FlatList, Image, ImageBackground, StatusBar, Text, View } from "react-native";
import { KeyboardAwareScrollView } from 'react-native-keyboard-aware-scroll-view';
import { useDispatch, useSelector } from "react-redux";
import { Reportedlistapi } from "../../actions/UserActions";
import { Header } from "../../components/Header";
import { moderateScale } from "../../helper/Scale";
import { getUser } from "../../selectors/UserSelectors";
import { styles } from "./Reportliststyles";

const APIBASEURL = 'https://youuup.es/mobile-api/'

const Reportlist = (props) => {
  const dispatch = useDispatch();
  const { navigation, route } = props;
  const user = useSelector(getUser);
  //const { usernameshow,creater_id,tabactivestatus } = route.params;

  const [animating, setAnimating] = useState(false);
  // const [activetab, setactivetab] = useState(tabactivestatus==1?2:1);
  //const [activestatus, setactivestatus] = useState(2);


  // useFocusEffect(
  //   React.useCallback(() => {
  //     const unsubscribe = followerlist(tabactivestatus);

  //     return () => unsubscribe;
  //   }, [])
  // );


  const reportUserList = () => {
    dispatch(Reportedlistapi());
  };
  useEffect(() => {
    console.log('fgf', user && user.ReportList)
    reportUserList()
  }, []);


  return (
    <ImageBackground
      style={{ flex: 1, }}
     resizeMode={"stretch"}
     backgroundColor={'black'}
      // source={require("../../assets/images/editprofileback.png")}
      source={require("../../assets/splash/bg.png")}
    >
      <StatusBar translucent backgroundColor="transparent" />
      <Header back={true} {...props} title={'Denunciado'} />
      {/* {showModal && <PopUp />} */}
      <KeyboardAwareScrollView>
        <View style={styles.mainContainer}>
          <View style={{ backgroundColor: "#2A2A2A", height: 0.5, marginTop: 60, width: '90%', justifyContent: 'center', alignSelf: 'center' }}></View>
          {user?.ReportList?.length > 0 ?
            <FlatList
              data={user && user.ReportList}
              renderItem={({ item }) =>
                <View style={{ marginTop: 10, flexDirection: "row", marginLeft: 15, marginRight: 15, alignContent: 'center', alignItems: 'center' }}>
                  <View style={{ width: '20%' }}>
                    {/* <Image style={{width:56,height:56,borderRadius:50}} source={{uri:item.profile_photo}} /> */}
                    {item?.profile_photo ?
                      <Image style={{ width: 60, height: 60, borderRadius: 50 }}
                        source={{ uri: APIBASEURL + item.profile_photo }}
                      />
                      :
                      <Image style={{ width: 60, height: 60, borderRadius: 50 }}
                        source={require("../../assets/images/defaultuser.png")}
                      />
                    }
                  </View>
                  <View style={{ width: '44%', marginLeft: 3 }}>
                    <View>
                      <Text style={{ color: '#08DDFD', fontSize: moderateScale(14), fontWeight: "600", fontFamily: FONTS.PoppinsMedium }}>{item.name}</Text>
                    </View>
                  </View>

                </View>
              }
              keyExtractor={item => item.id}
            />
            :
            <View style={{ justifyContent: "center", alignContent: 'center', alignItems: 'center', marginTop: 40 }}>
              <Text style={{ color: 'white' }}>
                No hay resultados
              </Text>
            </View>
          }
        </View>
        {animating == true && (
          <ActivityIndicator
            animating
            color={'black'}
            size="large"
            style={styles.activityIndicator}
          />
        )}
      </KeyboardAwareScrollView>
    </ImageBackground>
  );
};

export default Reportlist;
