import { goBack } from '@/navigation/NavigationRef';
import AsyncStorage from '@react-native-async-storage/async-storage';
import axios from "axios";
import { useEffect, useState } from "react";
import { Image, ImageBackground, StatusBar, Text, TextInput, View } from "react-native";
import { Dropdown } from 'react-native-element-dropdown';
import { showMessage } from "react-native-flash-message";
import { moderateScale } from "react-native-size-matters";
import { useDispatch, useSelector } from "react-redux";
import { logout } from "../../actions/UserActions";
import { Button } from "../../components/Button";
import { Header } from "../../components/Header";
import { verticalScale } from "../../helper/Scale";
import { getUser } from "../../selectors/UserSelectors";
import { styles } from "./Reportvideo_addstyles";
//const APIBASEURL = 'http://103.15.67.180:4006/'
const APIBASEURL = 'https://youuup.es/mobile-api/'


const Reportvideo_add = (props) => {

  
  const dispatch = useDispatch();
  const { navigation, route } = props;
  const user = useSelector(getUser);


  const { video_id,report_to_id,previous_screen,callbycommentfun } = route.params;

  const [commentreport, setcommentreport] = useState("");
  const [commentlist, setcommentlist] = useState([]);
  const [animating, setAnimating] = useState(false);
  const [btndisabled, setbtndisabled] = useState(false);
  const [isFocus, setIsFocus] = useState(false);
  const [selectedSite, setSelectedSite] = useState(null);
  const [siteList, setSiteList] = useState(
    [
    { label: "Contenido sexual", value: "Contenido sexual" },
    { label: "Contenido violento o repulsivo", value: "Contenido violento o repulsivo" },
    { label: "Contenido que incite al odio o abusivo", value: "Contenido que incite al odio o abusivo" },
    { label: "Acoso o intimidación", value: "Acoso o intimidación" },
    { label: "Actos nocivos o peligrosos", value: "Actos nocivos o peligrosos" },
    { label: "Desinformación", value: "Desinformación" },
    { label: "Abuso infantil", value: "Abuso infantil" },
    { label: "Promueve el terrorismo", value: "Promueve el terrorismo" },
    { label: "Spam o engañoso", value: "Spam o engañoso" },
    { label: "Cuestión jurídica", value: "Cuestión jurídica" },
    { label: "Problema de subtítulos", value: "Problema de subtítulos" }
  
  ]

    );


  useEffect(() => {
   // commentlistapi(video_id)
  
  }, []);

 
  const commentlistapi = (video_id) => {
    AsyncStorage.getItem('auth_token').then(async (datatoken) => {
      if (datatoken) {
        axios({
          url: APIBASEURL + "video/video-comments",

          method: "POST",

          data: { "video_id": video_id },

          headers: {
            //  "Content-Type": "",
            Accept: "application/json",
            Authorization: "Bearer " + datatoken,
          },
        })
          .then((response) => {
            console.log(response.data.videoComments)
            setcommentlist(response.data.videoComments);
          })
          .catch(function (error) {
            if(error?.response?.data?.message=='Unauthorized')
            {
           
             dispatch(logout());
            }
            console.log("error", error);
          });
      }
    });

  };


  const sendreport = async () => {

    AsyncStorage.getItem('auth_token').then(async (datatoken) => {
      axios({
        url: APIBASEURL + "report/report-video",

        method: "POST",
       
        data: { "report_to_id":report_to_id,"video_id": video_id, report_description: commentreport,report_reason:selectedSite },

        headers: {
          //  "Content-Type": "",
          Accept: "application/json",
          Authorization: "Bearer " + datatoken,
        },
      })
        .then((response) => {
          console.log('response',response)
          setcommentreport('');
          goBack();
          // commentlistapi(video_id)
          // setbtndisabled(false)
          // callbycommentfun(video_id)
          //  setcommentlist(response.data.videos);

        })
        .catch(function (error) {

          console.log("error", error.response)

        });
    });

    //console.log(data)
    //dispatch(editprofileapi(data));
  };
  const Validation2 = () => {
    
    if (!selectedSite) {
      showMessage({
        message: "Por favor seleccione razón",
        type: "danger",
      });
    }
    else if (!commentreport.trim()) {
      showMessage({
        message: "Por favor Ingrese el mensaje de informe",
        type: "danger",
      });
    }
     
    else {
      // setbtndisabled(true)
      sendreport();
      //setShowModal(true);
      // props.navigation.navigate("EditUserDetail");
    }
  };
  const addreportsave = () => {

 
    // console.log({"follow_to_id":follow_to_id,"follow_status":status==true?2:1})
    AsyncStorage.getItem('auth_token').then(async (datatoken) => {
      console.log(datatoken)
      axios({
        url: Apiurl + "report/report-user",
        method: "POST",
        data: { "report_to_id": creater_id, "report_message": commentreport },
        headers: {
          Accept: "application/json",
          Authorization: "Bearer " + datatoken,
        },
      })
        .then((response) => {
          console.log('response', response)
     //     setShowModal(false)

        })
        .catch(function (error) {
          console.log("error11", error);
          if(error?.response?.data?.message=='Unauthorized')
          {
         
          // dispatch(logout());
          }
        });
    });
  };

  return (
    <ImageBackground
      style={{ flex: 1, }}
      resizeMode={"stretch"}
      backgroundColor={'black'}
      source={require("../../assets/images/editprofileback.png")}
    >

      <StatusBar translucent backgroundColor="transparent" />
      <Header back={true} {...props} title='Denunciar vídeo' />
      {/* {showModal && <PopUp />} */}
      <View style={styles.mainContainer}>

         <Text style={styles.placeNameTextStyle}>Seleccionar motivo de denuncia</Text>
            <View
                style={{
               
                //width:'90%',
                //backgroundColor: "#08DDFD",
                backgroundColor: "white",

                // opacity:isFocus   ? 0.5 : 0.09,
                zIndex: 1000,
                borderRadius: moderateScale(15),
                marginBottom: 20,
                borderRadius: 25,
                height: 60,
                //   alignItems:'center',
                justifyContent: 'center',
                alignContent: 'center',

                marginLeft: 20,
                 marginRight: 20
              }}
            >
                 
              <Dropdown
                style={[styles.dropdown, isFocus && { borderWidth: 0 }]}
                placeholderStyle={styles.placeholderStyle}
                selectedTextStyle={styles.selectedTextStyle}
                inputSearchStyle={styles.inputSearchStyle}
                itemTextStyle={{color:'black'}}
                iconStyle={styles.iconStyle}
                containerStyle={{
                  bottom: verticalScale(25),
                }}
                data={siteList}
                search
                maxHeight={300}
                labelField="label"
                valueField="value"
              //  placeholder={!isFocus ? '' : ''}
              placeholder="Seleccionar motivo de denuncia"
                searchPlaceholder="Buscar..."
                value={selectedSite}
               // onFocus={() => setIsFocus(true)}
              //  onBlur={() => setIsFocus(false)}
                onChange={item => {
                  setSelectedSite(item.value);
                 // setIsFocus(false);
                }}
             
                renderRightIcon={() => (
                  <Image
                    style={{ marginTop: verticalScale(8) }}
                    source={require("../../assets/reg/downarrow.png")}
                  />
                )}
              />
            </View>
            <Text style={styles.placeNameTextStyle}>Ingrese el mensaje de informe</Text>
          <View style={{ paddingLeft: 20, paddingRight: 20}}>
        
             <TextInput
                //  ref={ref_input1}
                // ref={input => {
                //   this.nameOrId = input;
                // }}
                //value={report_message}
                numberOfLines={5}
                multiline={true}
                style={{backgroundColor:'white', borderColor: '#08DDFD', borderWidth: 1, borderRadius: 12, padding: 10 }}
                placeholder="Ingrese el mensaje de informe"
                // onBlur={handleInputSubmit(ev)}
                onChangeText={(text) => setcommentreport(text)}
                // onBlur={alert(4)}

                // onChangeText={text => { setreport_message(text) }} 

                textAlignVertical='top'
              />
        
        </View>
          <Button
             style={{marginTop:30}}
              onPress={Validation2}
              title={"Enviar"}
            />
      </View>
      {/* {animating == true && (
        <ActivityIndicator
          animating
          color={'black'}
          size="large"
          style={styles.activityIndicator}
        />
      )} */}
    </ImageBackground>
  );
};

export default Reportvideo_add;
