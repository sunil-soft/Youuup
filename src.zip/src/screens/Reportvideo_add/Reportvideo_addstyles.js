import { StyleSheet } from "react-native";
import { moderateScale } from "../../helper/Scale";
import { FONTS } from "../../theme/fonts";
export const styles = StyleSheet.create({
  dropdown: {
   // marginTop:20,
    height: 70,
    paddingHorizontal: 10,
    borderRadius:25,
    color:'white'
  },
  icon: {
    marginRight: 5,
  },
  label: {
    position: 'absolute',
    backgroundColor: 'white',
    left: 22,
    top: 8,
    zIndex: 999,
    paddingHorizontal: 8,
    fontSize: 14,
  },
  placeholderStyle: {
    fontSize: 16,
  },
  selectedTextStyle: {
    fontSize: 16,
    color:'black'
  },
  iconStyle: {
    width: 20,
    height: 20,
  },
  inputSearchStyle: {
    height: 40,
    fontSize: 16,
  },
  activityIndicator: {
    position: 'absolute',
    left: 0,
    right: 0,
    top: 50,
    bottom: 0,
    alignItems: 'center',
    justifyContent: 'center',
    zIndex: 9999,
  },
  placeNameTextStyle: {
    color: "white",
    fontSize: moderateScale(15),
    fontWeight:'400',
    fontFamily: FONTS.PoppinsRegular,
   marginLeft: moderateScale(20),
   marginBottom:10
   
  },
  mainContainer:
  {
    marginTop:100,
    flex:1,
    height:'100%',
    //backgroundColor:"red"
  },
  
});
