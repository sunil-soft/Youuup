import { useState } from "react";
import {
  Image, ImageBackground,
  StatusBar, Text,
  TouchableOpacity, View
} from "react-native";

import { geterror, getUser } from "@/selectors/UserSelectors";
import { showMessage } from "react-native-flash-message";
import { KeyboardAwareScrollView } from 'react-native-keyboard-aware-scroll-view';
import { useDispatch, useSelector } from "react-redux";
import { popupoff, resetpassword } from "../../actions/UserActions";
import { Button } from "../../components/Button";
import { Header } from "../../components/Header";
import { InputField } from "../../components/InputField";
import { verticalScale } from "../../helper/Scale";
import { TextStyles } from "../../theme/TextStyles";
import { styles } from "./ResetPassword.styles";

export function ResetPassword(props) {
  const { navigation, route } = props;
  const {dataroot} = route.params;

  const dispatch = useDispatch();
  const [email, setEmail] = useState("");
  const user = useSelector(getUser);
  const error = useSelector(geterror);
  const [showModal, setShowModal] = useState(true);
  
  const [secureText, setsecureText] = useState(true);
  const [secureText2, setsecureText2] = useState(true);
  const [isActiveviewstatus2, setisActiveviewstatus2] = useState(2);
  const [password2, setpassword2] = useState('');


  const [isActiveviewstatus, setisActiveviewstatus] = useState(2);
  const [password, setpassword] = useState('');

  
  const [radioButtonActive, SetRadioButtonActive] = useState(
  true
  );
  var validRegex =
  /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9-]+(?:\.[a-zA-Z0-9-]+)*$/;
  const HideModal = () => {
  //  setShowModal(false);
    dispatch(popupoff())
  };
  const Validation = () => {
    if (!password.trim()) {
      showMessage({
        message: "El campo de contraseña es obligatorio",
        type: "danger",
      });
    }
    else if (!password2.trim()) {
      showMessage({
        message: "El campo Confirmar contraseña es obligatorio",
        type: "danger",
      });
    }
    else if (password.trim()!=password2.trim()) {
      showMessage({
        message: "Ingrese la contraseña y confirme la misma contraseña.",
        type: "danger",
      });
    }
    
    
      else {
     resetpasswordauth();
      //setShowModal(true);
     // props.navigation.navigate("EditUserDetail");
    }
  };
  const resetpasswordauth = async () => {
    const data = {
      user_id: dataroot,
      password: password,
    };
    console.log(data)
    dispatch(resetpassword(data));
    
  };
  
  return (
    <ImageBackground
      style={{ flex: 1,  }}
      resizeMode={"stretch"}
      backgroundColor={'black'}
      source={require("../../assets/splash/bg.png")}
    >
      <StatusBar translucent backgroundColor="transparent" />
      <Header back={true} {...props} />
      <KeyboardAwareScrollView>
      <View style={{ marginTop: verticalScale(50), alignSelf: "center" }}>
        <Image resizeMode="center" source={require("../../assets/splash/Logo.png")} />
      </View>
      <View style={styles.loginContainer}>
        {/* <Text style={TextStyles.title}>Keep it Real</Text> */}
        {/* <Text style={TextStyles.light}>
        La aplicación para crear, compartir y disfrutar de contenido real.</Text> */}
       
        <Text style={[TextStyles.titlelogin,{marginTop:50}]}>Restablecer la contraseña </Text>
        <Text style={TextStyles.subtitle}>Crea una nueva contraseña.</Text>
       
        <Text style={TextStyles.titlereg}>
        Nueva contraseña*
         </Text>
            <View style={{flexDirection:'row',alignItems:"center",marginLeft:25}}>
        <InputField
          placeholderColor={"white"}
          placeholder={""}
          mainViewStyle={{ width: "95%" }}
          secureTextEntry={secureText}
          isActiveview={isActiveviewstatus}
          //title={"Email Address"}
          onChangeText={(text) => setpassword(text)}
        
          //defaultValue={"toprady876@gmail.com"}
         // icon={"email"}
          // color={"#05A1AB"}
        />
           <TouchableOpacity 
         onPress={()=> {setisActiveviewstatus(1), setsecureText(!secureText)}} 
            style={{position:'relative', zIndex:999999,right:30,padding:4}} >
           <Image source={secureText?require("../../assets/login/closeeye.png"):require("../../assets/login/openeye.png")} />
          </TouchableOpacity> 
          </View>
        
          <Text style={TextStyles.titlereg}>
          Confirmar nueva contraseña*
         </Text>
        <View style={{flexDirection:'row',alignItems:"center",marginLeft:25}}>
        <InputField
          placeholderColor={"white"}
          placeholder={""}
          mainViewStyle={{ width: "95%" }}
          secureTextEntry={secureText2}
          isActiveview={isActiveviewstatus2}
          //title={"Email Address"}
          onChangeText={(text) => setpassword2(text)}
        
          //defaultValue={"toprady876@gmail.com"}
         // icon={"email"}
          // color={"#05A1AB"}
        />
           <TouchableOpacity 
         onPress={()=> {setisActiveviewstatus2(1), setsecureText2(!secureText2)}} 
            style={{position:'relative', zIndex:999999,right:30,padding:4}} >
           <Image source={secureText2?require("../../assets/login/closeeye.png"):require("../../assets/login/openeye.png")} />
          </TouchableOpacity> 
          </View>
     
        <Button
          style={{ marginTop: verticalScale(10) }}
          onPress={Validation}
         // onPress={() => navigate(NAVIGATION.otp)}
          title={"Enviar"}
        />
       
      </View>
      </KeyboardAwareScrollView>
    </ImageBackground>
  );
}
export default ResetPassword;