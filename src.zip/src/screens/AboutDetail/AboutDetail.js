import axios from "axios";
import { useEffect, useState } from "react";
import { ActivityIndicator, ImageBackground, StatusBar, View } from "react-native";
import { KeyboardAwareScrollView } from 'react-native-keyboard-aware-scroll-view';
// import { WebView } from 'react-native-webview';
import RenderHtml from 'react-native-render-html';
import { Header } from "../../components/Header";
import { styles } from "./AboutDetailStyles";
const tagsStyles = {
  body: {
    whiteSpace: 'normal',
    color: 'white'
  },
  a: {
  //  color: 'green'
  }
};
const AboutDetail = (props) => {
  
  const [animating, setAnimating] = useState(false);
  const [aboutdata, setaboutdata] = useState('');
  useEffect(() => {
    setAnimating(true)
      axios({
        url: "https://youuup.es/mobile-api/managepages/pages-list",
        method: "GET",
        headers: {
          Accept: "application/json",
         // Authorization: "Bearer " + datatoken,
        },
      })
        .then((response) => {
          setAnimating(false)
           console.log(response.data.result)
           var index = response.data.result.findIndex(img => img.page_url == 'aboutus');
        // console.log()
           setaboutdata(response.data.result[index].page_description)
           
          // if (response.data?.paymentStatus == false) {
          //   navigation.navigate(NAVIGATION.Membership)

          // }
          // setpaymentStatus(response.data?.paymentStatus)


        })
        .catch(function (error) {
          setAnimating(false)
          console.log("error", error);
        });
   
  }, []);
  
const sourcehtml = {
  html: "<div><p style='color:white;'>"+aboutdata+"</p></div>"

};
  return (
    <ImageBackground
    style={{ flex: 1,  }}
    backgroundColor={'black'}
    resizeMode={"stretch"}
    source={require("../../assets/images/editprofileback.png")}
    >
    <StatusBar translucent backgroundColor="transparent" />
    <Header back={true} {...props} title='Sobre nosotras' />
    <KeyboardAwareScrollView>
    <View style={styles.mainContainer}>
    <View style={{marginTop:50,marginLeft:20,marginRight:7,}}>
   {/* <Text style={{color:'white',fontFamily:FONTS.PoppinsRegular,fontSize:14}}>
    Youuup es una plataforma en formato aplicación móvil para los sistemas, android e ios, dedicada a entretener, divertir, formar e informar a la gente, a través de contenido audiovisual real. Nuestra misión es brindar una experiencia única a nuestros usuarios, ofreciendo contenido variado y de calidad, en distintas áreas de interés, por creadores de contenido audiovisual (CCA). Desde entretenimiento y humor, hasta noticias y educación, con promociones y colaboraciones reales. En Youuup encontrarás lo que estás buscando y mucho más. Nos esforzamos por ser una fuente confiable y objetiva de información, mientras que también nos aseguramos de mantener una atmósfera divertida y agradable para nuestros usuarios. Unete a nosotros y descubre todo lo que Youuup tiene para ofrecer al mundo y a tí en especial.{`\n`}
Los creadores de contenido son selectos y determinados, sólo éstan los mejores. Youuup app es diferente y no habrás visto nada igual.{`\n`}
Estudio, desarrollo y puesta en servicio de Youuup app a cargo de Bobili-Bobili Solutions S.L.
    </Text>  */}
     <RenderHtml
     // contentWidth={500}
     customHTMLElementModels
      source={sourcehtml}
      tagsStyles={tagsStyles}
    />  
     {/* <WebView
      //  originWhitelist={['*']}
        source={{ html: '<h1>Hello world</h1>' }}
      />  */}
    </View>
    </View>
        {animating == true && (
         <ActivityIndicator
          animating
         color={'white'}
         size="large"
         style={styles.activityIndicator}
         />
         )} 
         </KeyboardAwareScrollView>
 </ImageBackground>
  );
};

export default AboutDetail;
