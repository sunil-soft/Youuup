import { Apiurl } from "@/constants/Apiurl";
import { FONTS } from "@/theme/fonts";
import { useFocusEffect } from "@react-navigation/native";
import axios from "axios";
import moment from 'moment/min/moment-with-locales';
import React from "react";

import AsyncStorage from '@react-native-async-storage/async-storage';
import { FlatList, Image, StatusBar, Text, TouchableOpacity, View } from "react-native";
import { showMessage } from "react-native-flash-message";
import { moderateScale, verticalScale } from "react-native-size-matters";
import { useDispatch, useSelector } from "react-redux";
import { favvideosapi } from "../../actions/UserActions";
import { Header } from "../../components/Header";
import { NAVIGATION } from "../../constants";
import { getUser } from "../../selectors/UserSelectors";
import { styles } from "./Favvideo.styles";

const Favvideo = (props) => {
  const dispatch = useDispatch();
  const user = useSelector(getUser);
  const { navigation, route } = props;


  // const userData = useSelector(getProfile);
  useFocusEffect(
    React.useCallback(() => {
      console.log('fdf',user && user?.favvideos)
     UserProfilee();
     // return () => unsubscribe;
    }, [])
  );
  const UserProfilee = () => {
    // dispatch(Myprofile());
    //   const data = {
    //     "user_id": user?.profileinfo?.id,
    //     "video_type": 1,
    //     "offset": 0,
    //     "limit": 5
    // };
    dispatch(favvideosapi());
  };
  const goredirect = (selfvideodata,index) => {
   // console.log(index)
    //  alert(JSON.stringify(selfvideodata))
    //  alert(JSON.stringify(index))
 
    //  navigation.goBack()
      navigation.replace(NAVIGATION.Selfvideolist,{selfvideodata: selfvideodata,startindex:index,screenbyfav:1})

   
    // dispatch(Myprofile());
    //   const data = {
    //     "user_id": user?.profileinfo?.id,
    //     "video_type": 1,
    //     "offset": 0,
    //     "limit": 5
    // };
    
  };
  const formatCash = (n) => {
    if (n < 1e3) return n;
    if (n >= 1e3 && n < 1e6) return +(n / 1e3).toFixed(1) + "K";
    if (n >= 1e6 && n < 1e9) return +(n / 1e6).toFixed(1) + "M";
    if (n >= 1e9 && n < 1e12) return +(n / 1e9).toFixed(1) + "B";
    if (n >= 1e12) return +(n / 1e12).toFixed(1) + "T";
  };
  const delete_fav = (id) => {
    AsyncStorage.getItem('auth_token').then(async (datatoken) => {
      if (datatoken) {
        axios({
          url: Apiurl + "video/favourite",
          method: "POST",
          data: { "video_id": id ,"favourite_status":2},
          headers: {
            Accept: "application/json",
            Authorization: "Bearer " + datatoken,
          },
        })
          .then((response) => {
           dispatch(favvideosapi());
            showMessage({
              message: "Borrado exitosamente.",
              type: "success",
            });
          
          })
          .catch(function (error) {
           console.log(error)

          });
      }

    });
  };
  return (
    // <ScrollView>
    <View style={{ flex: 1, backgroundColor: "#181A1B" }}>
      <Header {...props} midle={true} midtitle={'Favoritos'} />
      <StatusBar
        translucent
        barStyle="light-content"
        backgroundColor={"transparent"}
      />
      <View style={{ flex: 1, marginTop: 70, paddingLeft: verticalScale(10), paddingRight: verticalScale(10), width: '100%', flexDirection: 'row' }}>
        <View
          style={{
            marginTop: verticalScale(10),
            flexDirection: "row",
            width:"99%",
            marginRight:10,
            //backgroundColor:"red"
          }}
        >
         {/* <Text style={{color:'white'}}>{JSON.stringify(user.favvideos)}</Text> */}
          {
         
            user?.favvideos?.length > 0 ?
              <>
                {/* <Text style={{color:'white'}}>{JSON.stringify(user.favvideos)}</Text> */}
                <FlatList
                  data={user && user?.favvideos}
                  numColumns={3}
                 // keyExtractor={index}
                //  contentContainerStyle={{flex:3}}
                  renderItem={({ item,index }) =>
                <View style={{flex:1}}>
                  <View style={{width:"100%",  position:"absolute", zIndex:9999999,top:5,flexDirection:"row", justifyContent:"space-between",alignItems:'center',}}>
                 
                    
                     <View 
                    // onPress={() => deletenotify(item.id)} 
                     style={{padding:5, alignSelf:'flex-end',flexDirection:'row',alignItems:'center'}}
                     >
                       <Text style={{ fontSize: 12, paddingLeft: 8, color: '#08DDFD', fontFamily: FONTS.PoppinsRegular }}>{moment.utc(item.upload_date).local().startOf('seconds').fromNow(true)} </Text>
                     </View>
                     
                    <TouchableOpacity 
                     onPress={() => delete_fav(item.id)} 
                     style={{marginRight:7,marginTop:3}}
                    >
                     <Image
                      style={{height:24,width:24}}
                      source={require("../../assets/images/crossdelete.png")}
                      />
                     </TouchableOpacity>
                  </View>
                    <TouchableOpacity
                   //  onPress={()=>navigation.navigate(NAVIGATION.mainHome,{firstvideo_id:item.id})}
                  
                    onPress={()=> goredirect(user?.favvideos,index)}
                     //onPress={()=>navigation.navigate(NAVIGATION.Selfvideolist,{selfvideodata: user?.favvideos,startindex:index})}

                     style={{borderRadius: moderateScale(15), margin: 5, marginTop: 7, }}>
                     <View style={styles.backgroundVideo}> 
                      <Image
                     //  onPress={()=> goredirect(user?.favvideos,index)}
                     //  onPress={()=>navigation.navigate(NAVIGATION.Selfvideolist,{selfvideodata: user?.favvideos,startindex:index})}
                      // onPress={()=>navigation.navigate(NAVIGATION.mainHome,{firstvideo_id:item.id})}
                      //  onPress={()=>navigation.navigate(NAVIGATION.Selfvideolist,{selfvideodata:user && user.favvideos,startindex:index})}
                        style={{width:'100%',height:158,borderRadius:15}} source={ item?.video_thumbnail=='null'?require("../../assets/Home/New/videothumb.png"):{ uri:Apiurl + item?.video_thumbnail} }/>
                     </View>
                    </TouchableOpacity>
                    {item?.view_count>0 &&
                    <View style={{position:"absolute", zIndex:9999999,bottom:5,flexDirection:"row",justifyContent:"flex-start",marginLeft:15,marginRight:4,alignItems:'center'}}>
                    <View 
                   // onPress={() => deletenotify(item.id)} 
                  style={{ padding:5, alignSelf:'flex-end',right:5,flexDirection:'row',alignItems:'center'}}
                    >
                     <Image
                     // style={{height:18,width:18}}
                      source={require("../../assets/images/videoview.png")}
                      />
                      <Text style={{paddingTop:4, color:'white',paddingLeft:5,fontSize:12,fontFamily:FONTS.PoppinsRegular}}>{formatCash(item?.view_count)} </Text>
                    </View>
                
                    </View>
                  }
                  </View>
                  }
                />
              </>
              :
              <View style={{ width: "100%" }}>
                <Image resizeMode="center" style={{ alignSelf: 'center' }} source={require("../../assets/images/defaultimage.png")} />
              </View>
          }
        </View>
      </View>


    </View>
    // </ScrollView>
  );
};

export default Favvideo;
