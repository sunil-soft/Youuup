import { Dimensions, StatusBar, StyleSheet } from "react-native";
import styled from 'styled-components/native';
import { verticalScale } from "../../helper/Scale";
import { FONTS } from "../../theme/fonts";
export const styles = StyleSheet.create({
    backgroundVideo: {
        alignItems: "stretch",
        position: "absolute",
        height: Dimensions.get("window").height + StatusBar.currentHeight,
        left: 0,
        top: 0,
        right: 0,
        bottom: 0,
    },

    pagerView: {
        flex: 1,
    },
    container: {
        flex: 1,
        backgroundColor: 'black',
      //  paddingBottom:20
        // padding: 30,
        // justifyContent: 'center',
    },
    activityIndicator: {
        position: 'absolute',
        top: '50%',
        left: 70,
        right: 70,
        height: 50,
        alignItems: 'center',
        justifyContent: 'center',
    },
    modalView: {
        zIndex:99999999999999,
      //  flex: 1,
      //  backgroundColor: '#000000aa',
        padding: 20,
        justifyContent: 'center',
      },
      modalInnerView: {
        backgroundColor: 'white',
        borderRadius: 15,
        padding: verticalScale(20),
        paddingVertical: verticalScale(20),
      },
      modalTitleTxt: {
        fontFamily: FONTS.PoppinsSemiBold,
        color: '#43686A',
        fontSize: 20,
      },
      modalContentView: {
        // paddingRight: verticalScale(30),
        // borderBottomWidth: 2,
        // borderBottomColor: '#EBF0F1',
        // paddingVertical: verticalScale(0),
        paddingBottom:20,
      },
  
});

export const Container = styled.SafeAreaView`
    flex: 1;
    align-items: center;
    justify-content: center;
    background: red;
`;

export const NewsByFollowing = styled.View`
    position: absolute;
    left: 10%;
    right: 10%;
    top: 5%;
    z-index: 99;
    flex: 1;
    display: flex;
    align-items: center;
    justify-content: center;
`;

export const NewsByFollowingText = styled.Text`
    color: #FFF;
`;

export const NewsByFollowingTextBold = styled.Text`
    font-weight: bold;
    font-size: 15px;
    color: #FFF;
`;

export const ContentRight = styled.View`
    position: absolute;
    padding: 10px;
    right: 5px;
    top: 30%;
    bottom: 30%;
    z-index: 99;
    flex: 1;
    display: flex;
    align-items: center;
    justify-content: center;
`;

export const ContentRightUser = styled.TouchableOpacity`
    width: 40px;
    height: 40px;
    border-radius: 25px;
    background: red;
    margin-top: 10px;
    display: flex;
    align-items: center;
    justify-content: center;
    background: #555;
`;

export const ContentRightUserImage = styled.Image`
    width: 40px;
    height: 40px;
    border-radius: 25px;
`;

export const ContentRightUserPlus = styled.View`
    top: -10px;
    width: 20px;
    height: 20px;
    display: flex;
    align-items: center;
    justify-content: center;
    border-radius: 25px;
    background: #F00;
`;

export const ContentRightHeart = styled.TouchableOpacity`
    margin-top: 10px;
    margin-bottom: 10px;
    flex: 1;
    display: flex;
    align-items: center;
    justify-content: center;
`;

export const ContentRightComment = styled.TouchableOpacity`
    margin-top: 10px;
    margin-bottom: 10px;
    flex: 1;
    display: flex;
    align-items: center;
    justify-content: center;
`;

export const ContentRightWhatsApp = styled.TouchableOpacity`
    margin-top: 10px;
    margin-bottom: 10px;
    flex: 1;
    display: flex;
    align-items: center;
    justify-content: center;
`;

export const ContentRightWhatsAppImage = styled.Image`
   width: 30px;
   height: 30px;
`;

export const ContentRightText = styled.Text`
    margin-top: 10px;
    font-weight: bold;
    color: #FFF;
`;

export const ContentLeftBottom = styled.View`
    position: absolute;
    padding: 10px;
    left: 5px;
    bottom: 0%;
    z-index: 99;
    width: 99.5%;
    display: flex;
    align-items: flex-start;
    justify-content: center;
`;

export const ContentLeftBottomNameUser = styled.View`

`;
export const ContentLeftBottomNameUserText = styled.Text`
    color: #FFF;
    font-weight: bold;
`;

export const ContentLeftBottomDescription = styled.Text`
    margin-top: 10px;
    color: #FFF;
`;

export const ContentLeftBottomMusic = styled.Text`
    margin-top: 10px;
    color: #FFF;
    overflow: scroll;
`;
