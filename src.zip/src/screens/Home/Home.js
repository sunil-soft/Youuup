import { HeaderAuth } from "@/components";
import { FONTS } from "@/theme/fonts";
import { useFocusEffect } from "@react-navigation/native";
import React, { useEffect, useState } from 'react';
import { ActivityIndicator, AppState, Image, Linking, Modal, Platform, SafeAreaView, Share, Text, TextInput, View } from 'react-native';
import { TouchableOpacity } from "react-native-gesture-handler";
import PagerView from 'react-native-pager-view';
import Video from 'react-native-video';
import { useDispatch, useSelector } from "react-redux";
import { Header } from "../../components/Header";
import { getUser } from "../../selectors/UserSelectors";
//import { styles } from "./Home.Styles";
import { Apiurl } from "@/constants/Apiurl";
import AsyncStorage from '@react-native-async-storage/async-storage';
import axios from "axios";
import { logout } from "../../actions/UserActions";
import { NAVIGATION } from "../../constants";
import { ContentLeftBottom, ContentLeftBottomDescription, ContentLeftBottomNameUser, styles } from './styles';

export function Home(props) {
  const { navigation, route, } = props;
  const { firstvideo_id} = route.params || {};
  const dispatch = useDispatch();
  const user = useSelector(getUser);
  const [paused, setPaused] = useState(false);
  const [playindex, setplayindex] = useState(0);
  const [scrollToIndex, setScrollToIndex] = useState(0);
  const [videolist, setvideolist] = useState([]);
  const [activevideotype, setactivevideotype] = useState(0);
  const [pausetatus, setpausestatus] = useState(-1);
  const [offset, setoffset] = useState(0);
  const [tempposition, settempposition] = useState(1);
  const [showModal, setShowModal] = useState(false);
  const [comment, setcomment] = useState('');
  const [sharevideo_id, setsharevideo_id] = useState('');
  const [pageIndex, setPageIndex] = useState(0)
  const [showMore, setShowMore] = useState(false);
  const [showMore2, setShowMore2] = useState(false);
  //const [isplaying, setisplaying] = useState(false);
  const [currentdisplay, setcurrentdisplay] = useState(0);
  const [currentvideoindex, setcurrentvideoindex] = useState(0);
  const [clickstatus, setclick] = useState(0);
  const [opacity, setopacity] = useState(0);
  const videoPlayer = React.useRef(0);
  const ref = React.useRef(PagerView);
  const appState = React.useRef(AppState.currentState);
  const [appStateVisible, setAppStateVisible] = useState(appState.current);
  const [callbak, setcallback] = useState('');
  useFocusEffect(
    React.useCallback(() => {
     // alert(1)
  
    
      //console.log(44)
      
        if(firstvideo_id)
        {
       //  setvideolist([])
         setpausestatus(-1)
          setplayindex(0)
         setactivevideotype(0)
         videolistapi(activevideotype, offset, firstvideo_id)
         
        }
        else{
         // videolistapi(activevideotype, offset, null)
        // start(0)
        // setplayindex(0)
         }
      
      if (AppState.currentState == 'background') {
       
        setplayindex(-1)
       // setpausestatus(-1)
        setpausestatus(currentdisplay)
      }
      return () => {
     //   alert('ff'+currentdisplay)
        // setPaused(true)
        // setpausestatus(-1)
        // setplayindex(-1)
    }
    }, [])
  );
  useFocusEffect(
     React.useCallback(() => {
      //console.log(22)
   //  alert(22)
      const unsubscribe=getvideo();
       return () => unsubscribe;
    }, [firstvideo_id])
  );
  const onBuffer = (isBuffering,vid) => {
    //alert(4)
    // console.log('isbuff',isBuffering)
     console.log('vid',isBuffering)
    setopacity(isBuffering)
    if(vid!=null)
    {
    // Addviewcount(vid)
    }
    //this.setState({opacity: isBuffering ? 1 : 0});
}
  const getvideo = () => {
    console.log('get')
    console.log('fget',firstvideo_id)
   
       if(firstvideo_id)
       {
        setpausestatus(-1)
        setplayindex(0)
        setactivevideotype(0)
       //alert('firsget')
     //   setvideolist([])
        videolistapi(activevideotype, offset, firstvideo_id)
       }
       else{
       // start(scrollToIndex)
      //  setpausestatus(-1)
       // console.log('scrollToIndex',scrollToIndex)
       // start(playindex)
       // videolistapi(activevideotype, offset, null)
        }
        // alert(AppState.currentState)
        // alert(currentdisplay)
      if (AppState.currentState == 'background') {
        setplayindex(-1)
        //setpausestatus(-1)
        setpausestatus(currentdisplay)
      }
      // else{

      // }
      

  };
  useEffect(() => {
    // console.log('onlyone')
     videolistapi(activevideotype, offset, null)
     return () => {
     // alert('first'+currentdisplay)
  }
  
   }, []);
  useEffect(() => {
   // alert(44)
   // videolistapi(activevideotype, offset, null)
    const subscription = AppState.addEventListener('change', nextAppState => {
      appState.current = nextAppState;
      setAppStateVisible(appState.current);
      console.log('df',route)
      // const route = useRoute();
      
     // console.log('route',props.navigation.state.routeName);
      if (appState.current == 'background') {
        setplayindex(-1)
      //  setpausestatus(-1)
        setpausestatus(currentdisplay)
        setPaused(true)
      }
      if (appState.current == 'active') {
       // alert(appState.current)
        // setPaused(false)
        // setpausestatus(-1)
        // setplayindex(currentdisplay)
      }
      
    });

    return () => {
      // alert('fd')
     // AppState.removeEventListener('change')
      subscription.remove();
    };
  }, [currentdisplay]);

  const callstatusget = () => {
    if (AppState.currentState == 'background') {

      setplayindex(-1)
      //setpausestatus(-1)
      setpausestatus(currentdisplay)
      setPaused(true)
    }

  };

  // useEffect(() => {
  //   console.log('useEffect setPage '+pageIndex)
  //   viewPager.current?.setPage(pageIndex)
  // }, [pageIndex]);
  useEffect(() => {

    setplayindex(0)
    setactivevideotype(0)
    if (Platform.OS === 'android') {
      Linking.getInitialURL().then(url => {
        
        if(url)
        {
        //  alert(url)
        videolistapi(activevideotype, offset, url.split('/')[3])
        }
      });
    }
    return () => {
     
  }
  }, []);
  //Get Video List //
  const videolistapi = (video_type_status, offset, shavideo_id) => {
    AsyncStorage.getItem('auth_token').then(async (datatoken) => {
    //  console.log('f',shavideo_id ? { "video_type": video_type_status, "offset": offset, "limit": 40, "video_id": shavideo_id } : { "video_type": video_type_status, "offset": offset, "limit": 4 })
    // console.log(datatoken)
      if (datatoken) {
        axios({
          url: Apiurl + "video/video-by-logged-user",
          method: "POST",
          data: shavideo_id ? { "video_type": video_type_status, "offset": offset, "limit": 4, "video_id": shavideo_id } : { "video_type": video_type_status, "offset": offset, "limit": 4 },
          headers: {
            Accept: "application/json",
            Authorization: "Bearer " + datatoken,
          },
        })
          .then((response) => {
       //   alert(response) 
          //  console.log('videolistres',response.data) 
            if (AppState.currentState == 'background') {
              // console.log(AppState.currentState)
              callstatusget()
            }
            if (shavideo_id) {
              //console.log('shavideo_id',response) 
              setvideolist([])
              setvideolist(response.data.videos);
            }
            else {
            // console.log('videolist11',videolist) 
            // console.log('videolistresponse',response.data.videos) 
              //console.log('videolist',response.data.videos) 
             //if(videolist.length>0)
             // {
               // let newupdatearray=videolist
               // response.data.videos.map((item, i) => {
                 // console.log(item.id)
                //  console.log('newupdatearray',videolist) 
               //  console.log(item.id)
               // var foundIndex = videolist.findIndex(x => x.id == item.id);
             // console.log(foundIndex)
             // if(foundIndex!=-1)
             // {
             // console.log(videolist[foundIndex].follow_by_logged_user)   
             // videolist[foundIndex].follow_by_logged_user = item.follow_by_logged_user
              
               
             // }
            //  });
            //  console.log('newupdatearray',videolist)
            //  setTimeout(() => {

            //    let arraynew=[...videolist, ...response.data.videos]
            // console.log(arraynew)
            // videolist=arraynew
              // setvideolist(videolist => [...videolist, ...response.data.videos]);
          // setTimeout(() => {
                AsyncStorage.getItem('follow_to_id_user').then(async (follow_to_id) => {
               //  console.log("follow_to_id",follow_to_id)
                  if(follow_to_id!=null)
                 {
                  console.log("go")
                 AsyncStorage.getItem('follow_status').then(async (follow_status_data) => {
                 changefollow(follow_to_id,follow_status_data, [...videolist, ...response.data.videos])
                //  changefollow(follow_to_id,follow_status_data, response.data.videos)
                 })
                 }
                 else{
                 // alert(2)
                  console.log('v',videolist)
                 console.log('res',response.data.videos)
                 console.log('videolist',videolist)
                //if(videolist)
                if(response?.data?.videos)
                {
                  setvideolist(videolist => [...videolist, ...response?.data?.videos]);
                }
                }
               })
            //  }, 100);
                //   setvideolist(arraynew);
               

                //  }, 100);
             //}
             //else{
            //  setvideolist(response.data.videos);

            // }
            
           }


            // setvideolist(response.data.videos,...videolist)
          //  setvideolist(videolist => [...videolist, response.data.videos]);
            // setvideolist( [...videolist, response.data.videos]);
          })
          .catch(function (error) {

            console.log('msgerror',error?.response?.data?.message) 

            if(error?.response?.data?.message=='Unauthorized')
            {
           
             dispatch(logout());
            }
          
          });
      }
      else {
        axios({
          url: Apiurl + "video/get-all-video",

          method: "POST",

          data: { "video_type": video_type_status, "offset": offset, "limit": 4 },

          headers: {
            Accept: "application/json",
          },
        })
          .then((response) => {
            console.log('videolistresponse',response.data.videos) 
            if (AppState.currentState == 'background') {
              console.log(AppState.currentState)
              setplayindex(-1)
            }
            setvideolist(videolist => [...videolist, ...response.data.videos]);
          })
          .catch(function (error) {
            console.log("error", error);
          });
      }
    });
  };
  const videolistapicall = (video_type_status, offset, shavideo_id) => {
    AsyncStorage.getItem('auth_token').then(async (datatoken) => {
     // console.log('dfd',shavideo_id ? { "video_type": video_type_status, "offset": offset, "limit": 4, "video_id": shavideo_id } : { "video_type": video_type_status, "offset": offset, "limit": 4 })
    // console.log(datatoken)
      if (datatoken) {
        axios({
          url: Apiurl + "video/video-by-logged-user",
          method: "POST",
          data: shavideo_id ? { "video_type": video_type_status, "offset": offset, "limit": 4, "video_id": shavideo_id } : { "video_type": video_type_status, "offset": offset, "limit": 4 },
          headers: {
            Accept: "application/json",
            Authorization: "Bearer " + datatoken,
          },
        })
          .then((response) => {
            console.log('oldvideolistres',videolist) 
            console.log('videolistres',response.data) 
            if (AppState.currentState == 'background') {
              // console.log(AppState.currentState)
              callstatusget()
            }
            if (shavideo_id) {
              setvideolist(response.data.videos);
            }
            else {
         
               //setvideolist(videolist => [...videolist, ...response.data.videos]);
          // setTimeout(() => {
                AsyncStorage.getItem('follow_to_id_user').then(async (follow_to_id) => {
                // console.log(follow_to_id)
                  if(follow_to_id!=null)
                 {
                 AsyncStorage.getItem('follow_status').then(async (follow_status_data) => {
                  // console.log(follow_status_data)
                 changefollow(follow_to_id,follow_status_data, response.data.videos)
                 })
                 }
                 else{
                  setvideolist(response.data.videos);
                 }
               })
          
            
           }


            // setvideolist(response.data.videos,...videolist)
          //  setvideolist(videolist => [...videolist, response.data.videos]);
            // setvideolist( [...videolist, response.data.videos]);
          })
          .catch(function (error) {
            console.log('error',error) 
            if(error?.response?.data?.message=='Unauthorized')
            {
           
             dispatch(logout());
            }
            if (error?.response?.data?.error?.status) {
              //  dispatch(logout())  
            }
          });
      }
      else {
        axios({
          url: Apiurl + "video/get-all-video",

          method: "POST",

          data: { "video_type": video_type_status, "offset": offset, "limit": 4 },

          headers: {
            Accept: "application/json",
          },
        })
          .then((response) => {
            console.log('videolistresponse',response) 
            if (AppState.currentState == 'background') {
              console.log(AppState.currentState)
              setplayindex(-1)
            }
            setvideolist(videolist => [...videolist, ...response.data.videos]);
          })
          .catch(function (error) {
            console.log("error", error);
          });
      }
    });
  };

  const Addviewcount = (video_id) => {
        axios({
          url: Apiurl + "video/add-video-count",
          method: "POST",
          data: { "video_id": video_id },
          headers: {
            Accept: "application/json",
          },
        })
          .then((response) => {
            console.log('view response',response)
          })
          .catch(function (error) {
            console.log('error',error) 
          });
  };
  const pageOnScroll = (event) => {
    const { position } = event.nativeEvent;
    if (position !== scrollToIndex) {
      console.log(videoPlayer)

    // videoPlayer.play()
     // console.log('length1',videolist.length)
    //   console.log('length',videolist)
     // console.log('position', position)
      //setcurrentdisplay(position)
    //  console.log('b'+videolist?.length)
     // console.log('b',videolist?.length - 2)

    //  videoPlayer.current.forEach((ref, i) => {
    //   if (i !== index && ref) {
       // ref.pause(); // Pause video
       console.log('ff',position)
     //  videoPlayer.seek(0); // Reset video to the beginning
    //   }
    // });
    // Play the selected video
    //if (videoPlayer.current[position]) {
     // videoPlayer.current[position].play();
     // videoPlayer.current[position].seek(0);
   // }
     setShowMore(false)
     setShowMore2(false)
     start(position)
     setplayindex(position)
     setPageIndex(position)
   //  console.log('F',videolist[position].id)

console.log(videolist?.length - 2)
console.log(position)
      if (videolist?.length - 2 == position) {
        
       // alert('ff'+videolist?.length)
        videolistapi(activevideotype, videolist?.length, null)
        console.log('positionfix', position)
      }
       if (tempposition == 3) {
        // settempposition(1)
        // videolistapi(activevideotype,offset)
       }
       else {
          // settempposition(tempposition+1)
         }
     // setoffset(offset+1)
  
    }
    else {
      setplayindex(0)
    }
    setPaused(false)
  };
  const stop = (index) => {
    // alert(2)
    setplayindex(-1)
    setPaused(true)
    setpausestatus(index)
    // setTimeout(() => {
    //   setpausestatus(false)

    // }, 100);

  };
  const stop2 = (index) => {
    // alert(2)
    setplayindex(-1)
    setPaused(true)
    setpausestatus(-1)
    // setTimeout(() => {
    //   setpausestatus(false)

    // }, 100);

  };
  const stophard = () => {
    setplayindex(-1)
    setPaused(true)
    setpausestatus(true)
    setpausestatus(false)
    // setTimeout(() => {
    //   setpausestatus(false)

    // }, 100);

  };
  const start = (index) => {
    setplayindex(index)
    setPaused(false)
    setpausestatus(-1)
    // setplaystatus(true)

  };

  const addlike = (video_id, status) => {
  
    AsyncStorage.getItem('auth_token').then(async (datatoken) => {
      setclick(true)
      setopacity(true)
      axios({
        url: Apiurl + "video/like",

        method: "POST",

        data: { "video_id": video_id, "like_status": status == true ? 2 : 1 },
        headers: {
          //  "Content-Type": "",
          Accept: "application/json",
          Authorization: "Bearer " + datatoken,
        },
      })
        .then((response) => {
       
          // console.log(response.data.data.video_id)
         
          // console.log(offset)
          var foundIndex = videolist.findIndex(x => x.id == response.data.data.video_id);
          const newArray = videolist.map((item, i) => {
            if (foundIndex === i) {
              if (response.data.data.like_status == 1) {
                videolist[i].like_count = videolist[i].like_count + 1
              }
              else {
                videolist[i].like_count = videolist[i].like_count - 1
              }
              return { ...item, ["like_by_logged_user"]: response.data.data.like_status == 1 ? true : false };
            } else {
              return item;
            }
          });
         
          setopacity(false)
          setvideolist(newArray);
          setclick(false)
        })
        .catch(function (error) {
          setopacity(false)
          setclick(false)
          if(error?.response?.data?.message=='Unauthorized')
          {
         
           dispatch(logout());
          }
          console.log("error", error);
        });
    });
  };

  const changefollow=(follow_to_id,follow_status,arraylist)=>
  {
  //  console.log('arraylist',arraylist)
  //  console.log('follow_to_id',follow_to_id)
  //  console.log('follow_status',follow_status)
   if(follow_status)
   {
      const videolistnew = arraylist.map((item, i) => {
        // console.log('ddf',item)
        // console.log('ddfuser_id',item.user_id)
        // console.log('follow_to_id',follow_to_id)
        if (item.user_id == follow_to_id) {

         // console.log('ddf',videolist[i].follow_by_logged_user)
         // videolist[i].follow_by_logged_user = follow_status
          //item.follow_by_logged_user=follow_status
         // videolist[i]['follow_by_logged_user']=follow_status
         arraylist[i].follow_by_logged_user = follow_status==2?false:true
          return { ...item};
        } 
        else {
          return item;
        }
      })

     setvideolist(videolistnew);
     AsyncStorage.setItem('follow_to_id_user','')
     AsyncStorage.setItem('follow_status','')
    }
    //  AsyncStorage.removeItem('follow_to_id_user')
    //  AsyncStorage.removeItem('follow_status')

  };
  const renderTruncatedFooter = (handlePress) => {
    // alert(2)
    return (
      <Text style={{ color: "red", marginTop: 5 }} onPress={handlePress}>
        Read more
      </Text>
    );
  }

  const renderRevealedFooter = (handlePress) => {
    //alert(1)
    return (
      <Text style={{ color: "red", marginTop: 5 }} onPress={handlePress}>
        Show less
      </Text>
    );
  }
  const handleTextReady = () => {

  }
  const addfav = (video_id, status) => {
    //console.log(status)

    AsyncStorage.getItem('auth_token').then(async (datatoken) => {
      setclick(true)
      setopacity(true)
      axios({
        url: Apiurl + "video/favourite",

        method: "POST",

        data: { "video_id": video_id, "favourite_status": status == true ? 2 : 1 },
        headers: {
          Accept: "application/json",
          Authorization: "Bearer " + datatoken,
        },
      })
        .then((response) => {
          setopacity(false)
         // console.log(response.data.data)
         // console.log(response.data.data.video_id)
       //   console.log(offset)
          var foundIndex = videolist.findIndex(x => x.id == response.data.data.video_id);
          const newArray2 = videolist.map((item, i) => {
            if (foundIndex === i) {
              if (response.data.data.favourite_status == 1) {
                videolist[i].favourite_count = videolist[i].favourite_count + 1
              }
              else {
                videolist[i].favourite_count = videolist[i].favourite_count - 1
              }

              return { ...item, ["favourite_by_logged_user"]: response.data.data.favourite_status == 1 ? true : false };
            } else {
              return item;
            }
          });
          setvideolist(newArray2);
          setclick(false)
          // videolistapi(activevideotype,offset)
          //  setvideolist(response.data.videos);
        })
        .catch(function (error) {
          setopacity(false)
          setclick(false)
          if(error?.response?.data?.message=='Unauthorized')
          {
         
           dispatch(logout());
          }
          console.log("error", error);
        });
    });
  };

  const addfollow = (follow_to_id,status) => {
    
    console.log({"follow_to_id":follow_to_id,"follow_status":status==true?2:1})
    AsyncStorage.getItem('auth_token').then(async (datatoken) => { 
     // console.log(datatoken)
    axios({
      url: Apiurl+"user/follow",
      method: "POST",
      data: {"follow_to_id":follow_to_id,"follow_status":status==true?2:1},
      headers: {
        Accept: "application/json",
        Authorization:"Bearer "+datatoken,
      },
    })
    .then((response) => {
      console.log('ffd',videolist)
      var foundIndex = videolist.findIndex(x => x.user_id == follow_to_id);
     // console.log(foundIndex)
      const newArray2 = videolist.map((item, i) => {
        if (videolist[i].user_id == follow_to_id) {
          videolist[i].follow_by_logged_user = status==true?false:true
          return { ...item};
       
        } else {
          return item;
        }
      });
      setvideolist(newArray2);
     })
    .catch(function (error) {
      if(error?.response?.data?.message=='Unauthorized')
      {
     
       dispatch(logout());
      }
      //console.log("error", error);
    });
   });
    };

  const calllive = (index) => {
    navigation.navigate(NAVIGATION.Liveuserlist)
  };
  const shorttype = (index) => {
    //stop(currentvideoindex)
    setplayindex(-1)
    //setPaused(true)
    //setpausestatus(index)
    setvideolist('')
    videolistapicall(1, 0, null)
    setactivevideotype(1)
    setPaused(false)
    setplayindex(0)
    // alert("short")
  };

  const callallvideo = (index) => {
   setplayindex(-1)
    //stop(currentvideoindex)
    setvideolist([])
    // setpausestatus(-1)
   
    videolistapicall(0, 0, null)
    setPaused(false)
    setplayindex(0)
    setactivevideotype(0)
    // alert("short")
  };
  const longtype = (index) => {
    setplayindex(-1)
   // stop(currentvideoindex)
    setvideolist([])
    setpausestatus(-1)
   
    setactivevideotype(2)
    videolistapicall(2, 0, null)
    setPaused(false)
    setplayindex(0)
  };
  const callblink = (index) => {
   // alert(currentvideoindex)
    // stop(currentvideoindex)
    // setplayindex(-1)
    // setPaused(true)
    // setpausestatus(index)
    setplayindex(-1)
    setvideolist([])
    setpausestatus(-1)
   
    setactivevideotype(3)
    videolistapicall(3, 0, null)
    setPaused(false)
    setplayindex(0)

  };
  //Video Share //
  const onShare = async (vid) => {
    try {
      const result = await Share.share({
        title: 'App link',
       // message: 'Descarga esta aplicación si no la tienes y mira este video. \n https://youuup.com/share/?id=' + vid,
        message: 'Descarga esta aplicación si no la tienes y mira este video. \n https://youuup.es/share?id=' + vid,
        // message: 'http://103.15.67.180:3006/test?id=' + encodeURIComponent(vid),
        //  message: 'http://103.15.67.180:3006',
        // url: 'https://youuup.es/youuupapi/test?id=' + vid
        url: 'https://youuup.es/share?id=' + vid
      });
      if (result.action === Share.sharedAction) {
        if (result.activityType) {
        } else {
        }
      } else if (result.action === Share.dismissedAction) {
      }
    } catch (error) {
      alert(error.message);
    }
  };
  const PopUp = () => {
    return (
      <Modal
        animationType="slide"
        onRequestClose={() => {
          setShowModal(false)
        }}
        transparent visible={showModal}>
        <View
          style={{
            height: '50%',
            marginLeft: 5,
            marginRight: 5,
            marginTop: 'auto',
            backgroundColor: 'white',
            borderTopLeftRadius: 10,
            borderTopRightRadius: 10
          }}>
        </View>
        <TextInput
          onChangeText={(text) => setcomment(text)}
          color={"black"}
          style={{ width: "100%", backgroundColor: 'red' }}
          placeholderColor={"white"}
        />
      </Modal>
    );
  };
  const callbycomment = (vid) => {
    var foundIndex = videolist.findIndex(x => x.id == vid);
    const newArray22 = videolist.map((item, i) => {
      if (foundIndex === i) {
          videolist[i].comment_count = videolist[i].comment_count + 1
        return { ...item };
      } else {
        return item;
      }
    });
    setcallback(1)
    setcallback(2)
  };
  const goreport = (index,video_id,report_to_id) => {
    // alert(index)
    setPaused(true)
     stop(index)
     props.navigation.navigate("Reportvideo_add", { video_id:video_id,report_to_id:report_to_id})
   };
  return (
    <SafeAreaView style={styles.container}>
    <View style={styles.container}>
      {user?.userinfo?.user.id ?
    
     <Header {...props}  callbuffer={currentdisplay} stop={stop} activevideotype={activevideotype} callallvideo={callallvideo} calllive={calllive} callblink={callblink} shorttype={shorttype} longtype={longtype} />   
     
        
   
        : 
        <HeaderAuth {...props} activevideotype={activevideotype} callbuffer={currentdisplay} stop={stop} callblink={callblink} callallvideo={callallvideo} calllive={calllive} shorttype={shorttype} longtype={longtype} />}
     
     
      <PagerView   onPageSelected={(e)=>setcurrentvideoindex(e.nativeEvent.position)} ref={ref} onPageScroll={(e) => pageOnScroll(e)} orientation='vertical' style={styles.pagerView} initialPage={0}>
        
           
          {
          videolist.length > 0 ?
            videolist.map((video, index) => (
            
              <View
                key={index}
                style={{ height:'95.1%', backgroundColor: '#010101' }}
              //  style={{ height: Dimensions.get("window").height-20, backgroundColor: '#010101' }}
                >
                {/* <Video
                 // style={styles.backgroundVideo}
                 style={{width:200,height:1000}}
                  source={{ uri: "http://commondatastorage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4"}}
                />  */}
                {/* <Video
                  style={styles.backgroundVideo}
                  source={{ uri: video.url }}
           
                />  */}
              {/* <VideoPlayer video={video} index={index}/>  */}
                 {/* {index == playindex ?  
                 <VideoPlayer video={video} index={index}/> 
                 :
                 <View style={styles.backgroundVideo}> 
                 <Image style={{width:105,height:153,borderRadius:15}} source={{ uri:Apiurl + video?.video_thumbnail} }/>
               </View>
                }  */}
             { currentvideoindex == index && 
                 <>  
                  <Video
                  style={styles.backgroundVideo}
                  source={{ uri: video.url }}
                  
             // poster={Apiurl + video?.video_thumbnail}
                //  posterResizeMode="cover"
                // ref={(ref) => {
                //   this.player = ref
                // }}   
              
                  resizeMode="cover"
                  playInBackground={false}
                  playWhenInactive={false}
                 // paused={true}
                   preload="none"
                    paused={index == playindex ?
                      false :
                      true}
                  onTouchStart={() =>
                    paused ?
                      start(index)
                      :
                      stop(index)
                  }
                  onBuffer={() =>{
                    console.log('buffer11')
                    onBuffer(0,video.id)
                  }}
                 
                
                  onReadyForDisplay={() =>
                    {
                   // alert(index)
                    setcurrentdisplay(index)
                    }
                  }
                  onLoadStart={() =>{
                    console.log('onLoadStart')
                    onBuffer(1,null)
                   
                    
                    }}
                   
                    onLoad={() =>
                    {
                      Addviewcount(video.id)
                      
                      console.log('onLoad')
                      onBuffer(0,video.id)
                    }
                       
                       }
                       onError={(e) => console.log(e)}
                       ref={(ref) => (videoPlayer.current[index] = ref)}
                   // ref={videoPlayer}
                  onEnd={() => { 
                   
                    ref.current.setPage(playindex + 1) }}
               
                  //  bufferConfig = {{
                  //   minBufferMs: 50,
                  //   maxBufferMs: 100,
                  //   bufferForPlaybackMs: 50,
                  //   bufferForPlaybackAfterRebufferMs: 100
                  // }}
                /> 
              
            {opacity == 1 && (
              <ActivityIndicator
               animating
               color={'white'}
              size="large"
               style={styles.activityIndicator}
              />
             )} 
                </>
              }    
             
                <View style={{ position: "relative", top: '45%' }}>
                  {/* {index != playindex &&  pausetatus==false &&  */}
                  {/* {pausetatus == index &&  playindex==-1 && */}
                  {/* // {pausetatus == index &&  playindex==-1 && */}
                    { pausetatus == index &&  paused && playindex==-1 &&

                    <TouchableOpacity style={{ zIndex: 9999999, }}
                      onPress={() => paused  ?
                        start(index)
                        :
                        stop(index)}
                    >
                      <Image style={{ alignSelf: 'center' }} resizeMode='center' source={require("../../assets/splash/Shape.png")} />
                    </TouchableOpacity>
                  }
                </View>
                <ContentLeftBottom  style={{}}>
                  {/* <ContentLeftBottomNameUser style={{ top: '20%' }}>
                    <View style={{ flexDirection: 'row', justifyContent: 'center', alignContent: 'center', alignItems: 'center' }}>
                      <Text style={{ color: 'white', paddingRight: 5, fontSize: 15 }}>{video?.user?.name}</Text>
                    
                      {user?.userinfo?.user.id!=video.user_id &&
                      <TouchableOpacity
                       onPress={()=>user?.userinfo?.user.id ? addfollow(video.user_id,video.follow_by_logged_user): props.navigation.navigate("Login")}
                        style={{ borderColor: video?.follow_by_logged_user ? "#08DDFD" : "white", borderWidth: 1, marginLeft: 2, borderRadius: 10, padding: 2 }}>
                        <Text style={{ color: video?.follow_by_logged_user ? "#08DDFD" : "white", fontSize: 12, padding: 2 }}>{video?.follow_by_logged_user ? 'Siguiendo' : 'Seguir'} </Text>
                        </TouchableOpacity>
                      }
                    </View>

                  </ContentLeftBottomNameUser> */}

                  <ContentLeftBottomNameUser style={{ top: '20%',width:'100%',}}>
                    <View style={{width:'100%', flexDirection: 'row',}}>
                      <View style={{width:'95%',flexDirection: 'row', }}>
                      <Text style={{ color: 'white', paddingRight: 5, fontSize: 15 }}>{video?.user?.name}</Text>
                      {/* <Image
                        source={require("../../assets/Home/New/verified.png")}
                      /> */}
                      {user?.userinfo?.user.id!=video.user_id &&
                      <TouchableOpacity
                       onPress={()=>user?.userinfo?.user.id ? addfollow(video.user_id,video.follow_by_logged_user): props.navigation.navigate("Login")}
                        style={{ borderColor: video?.follow_by_logged_user ? "#08DDFD" : "white", borderWidth: 1, marginLeft: 2, borderRadius: 10, padding: 2 }}>
                        <Text style={{ color: video?.follow_by_logged_user ? "#08DDFD" : "white", fontSize: 12, padding: 2 }}>{video?.follow_by_logged_user ? 'Siguiendo' : 'Seguir'} </Text>
                        </TouchableOpacity>
                      }
                      </View>
                     <TouchableOpacity  onPress={() => user?.userinfo?.user.id ? (stop(index), goreport(index, video.id,video?.user?.id)) : (stop(index),props.navigation.navigate("Login"))} style={{paddingLeft:4,paddingRight:4}} >
                       <Image  style={{  }} source={require("../../assets/images/reportvideo_call.png")} />
                      </TouchableOpacity>
                    </View>
                  </ContentLeftBottomNameUser>
                  <ContentLeftBottomDescription style={{ top: '20%' }} numberOfLines={3}>
                    {video?.description.length > 40 ?
                      <>
                        {!showMore ?
                          <Text style={{ color: 'white' }}>
                            {video?.description.substring(0, 40)}...
                          </Text>
                          :
                          <Text style={{ color: 'white' }}>
                            {video?.description}
                          </Text>
                        }
                        <Text onPress={() => setShowMore(!showMore)} style={{ color: '#08DDFD' }}>
                          {' '}  {!showMore ? 'Leer más' : 'Leer menos'}
                        </Text>
                      </>

                      :
                      <Text style={{ color: 'white' }}>
                        {video?.description}
                      </Text>
                    }

                  </ContentLeftBottomDescription>

                  <ContentLeftBottomDescription style={{ top: '20%', color: "#08DDFD" }} numberOfLines={3}>
                    {video?.chennelName.length > 40 ?
                      <>
                        {!showMore2 ?
                          <Text style={{ color: '#08DDFD' }}>
                            {video?.chennelName.substring(0, 40)}...
                          </Text>
                          :
                          <Text style={{ color: '#08DDFD' }}>
                            {video?.chennelName}
                          </Text>
                        }
                        <Text onPress={() => setShowMore2(!showMore2)} style={{ color: 'white' }}>
                          {' '}  {!showMore2 ? 'Leer más' : 'Leer menos'}
                        </Text>
                      </>
                      :
                      <Text style={{ color: '#08DDFD' }}>
                        {video?.chennelName}
                      </Text>
                    }
                  </ContentLeftBottomDescription>
               
                  <View style={{ position: 'relative', top: 40, right: 1, flexDirection: "row", width: '100%', justifyContent: 'space-between', alignItems: 'center', alignContent: 'center' }}>
                    <TouchableOpacity
                      //onPress={() => navigation.navigate(NAVIGATION.UserProfile,{creater_id:video.user_id})}
                      onPress={() => user?.userinfo?.user.id ? (stop(index),navigation.navigate(user?.userinfo?.user.id==video.user_id? NAVIGATION.MyProfile:NAVIGATION.UserProfile, { creater_id: video.user_id })) : (stop(index),props.navigation.navigate("Login"))}

                      style={{ borderWidth: 3, borderRadius: 30, borderColor: 'white', marginBottom: 10 }}>
                      <Image
                        style={{ width: 45, height: 45, borderRadius: 60, position: 'relative' }}
                        source={{ uri: video?.user?.image }}
                      />

                    </TouchableOpacity>
                    <TouchableOpacity
                      disabled={clickstatus? true:false}
                      onPress={() => user?.userinfo?.user.id  ? ( clickstatus==false && addlike(video.id, video.like_by_logged_user)) : (stop(index),props.navigation.navigate("Login"))}

                    >
                      <Image
                        style={{ tintColor: video.like_by_logged_user ? '#08DDFD' : 'white' }}
                        source={require("../../assets/Home/New/inactivelikeIcon.png")}
                      />
                      <Text style={{ paddingTop: 7, color: '#FFFFFF', fontFamily: FONTS.PoppinsRegular, fontSize: 13, fontWeight: '500', alignContent: 'center', textAlign: "center" }}>{video.like_count ? video.like_count : 0}</Text>
                    </TouchableOpacity>
                    <TouchableOpacity
                     disabled={clickstatus? true:false}
                      onPress={() => user?.userinfo?.user.id ? ( clickstatus==false && addfav(video.id, video.favourite_by_logged_user)) : (stop(index),props.navigation.navigate("Login"))}
                    >
                      <Image
                        style={{ tintColor: video.favourite_by_logged_user ? '#08DDFD' : 'white' }}
                        source={require("../../assets/Home/New/save.png")}
                      />
                      <Text style={{ textAlign: "center", paddingTop: 7, color: '#FFFFFF', fontFamily: FONTS.PoppinsRegular, fontSize: 13, fontWeight: '500' }}>{video.favourite_count ? video.favourite_count : 0}</Text>
                    </TouchableOpacity>
                    <TouchableOpacity
                      onPress={() => user?.userinfo?.user.id ?  (stop(index), props.navigation.navigate("Commentslist", { video_id: video.id,callbycommentfun:callbycomment })): (stop(index), props.navigation.navigate("Login"))}
                    // onPress={()=>user?.userinfo?.user.id ? setShowModal(true): props.navigation.navigate("Login")}

                    >
                      <Image
                        source={require("../../assets/Home/New/CommentIcon.png")}
                      />
                      <Text style={{ textAlign: "center", paddingTop: 7, color: '#FFFFFF', fontFamily: FONTS.PoppinsRegular, fontSize: 13, fontWeight: '500' }}> {video.comment_count ? video.comment_count : 0}</Text>

                    </TouchableOpacity>
                    <TouchableOpacity onPress={() => user?.userinfo?.user.id ? onShare(video.id) : (stop(index), props.navigation.navigate("Login"))}>
                      <Image
                        source={require("../../assets/Home/New/SharedIcon.png")}
                      />
                      <Text style={{ paddingTop: 7, color: '#FFFFFF', fontFamily: FONTS.PoppinsRegular, fontSize: 13, fontWeight: '500' }}> </Text>

                    </TouchableOpacity>
                  </View>
                </ContentLeftBottom>
              </View>
            
                
            ))
            :
            <View style={{ backgroundColor: "black", alignSelf: 'center', justifyContent: 'center', alignItems: 'center', alignContent: 'center' }}>
              {/* <Text style={{ color: 'white' }}>No se encontraron vídeos</Text> */}
              
                 <Image
                        
                        style={{width:'30%',height:'30%'}}
                        source={require("../../assets/Home/New/empty_records_icon.png")}
                      />
              {/* <TouchableOpacity onPress={()=>onShare()} >
                <Text style={{color:'white'}}>sfmdf</Text>
              </TouchableOpacity> */}
            </View>
        }

      </PagerView>
      {showModal && <PopUp />}
    </View>
    </SafeAreaView>
  );
}

