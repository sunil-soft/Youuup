import { Apiurl } from "@/constants/Apiurl";
import AsyncStorage from '@react-native-async-storage/async-storage';
import { useFocusEffect } from "@react-navigation/native";
import axios from "axios";
import moment from 'moment/min/moment-with-locales';
import React, { useState } from "react";
import { FlatList, Image, ImageBackground, Text, TouchableOpacity, View } from "react-native";
import { showMessage } from "react-native-flash-message";
import { KeyboardAwareScrollView } from 'react-native-keyboard-aware-scroll-view';
import { moderateScale, verticalScale } from "react-native-size-matters";
import { useDispatch } from "react-redux";
import { logout } from "../../actions/UserActions";
import { Header } from "../../components/Header";
import styles from "./NotificationsStyles";
moment.locale('es')
const Notifications = (props) => {
  const [isModalVisible, setModalVisible] = useState(false);
  const [notificationlist, setnotificationlist] = useState([]);
  const dispatch = useDispatch();


  const deletenotify = (id) => {
    AsyncStorage.getItem('auth_token').then(async (datatoken) => {
      if (datatoken) {
        axios({
          url: Apiurl + "user/delete_notify",
          method: "POST",
          data: { "notification_id": id },
          headers: {
            Accept: "application/json",
            Authorization: "Bearer " + datatoken,
          },
        })
          .then((response) => {
            notificationlistdata()
            showMessage({
              message: "Borrado exitosamente.",
              type: "success",
            });
            // console.log('notificationlist', response.data?.result)

            // setnotificationlist(response.data?.result)
            //setvideolist(videolist => [...videolist, response.data.videos]);
            // setvideolist( [...videolist, response.data.videos]);
          })
          .catch(function (error) {
            // console.log(Apiurl)

          });
      }

    });
  };
  const notificationlistdata = () => {
    AsyncStorage.getItem('auth_token').then(async (datatoken) => {
      if (datatoken) {
        axios({
          url: Apiurl + "user/notification-list",
          method: "GET",
          //  data: shavideo_id ? { "video_type": video_type_status, "offset": offset, "limit": 4, "video_id": shavideo_id } : { "video_type": video_type_status, "offset": offset, "limit": 4 },
          headers: {
            Accept: "application/json",
            Authorization: "Bearer " + datatoken,
          },
        })
          .then((response) => {
            console.log('notificationlist', response.data?.result)

            setnotificationlist(response.data?.result)
            //setvideolist(videolist => [...videolist, response.data.videos]);
            // setvideolist( [...videolist, response.data.videos]);
          })
          .catch(function (error) {
            console.log(Apiurl)

          });
      }

    });
  };
  useFocusEffect(
    React.useCallback(() => {
      AsyncStorage.getItem('auth_token').then(async (datatoken) => {
        if (datatoken) {
          axios({
            url: Apiurl + "user/notification-list",
            method: "GET",
            //  data: shavideo_id ? { "video_type": video_type_status, "offset": offset, "limit": 4, "video_id": shavideo_id } : { "video_type": video_type_status, "offset": offset, "limit": 4 },
            headers: {
              Accept: "application/json",
              Authorization: "Bearer " + datatoken,
            },
          })
            .then((response) => {
              console.log('notificationlist', response.data?.result)

              setnotificationlist(response.data?.result)
              //setvideolist(videolist => [...videolist, response.data.videos]);
              // setvideolist( [...videolist, response.data.videos]);
            })
            .catch(function (error) {
              if(error?.response?.data?.message=='Unauthorized')
           {
          
            dispatch(logout());
           }

            });
        }

      });

    }, [])
  );

  const renderItem = ({ item }) => {
    return (


      <View>
        <View style={styles.notificationBoxStyle}>
          <View style={{ flexDirection: "row" }}>
            <View style={{ width: "90%" }}>
              <View>
                <Text style={styles.NotificationTitleStyle}>{item.notification_title}</Text>
                <Text style={styles.NotificationdisStyle}>{item.notification_body}</Text>
                <Text style={styles.timeTitle}>{moment.utc(item.updatedAt).local().startOf('seconds').fromNow()}</Text>
                <View
                  style={{
                    borderWidth: 0.2,
                    borderColor: "#0000001A",
                    marginLeft: moderateScale(15),
                    marginTop: verticalScale(20),
                  }}
                ></View>
              </View>
            </View>
            <View style={{ width: '10%' }}>
              <TouchableOpacity onPress={() => deletenotify(item.id)} style={{ paddingTop: 40,paddingBottom:10, }}>
                <Image
                  source={require("../../assets/Home/bin.png")}
                />
              </TouchableOpacity>
            </View>
          </View>
        </View>
      </View>
    );
  };
  return (
    <ImageBackground
      style={{ flex: 1, }}
      resizeMode={"stretch"}
      backgroundColor={'black'}
      // source={require("../../assets/images/editprofileback.png")}
      source={require("../../assets/splash/bg.png")}
    >

      <View style={{ flex: 1, }}>
        <Header back={true} {...props} title={'Notificaciones'} />
        <KeyboardAwareScrollView>
         
            {/* <Text
              style={{
                color: "#43686A",
                fontSize: moderateScale(20),
                fontFamily: FONTS.PoppinsSemiBold,
              }}
            >
              Notifications
            </Text>
            <Text
              style={{
                color: "#738485",
                fontSize: moderateScale(16),
                fontFamily: FONTS.PoppinsLight,
              }}
            >
              Mark as read
            </Text> */}
          
          <FlatList data={notificationlist} renderItem={renderItem} style={{ marginTop: 70 }} />
          {/* <Text>{JSON.stringify(user?.notificationlist.notification)}</Text> */}

        </KeyboardAwareScrollView>
      </View>

    </ImageBackground>
  );
};

export default Notifications;
