import { StyleSheet } from "react-native";
import { moderateScale, verticalScale } from "react-native-size-matters";
import { FONTS } from "../../theme/fonts";

const styles = StyleSheet.create({
  notificationBoxStyle: {
    backgroundColor: "#FFFFFF",
    margin: verticalScale(10),
   // height: scale(140),
   padding:10,
    borderRadius: moderateScale(15),
    elevation: 20,
    shadowColor: "grey",
    marginLeft: moderateScale(20),
    marginRight: moderateScale(20),
  },
  leftView: {
    backgroundColor: "#0D625B",
    height: 40,
    width: 4,
    borderBottomEndRadius: 15,
    borderTopEndRadius: 15,
    marginTop: moderateScale(15),
  },
  NotificationTitleStyle: {
    fontSize: moderateScale(14),
    fontFamily: FONTS.PoppinsMedium,
    color: "black",
    marginHorizontal: moderateScale(10),
    marginTop: moderateScale(10),
  },
  NotificationdisStyle: {
    fontSize: moderateScale(12),
    fontFamily: FONTS.PoppinsRegular,
    color: "black",
    marginHorizontal: moderateScale(5),
    marginTop: moderateScale(10),
  },
  timeTitle: {
    color: "black",
    fontSize: moderateScale(11),
    fontFamily: FONTS.PoppinsLight,
    marginLeft: moderateScale(10),
    marginTop: moderateScale(3),
  },
  HorizontalLineStyle: {
    borderWidth: 0.18,
    borderColor: "#93AFB1",
    width: "95%",
    marginLeft: moderateScale(10),
    marginTop: moderateScale(15),
  },
  rejectTitleStyle: {
    color: "#43686A",
    fontSize: moderateScale(16),
    fontFamily: FONTS.PoppinsMedium,
  },
  acceptTitleStyle: {
    color: "#05A1AB",
    fontFamily: FONTS.PoppinsMedium,
    fontSize: moderateScale(16),
  },
});

export default styles;
