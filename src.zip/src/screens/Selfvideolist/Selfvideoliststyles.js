import { Dimensions, StatusBar, StyleSheet } from "react-native";
export const styles = StyleSheet.create({
   mainContainer:
  {
    flex:1,
  //  marginTop:10
  },

  pagerView: {
    flex: 1,
},
backgroundVideo: {
  alignItems: "stretch",
  position: "absolute",
  height: Dimensions.get("window").height + StatusBar.currentHeight,
  left: 0,
  top: 0,
  right: 0,
  bottom: 0,
},
activityIndicator: {
  position: 'absolute',
  top: '50%',
  left: 70,
  right: 70,
  height: 50,
  alignItems: 'center',
  justifyContent: 'center',
},
});
