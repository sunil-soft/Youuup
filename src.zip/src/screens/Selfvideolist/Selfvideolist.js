import React, { useEffect, useState } from 'react';

import { Apiurl } from "@/constants/Apiurl";
import { FONTS } from "@/theme/fonts";
import AsyncStorage from '@react-native-async-storage/async-storage';
import { useFocusEffect } from "@react-navigation/native";
import axios from "axios";
import { ActivityIndicator, AppState, Image, Share, StatusBar, Text, TouchableOpacity, View } from 'react-native';
import { showMessage } from "react-native-flash-message";
import PagerView from 'react-native-pager-view';
import Video from 'react-native-video';
import { useDispatch, useSelector } from "react-redux";
import { logout } from "../../actions/UserActions";
import { Header } from "../../components/Header";
import { NAVIGATION } from "../../constants";
import { getUser } from "../../selectors/UserSelectors";
import { ContentLeftBottom, ContentLeftBottomDescription, ContentLeftBottomNameUser } from '../Home/styles';
import { styles } from "./Selfvideoliststyles";
const APIBASEURL='https://youuup.es/mobile-api/'

  const Selfvideolist = (props) => {
  const dispatch = useDispatch();
  const { navigation, route } = props;
  const user = useSelector(getUser);
  const { selfvideodata,startindex,screenbyfav,video_id} = route.params;
  const [animating, setAnimating] = useState(false);
  const [activevideotype, setactivevideotype] = useState(0);
  const [opacity, setopacity] = useState(0);
  const [playindex, setplayindex] = useState(0);
  const [pausetatus, setpausestatus] = useState(-1);
  const [showMore, setShowMore] = useState(false);
  const [showMore2, setShowMore2] = useState(false);
  const [currentdisplay, setcurrentdisplay] = useState(0);
  const [paused, setPaused] = useState(false);
  const [currentvideoindex, setcurrentvideoindex] = useState(0);
  const [scrollToIndex, setScrollToIndex] = useState(0);
  const [Videolist, setVideolist] = useState([]);
  const [Videolistorignal, setVideolistorignal] = useState([]);

  const [Videolistblink, setVideolistblinkall] = useState([]);
  const [Videolistlongall, setVideolistlongall] = useState([]);
  const [Videolistshortall, setVideolistshortall] = useState([]);
  const [callbak, setcallback] = useState('');
  const [startindexdata, setstartindexdata] = useState(0);
  
  const appState = React.useRef(AppState.currentState);

  const ref = React.useRef(PagerView);
  const start = (index) => {
    setplayindex(index)
    setPaused(false)
    setpausestatus(-1)
    // setplaystatus(true)

  };
  useEffect(() => {
     const subscription = AppState.addEventListener('change', nextAppState => {
       appState.current = nextAppState;

       console.log(appState.current)
       if (appState.current == 'background') {
         setplayindex(-1)
         setPaused(true)
         setpausestatus(currentdisplay)
       }
       if (appState.current == 'active') {
        //  setPaused(false)
        //  setpausestatus(-1)
        //  setplayindex(currentdisplay)
       }
     });
     return () => {
       subscription.remove();
     };
   }, [currentdisplay]);
  const stop = (index) => {
    setplayindex(-1)
    setPaused(true)
    setpausestatus(index)
  };
  const Addviewcount = (video_id) => {
    //alert(video_id)
    axios({
      url: Apiurl + "video/add-video-count",
      method: "POST",
      data: { "video_id": video_id },
      headers: {
        Accept: "application/json",
      },
    })
      .then((response) => {
        console.log('view response',response)
      })
      .catch(function (error) {
        console.log('error',error) 
      });
};
  useEffect(() => {
    console.log('useEffectstartindex',startindex)
   // setstartindexdata(startindex)
   // console.log('selfvideodata',selfvideodata)
    // alert(startindex)
    // alert(video_id)
    setVideolistorignal(selfvideodata)
   // alert(startindex)
   if(screenbyfav==1)
   {
    setVideolist(selfvideodata)
    setplayindex(startindex)
   }
   else{
   // alert(video_id)
    //alert('totallength'+selfvideodata.length)
    const productArrayFiltered = selfvideodata.slice(0, selfvideodata.length>=startindex+4 ? startindex+4 :selfvideodata.length);
    console.log('productArrayFiltered',productArrayFiltered)

  //  let vindex = productArrayFiltered.findIndex(x => x.id ==video_id);

  // alert('v'+startindex);

    // console.log('selfvideodata',selfvideodata)
    // console.log('productArrayFiltered',productArrayFiltered)
    setVideolist(productArrayFiltered)
    setplayindex(startindex)

   }
   
  
   
   //  console.log(startindex)
   //  videolistapi(activevideotype, offset, null)
   return () => {
    //alert(startindex)
    //startindex=''
  };
   }, []);
   useFocusEffect(
    React.useCallback(() => {
      // setstartindexdata(startindex)
      console.log('useFocusEffectstartindex',startindex)
      console.log('useFocusEffectstartindex',screenbyfav)
      console.log('selfvideodata',selfvideodata)
      // setcallback(1)
      setVideolistorignal(selfvideodata)
      if(screenbyfav==1)
      {
       setVideolist(selfvideodata)
      
      // ref.current.setPage(startindex);
      // setplayindex(startindex)
      }
      else{
        // setVideolistorignal(selfvideodata)
       const productArrayFiltered = selfvideodata.slice(0, selfvideodata.length>=startindex+4 ? startindex+4 :selfvideodata.length);
       console.log('productArrayFiltered',productArrayFiltered)
       setVideolist(productArrayFiltered)
      // setplayindex(startindex)
   
      }
      
   }, [])
 );
   const onBuffer = (isBuffering,vid) => {
   // console.log(isBuffering)
    setopacity(isBuffering)

    if(vid!=null)
    {
      setTimeout(() => {
      //  Addviewcount(vid)
      }, 200);
   
    }
    }
const pageOnScroll = (event) => {
  console.log("45")
  setopacity(1)
  const { position } = event.nativeEvent;

   // onBuffer(1,null)
  if (position !== scrollToIndex) {
   
   setShowMore(false)
   setShowMore2(false)
   start(position)
   setplayindex(position)


   if (Videolist?.length - 2 == position) {
    if(activevideotype==3)
    {
      const productArrayFiltered2blink = Videolistblink.slice(Videolist?.length,Videolist?.length+4);
     setVideolist(Videolist => [...Videolist, ...productArrayFiltered2blink]);
    }
    else if(activevideotype==2)
    {
    
    const productArrayFiltered2long = Videolistlongall.slice(Videolist?.length,Videolist?.length+4);
    setVideolist(Videolist => [...Videolist, ...productArrayFiltered2long]);
    }
    
    else if(activevideotype==1)
    {
    
    const productArrayFiltered2short = Videolistshortall.slice(Videolist?.length,Videolist?.length+4);
    setVideolist(Videolist => [...Videolist, ...productArrayFiltered2short]);
    }

   else{
     const productArrayFiltered2 = Videolistorignal.slice(Videolist?.length,Videolist?.length+4);
     setVideolist(Videolist => [...Videolist, ...productArrayFiltered2]);
     }
  //  setVideolist(productArrayFiltered2)
    // alert('ff'+videolist?.length)
    //  videolistapi(activevideotype, videolist?.length, null)
    //  console.log('positionfix', position)
   }

  // setPageIndex(position)
   
  }
  else {
    setplayindex(0)
  }
  setPaused(false)
};

const addlike = (video_id, status) => {
  console.log({ "video_id": video_id, "like_status": status == true ? 2 : 1 })
  AsyncStorage.getItem('auth_token').then(async (datatoken) => {
    axios({
      url: Apiurl + "video/like",

      method: "POST",

      data: { "video_id": video_id, "like_status": status == true ? 2 : 1 },
      headers: {
        //  "Content-Type": "",
        Accept: "application/json",
        Authorization: "Bearer " + datatoken,
      },
    })
      .then((response) => {
        var foundIndex = Videolist.findIndex(x => x.id == response.data.data.video_id);
        const newArray = Videolist.map((item, i) => {
          if (foundIndex === i) {
            if (response.data.data.like_status == 1) {
              Videolist[i].like_count = Videolist[i].like_count + 1
            }
            else {
              Videolist[i].like_count = Videolist[i].like_count - 1
            }
            return { ...item, ["like_by_logged_user"]: response.data.data.like_status == 1 ? true : false };
          } else {
            return item;
          }
          });
        setVideolist(newArray);
      })
      .catch(function (error) {
        console.log("error", error);
        if(error?.response?.data?.message=='Unauthorized')
        {
       
         dispatch(logout());
        }
      });
  });
};
const addfav = (video_id, status) => {
  if(screenbyfav!=1 || !screenbyfav)
  {
  AsyncStorage.getItem('auth_token').then(async (datatoken) => {
    axios({
      url: Apiurl + "video/favourite",

      method: "POST",

      data: { "video_id": video_id, "favourite_status": status == true ? 2 : 1 },
      headers: {
        Accept: "application/json",
        Authorization: "Bearer " + datatoken,
      },
    })
      .then((response) => {
        var foundIndex = Videolist.findIndex(x => x.id == response.data.data.video_id);
        const newArray2 = Videolist.map((item, i) => {
          if (foundIndex === i) {
            if (response.data.data.favourite_status == 1) {
              Videolist[i].favourite_count = Videolist[i].favourite_count + 1
            }
            else {
              Videolist[i].favourite_count = Videolist[i].favourite_count - 1
            }
            return { ...item, ["favourite_by_logged_user"]: response.data.data.favourite_status == 1 ? true : false };
          } else {
            return item;
          }
        });
        setVideolist(newArray2);
      })
      .catch(function (error) {
        console.log("error", error);
        if(error?.response?.data?.message=='Unauthorized')
        {
       
         dispatch(logout());
        }
      });
  });
}
else{
  showMessage({
    message: "Ya favorita.",
    type: "danger",
  });
}
};
const addfollow = (follow_to_id,status) => {
  AsyncStorage.getItem('auth_token').then(async (datatoken) => { 
  axios({
    url: Apiurl+"user/follow",
    method: "POST",
    data: {"follow_to_id":follow_to_id,"follow_status":status==true?2:1},
    headers: {
      Accept: "application/json",
      Authorization:"Bearer "+datatoken,
    },
  })
  .then((response) => {
    var foundIndex = Videolist.findIndex(x => x.user_id == follow_to_id);
    const newArray2 = Videolist.map((item, i) => {
      if (Videolist[i].user_id == follow_to_id) {
        Videolist[i].follow_by_logged_user = status==true?false:true
        return { ...item};
     
      } else {
        return item;
      }
    });
    setVideolist(newArray2);
   })
  .catch(function (error) {
    if(error?.response?.data?.message=='Unauthorized')
    {
   
     dispatch(logout());
    }
  });
 });
  };
const onShare = async (vid) => {
  try {
    const result = await Share.share({
      title: 'App link',
      message: 'Descarga esta aplicación si no la tienes y mira este video. \n https://youuup.es/share?id=' + vid,
     // message: 'http://103.15.67.180:3006/test?id=' + encodeURIComponent(vid),
    //  message: 'http://103.15.67.180:3006',
      url: 'https://youuup.es/share?id=' + vid
    });
    if (result.action === Share.sharedAction) {
      if (result.activityType) {
      } else {
      }
    } else if (result.action === Share.dismissedAction) {
    }
  } catch (error) {
    alert(error.message);
  }
};
const callallvideo = (index) => {
  setplayindex(-1)
  setVideolist([])
  setpausestatus(-1)
  setactivevideotype(0)
  setTimeout(() => {
    setVideolist(Videolistorignal)
    setplayindex(0)
  }, 100);
};
const shorttype = (index) => {
  setplayindex(-1)
  setVideolist([])
  setpausestatus(-1)
  setactivevideotype(1)
  let newArray = Videolistorignal.filter(function (el) {
    return el.video_type == 1;
}
);
setVideolistshortall(newArray)
setTimeout(() => {
 // setVideolist(newArray)
  const productArrayFilteredshort = newArray.slice(0, 4);
  setVideolist(productArrayFilteredshort)
  setplayindex(0)
}, 100);
  // alert("short")
};


const longtype = (index) => {
  setplayindex(-1)
  setVideolist([])
  setactivevideotype(2)
  let newArray2 = Videolistorignal.filter(function (el) {
    return el.video_type == 2;
}
);
setVideolistlongall(newArray2)

setTimeout(() => {
  const productArrayFilteredlong = newArray2.slice(0, 4);

  setVideolist(productArrayFilteredlong)
 // setVideolist(newArray2)
  setplayindex(0)
}, 100);
};
const callblink = (index) => {
  setplayindex(-1)
  setVideolist([])
  setpausestatus(-1)
  setactivevideotype(3)
  let newArray3 = Videolistorignal.filter(function (el) {
    return el.video_type == 3;
}
);
setVideolistblinkall(newArray3)

setTimeout(() => {
  const productArrayFilteredblink = newArray3.slice(0, 4);

  setVideolist(productArrayFilteredblink)
  setplayindex(0)
}, 100);
 


};

const goreport = (index,video_id,report_to_id) => {
  // alert(index)
   setPaused(true)
   stop(index)
   props.navigation.navigate("Reportvideo_add", { video_id:video_id,report_to_id:report_to_id})
 };

 const callbycomment = (vid) => {
  var foundIndex = Videolist.findIndex(x => x.id == vid);
  const newArray22 = Videolist.map((item, i) => {
    if (foundIndex === i) {
      //alert(Videolist[i].comment_count)
      Videolist[i].comment_count = Videolist[i].comment_count + 1
      return { ...item };
    } else {
      return item;
    }
  });
  setcallback(1)
  // setVideolist(newArray22)
  setcallback(2)
};


  return (
    <View style={{flex:1,backgroundColor:"black",marginTop:2}}>
    {/* <ImageBackground
      style={{ flex: 1,  }}
      resizeMode={"stretch"}
     // source={require("../../assets/images/editprofileback.png")}
      source={require("../../assets/splash/bg.png")}
    > */}
      <StatusBar translucent backgroundColor="transparent" />
      <Header {...props} selfvideostatus={true} callbuffer={currentdisplay} stop={stop}  activevideotype={activevideotype} callallvideo={callallvideo}  callblink={callblink} shorttype={shorttype} longtype={longtype} /> 

      {/* {showModal && <PopUp />} */}

     <View style={styles.mainContainer}>
       <PagerView  
            onPageSelected={(e)=>setcurrentvideoindex(e.nativeEvent.position)} 
            ref={ref} 
            onPageScroll={(e) => pageOnScroll(e)} 
            orientation='vertical' style={styles.pagerView} 
            initialPage={startindex}>
            {
             Videolist.length > 0 ?
             Videolist.map((video, index) => (
            
              <View
                key={index}
                style={{  height:'95.1%', backgroundColor: '#010101' }}>
            
              { currentvideoindex == index &&  
               <>
                 <Video
                  style={styles.backgroundVideo}
                  source={{ uri: video.url }}
                 // poster={Apiurl + video?.video_thumbnail}
                //  posterResizeMode="cover"
                  
                  resizeMode="cover"
                  playInBackground={false}
                    paused={index == playindex ?
                      false :
                      true}
                  onTouchStart={() =>
                    paused ?
                      start(index)
                      :
                      stop(index)
                  }
                  onBuffer={() =>
                    console.log('buffer')
                  }
                  
                  onProgress={() =>
                    console.log('onProgress')
                  }
                  onReadyForDisplay={() =>
                    setcurrentdisplay(index)
                  }
                  onLoadStart={() =>
                    onBuffer(1,null)
                    }
                    onLoad={() =>{
                      Addviewcount(video.id)
                     onBuffer(0,video.id)
                    }
                       }
                  onEnd={() => { 
                    
                  
                    ref.current.setPage(playindex + 1) }}
                /> 
              {opacity == 1 && (
              <ActivityIndicator
               animating
               color={'white'}
              size="large"
               style={styles.activityIndicator}
              />
             )} 
                 </>
               }  
             
                <View style={{ position: "relative", top: '45%' }}>
                  {/* {index != playindex &&  pausetatus==false &&  */}
                  {/* {pausetatus == index && */}
                { pausetatus == index &&  paused && playindex==-1 &&

                    <TouchableOpacity style={{ zIndex: 9999999, }}
                      onPress={() => paused ?
                        start(index)
                        :
                        stop(index)}
                    >
                      <Image style={{ alignSelf: 'center' }} resizeMode='center' source={require("../../assets/splash/Shape.png")} />
                    </TouchableOpacity>
                  }
                </View>
                <ContentLeftBottom  style={{}}>
                  {/* <ContentLeftBottomNameUser style={{ top: '20%' }}>
                    <View style={{ flexDirection: 'row', justifyContent: 'center', alignContent: 'center', alignItems: 'center' }}>
                      <Text style={{ color: 'white', paddingRight: 5, fontSize: 15 }}>{video?.user?.name}</Text>
                      {user?.userinfo?.user.id!=video.user_id &&
                       <TouchableOpacity
                         onPress={()=>user?.userinfo?.user.id ? addfollow(video.user_id,video.follow_by_logged_user): props.navigation.navigate("Login")}
                         style={{ borderColor: video?.follow_by_logged_user ? "#08DDFD" : "white", borderWidth: 1, marginLeft: 2, borderRadius: 10, padding: 2 }}>
                         <Text style={{ color: video?.follow_by_logged_user ? "#08DDFD" : "white", fontSize: 12, padding: 2 }}>{video?.follow_by_logged_user ? 'Siguiendo' : 'Seguir'} </Text>
                        </TouchableOpacity>
                       }
                    </View>

                  </ContentLeftBottomNameUser> */}
                    <ContentLeftBottomNameUser style={{ top: '20%',width:'100%',}}>
                    <View style={{width:'100%', flexDirection: 'row',}}>
                      <View style={{width:'95%',flexDirection: 'row', }}>
                      <Text style={{ color: 'white', paddingRight: 5, fontSize: 15 }}>{video?.user?.name}</Text>
                      {/* <Image
                        source={require("../../assets/Home/New/verified.png")}
                      /> */}
                      {user?.userinfo?.user.id!=video.user_id &&
                      <TouchableOpacity
                       onPress={()=>user?.userinfo?.user.id ? addfollow(video.user_id,video.follow_by_logged_user): props.navigation.navigate("Login")}
                        style={{ borderColor: video?.follow_by_logged_user ? "#08DDFD" : "white", borderWidth: 1, marginLeft: 2, borderRadius: 10, padding: 2 }}>
                        <Text style={{ color: video?.follow_by_logged_user ? "#08DDFD" : "white", fontSize: 12, padding: 2 }}>{video?.follow_by_logged_user ? 'Siguiendo' : 'Seguir'} </Text>
                        </TouchableOpacity>
                      }
                      </View>
                     <TouchableOpacity  onPress={() => user?.userinfo?.user.id ? (stop(index), goreport(index, video.id,video?.user?.id)) : props.navigation.navigate("Login")} style={{paddingLeft:4,paddingRight:4}} >
                       <Image  style={{  }} source={require("../../assets/images/reportvideo_call.png")} />
                      </TouchableOpacity>
                    </View>
                  </ContentLeftBottomNameUser>
                  <ContentLeftBottomDescription style={{ top: '20%' }} numberOfLines={3}>
                    {video?.description.length > 40 ?
                      <>
                        {!showMore ?
                          <Text style={{ color: 'white' }}>
                            {video?.description.substring(0, 40)}...
                          </Text>
                          :
                          <Text style={{ color: 'white' }}>
                            {video?.description}
                          </Text>
                        }
                        <Text onPress={() => setShowMore(!showMore)} style={{ color: '#08DDFD' }}>
                          {' '}  {!showMore ? 'Leer más' : 'Leer menos'}
                        </Text>
                      </>

                      :
                      <Text style={{ color: 'white' }}>
                        {video?.description}
                      </Text>
                    }

                  </ContentLeftBottomDescription>

                  <ContentLeftBottomDescription style={{ top: '20%', color: "#08DDFD" }} numberOfLines={3}>
                     {video?.chennelName.length > 40 ?
                      <>
                        {!showMore2 ?
                          <Text style={{ color: '#08DDFD' }}>
                            {video?.chennelName.substring(0, 40)}...
                          </Text>
                          :
                          <Text style={{ color: '#08DDFD' }}>
                            {video?.chennelName}
                          </Text>
                        }
                        <Text onPress={() => setShowMore2(!showMore2)} style={{ color: 'white' }}>
                          {' '}  {!showMore2 ? 'Leer más' : 'Leer menos'}
                        </Text>
                      </>
                      :
                      <Text style={{ color: '#08DDFD' }}>
                        {video?.chennelName}
                      </Text>
                    } 
                  </ContentLeftBottomDescription>
                  <View style={{ position: 'relative', top: 40, right: 1, flexDirection: "row", width: '100%', justifyContent: 'space-between', alignItems: 'center', alignContent: 'center' }}>
                    <TouchableOpacity
                      //onPress={() => navigation.navigate(NAVIGATION.UserProfile,{creater_id:video.user_id})}
                     // onPress={() => user?.userinfo?.user.id ? navigation.navigate(user?.userinfo?.user.id==video.user_id?NAVIGATION.MyProfile:NAVIGATION.UserProfile, { creater_id: video.user_id }) : props.navigation.navigate("Login")}
                      onPress={() => user?.userinfo?.user.id ? (stop(index),navigation.navigate(user?.userinfo?.user.id==video.user_id? NAVIGATION.MyProfile:NAVIGATION.UserProfile, { creater_id: video.user_id })) : (stop(index),props.navigation.navigate("Login"))}

                      style={{ borderWidth: 3, borderRadius: 30, borderColor: 'white', marginBottom: 10 }}>
                      <Image
                        style={{ width: 45, height: 45, borderRadius: 60, position: 'relative' }}
                        source={{ uri: video?.user?.image }}
                      />
                    </TouchableOpacity>
                    <TouchableOpacity
                      //onPress={addlike(video.id)}
                      onPress={() => user?.userinfo?.user.id ? addlike(video.id, video.like_by_logged_user) : props.navigation.navigate("Login")}
                    >
                      <Image
                        style={{ tintColor: video.like_by_logged_user ? '#08DDFD' : 'white' }}
                        source={require("../../assets/Home/New/inactivelikeIcon.png")}
                      />
                      <Text style={{ paddingTop: 7, color: '#FFFFFF', fontFamily: FONTS.PoppinsRegular, fontSize: 13, fontWeight: '500', alignContent: 'center', textAlign: "center" }}>{video.like_count ? video.like_count : 0}</Text>
                    </TouchableOpacity>
                    <TouchableOpacity
                      onPress={() => user?.userinfo?.user.id ? addfav(video.id, video.favourite_by_logged_user) : props.navigation.navigate("Login")}
                    >
                      <Image
                        style={{ tintColor: video.favourite_by_logged_user ? '#08DDFD' : 'white' }}
                        source={require("../../assets/Home/New/save.png")}
                      />
                      <Text style={{ textAlign: "center", paddingTop: 7, color: '#FFFFFF', fontFamily: FONTS.PoppinsRegular, fontSize: 13, fontWeight: '500' }}>{video.favourite_count ? video.favourite_count : 0}</Text>
                    </TouchableOpacity>
                    <TouchableOpacity
                      onPress={() => user?.userinfo?.user.id ? (stop(index),props.navigation.navigate("Commentslist", { video_id: video.id,callbycommentfun:callbycomment })) : props.navigation.navigate("Login")}
                    // onPress={()=>user?.userinfo?.user.id ? setShowModal(true): props.navigation.navigate("Login")}
                    >
                      <Image
                        source={require("../../assets/Home/New/CommentIcon.png")}
                      />
                      <Text style={{ textAlign: "center", paddingTop: 7, color: '#FFFFFF', fontFamily: FONTS.PoppinsRegular, fontSize: 13, fontWeight: '500' }}> {video.comment_count ? video.comment_count : 0}</Text>

                    </TouchableOpacity>
                    <TouchableOpacity onPress={() => user?.userinfo?.user.id ? onShare(video.id) : props.navigation.navigate("Login")}>
                      <Image
                        source={require("../../assets/Home/New/SharedIcon.png")}
                      />
                      <Text style={{ paddingTop: 7, color: '#FFFFFF', fontFamily: FONTS.PoppinsRegular, fontSize: 13, fontWeight: '500' }}> </Text>

                    </TouchableOpacity>
                  </View>
                </ContentLeftBottom>
              </View>
            ))
            :
            <View style={{ backgroundColor: "black", alignSelf: 'center', justifyContent: 'center', alignItems: 'center', alignContent: 'center' }}>
               <Image
                        
                        style={{width:'30%',height:'30%'}}
                        source={require("../../assets/Home/New/empty_records_icon.png")}
                      />
            </View>
        }

      </PagerView>
  </View>
   {/* </ImageBackground> */}
   </View>
  );
};

export default Selfvideolist;
