import { Apiurl } from "@/constants/Apiurl";
import { getExtension } from "@/helper/GlobalMethods";
import AsyncStorage from '@react-native-async-storage/async-storage';
import axios from "axios";
import { useEffect, useState } from "react";
import { ActivityIndicator, Alert, Dimensions, Image, ImageBackground, Modal, Platform, StatusBar, Text, TouchableOpacity, View } from "react-native";
import { createThumbnail } from 'react-native-create-thumbnail';
import { MultiSelect } from 'react-native-element-dropdown';
import { showMessage } from "react-native-flash-message";
import ImagePicker from "react-native-image-crop-picker";
import { KeyboardAwareScrollView } from 'react-native-keyboard-aware-scroll-view';
import { PERMISSIONS, RESULTS, check, request } from "react-native-permissions";
import { moderateScale, scale, verticalScale } from "react-native-size-matters";
import Video from 'react-native-video';
import { useDispatch, useSelector } from "react-redux";
import { logout } from "../../actions/UserActions";
import { Header } from "../../components/Header";
import { InputField } from "../../components/InputField";
import { getUser } from "../../selectors/UserSelectors";
import { FONTS } from "../../theme/fonts";
import { styles } from "./AddVideoBlinkstyles";

const AddVideoBlink = (props) => {
  const dispatch = useDispatch();
  const { navigation, route } = props;

  const user = useSelector(getUser);
  const [btndisabled, setbtndisabled] = useState(false);
  const [selected, setSelected] = useState([]);
  const [isFocus, setIsFocus] = useState(false);

  const [fullName, setFullName] = useState("");
  const [email, setemail] = useState("");
  const [email_collaboration, setemail_collaboration] = useState("");
  const [Videopath, setVideo] = useState();
  const [videoData, setVideoData] = useState();
  const [pausetatus, setpausestatus] = useState(true);
  const [description, setdescription] = useState('');
  const [animating, setAnimating] = useState(false);
  const [isModalVisiblee, setModalVisiblee] = useState(false);
  const [paymentStatus, setpaymentStatus] = useState('');
  const [channel_name, setchannel_name] = useState('');
  const [image, setImage] = useState(null);
  const [thumbpath, setthumbpath] = useState('');
  const [chnlList, setchnlList] = useState([]);
  const [isModalVisiblee1, setModalVisiblee1] = useState(false);



  useEffect(() => {
    AsyncStorage.getItem('auth_token').then(async (datatoken) => {
      axios({
        url: Apiurl + "user/payment-status",

        method: "GET",

        //  data: {"video_id":video_id,"favourite_status":status==true?2:1},
        headers: {
          Accept: "application/json",
          Authorization: "Bearer " + datatoken,
        },
      })
        .then((response) => {
          // console.log(response.data?.paymentStatus)
          if (response.data?.paymentStatus == false) {
            navigation.navigate(NAVIGATION.Membership)

          }
          setpaymentStatus(response.data?.paymentStatus)


        })
        .catch(function (error) {
          console.log("error", error);
          if(error?.response?.data?.message=='Unauthorized')
          {
           dispatch(logout());
          }
        });
    });
    getchannellist()
  }, []);
  const toggleModall = () => {
    setModalVisiblee(!isModalVisiblee);
  };
  const getchannellist = () => {
    axios({
      url: Apiurl + "video/chennel-list",

      method: "GET",

      //  data: {"video_id":video_id,"favourite_status":status==true?2:1},
      headers: {
        Accept: "application/json",
        //  Authorization:"Bearer "+datatoken,
      },
    })
      .then((response) => {
        //console.log(response.data?.result)
        setchnlList(response.data?.result)
      })
      .catch(function (error) {
        console.log("error", error);
      });
  };
  const takeFromCamera = () => {
    setModalVisiblee(false);
    ImagePicker.openCamera({
      mediaType: 'video',
      width: 300,
      height: 400,
      // cropping: true,
      // cropperToolbarWidgetColor: '#5A67FC',
      // cropperActiveWidgetColor: '#5A67FC',
    }).then(video => {
      // alert(45)
      if (video?.duration / 1000 <= 15) {
       // generateThumbnail(video.path)
        setVideo(video.path);
        setVideoData(video)
      }
      else {
        Alert.alert(
          `Agregue un video de máximo 15 segundos`,
          "",
          [
            { text: "DE ACUERDO", onPress: () => { } }

          ],
        );
      }

      //   uploadImages(video);
    })
      .catch(error => {
        console.log(error)
        if (error.code === "E_NO_CAMERA_PERMISSION") {
          // alert(error);
          // Alert.alert(
          //   `Turn on camera permission .`,
          //   "",
          //   [
          //     { text: "Go to Settings", onPress: () => Linking.openSettings() },
          //     { text: "Don't Use Photos", onPress: () => { } },
          //   ],
          // );
          setModalVisiblee(false);
        }
      });

  }
  const chooseFromGalleryimage = async () => {
    setModalVisiblee1(false);
    const response = check(
      Platform.select({
        ios: PERMISSIONS.IOS.CAMERA,
        android: PERMISSIONS.ANDROID.CAMERA,
      })
    );
    if (response !== RESULTS.GRANTED && response !== RESULTS.UNAVAILABLE) {
      request(Platform.OS === 'ios' ? PERMISSIONS.IOS.CAMERA : PERMISSIONS.ANDROID.CAMERA).then((result) => {
      });

    }
    else {
      request(Platform.OS === 'ios' ? PERMISSIONS.IOS.CAMERA : PERMISSIONS.ANDROID.CAMERA).then((result) => {
      });
    }
    ImagePicker.openPicker({
      mediaType: 'photo',
      width: 300,
      height: 400,
    }).then(image => {
        console.log(image.path)
        uploadthumb(image)
    })
      .catch(error => {
        console.log(error)
        if (error.code === "E_NO_CAMERA_PERMISSION") {
        }
      });
  }
  const toggleModallimage = () => {
    setModalVisiblee1(!isModalVisiblee1);
  };
  const chooseFromGallery = () => {
    setModalVisiblee(false);
    const response = check(
      Platform.select({
        ios: PERMISSIONS.IOS.CAMERA,
        android: PERMISSIONS.ANDROID.CAMERA,
      })
    );
    if (response !== RESULTS.GRANTED && response !== RESULTS.UNAVAILABLE) {
      request(Platform.OS === 'ios' ? PERMISSIONS.IOS.CAMERA : PERMISSIONS.ANDROID.CAMERA).then((result) => {
      });

    }
    else {
      request(Platform.OS === 'ios' ? PERMISSIONS.IOS.CAMERA : PERMISSIONS.ANDROID.CAMERA).then((result) => {
      });
    }

    ImagePicker.openPicker({
      mediaType: 'video',
    }).then(async (video) => {

      if (video?.duration / 1000 <= 15) {
       // generateThumbnail(video.path)
        setVideo(video.path);
        setVideoData(video)
      }
      else {
        Alert.alert(
          `Agregue un video de máximo 15 segundos`,
          "",
          [
            { text: "DE ACUERDO", onPress: () => { } }

          ],
        );
      }


      //uploadImages(video);
    })
      .catch(error => {
        if (error.code === "E_NO_LIBRARY_PERMISSION") {
          // setModalVisiblee(false);
          // Alert.alert(
          //   `Active el permiso de la biblioteca de fotos para permitir el acceso a su galería de fotos para cargar fotos`,
          //   "",
          //   [
          //     { text: "Ir a la configuración", onPress: () => Linking.openURL('app-settings:') },
          //     { text: "No use fotos", onPress: () => { } },
          //   ],
          // );
        }
      });
  };

  const uploadthumb = async (responsethumb) => {
    AsyncStorage.getItem('auth_token').then(async (datatoken) => {
      const formData = new FormData();
      const fileimageData = {
        uri:
          Platform.OS === "android"
            ? responsethumb.path
            : responsethumb.path.replace("file://", ""),

        type: responsethumb.mime,
        name: `thumb_.jpg`,
      };
      console.log("check image data ", fileimageData);
      formData.append("file", fileimageData);
      axios({
        url: "https://youuup.es/mobile-api/video/create-video-thumbnail",
        method: "POST",
        data: formData,
        headers: {
          "Content-Type": "multipart/form-data",
          Accept: "application/json",
          Authorization: "Bearer " + datatoken,
        },
      })
        .then((resp) => {
          setthumbpath(resp.data.path)
          showMessage({
            message: "Miniatura agregada con éxito, agregue video",
            type: "success",
          });
          //  resolve(resp.data.payload.url);
          // setVideoUri(resp.data.payload.url);
        })
        .catch((error) => {
          console.log('error',error)
          showMessage({
            message: "Error Vuelva a intentarlo",
            type: "danger",
          });
        }
          // console.error("opdioeueo", error)
        );
    });
  };
  const PopUp1 = () => {
    return (
      <Modal style={{zIndex:9999999999}} transparent visible={isModalVisiblee1}>
        <View
          style={{
            flex: 1,
            backgroundColor: "#000000aa",
            padding: 20,
            justifyContent: "center",
          }}
        >
          <View style={{
            backgroundColor: "white", backgroundColor: "#FFFFFF",
            padding: 20,
            borderRadius: moderateScale(20),
          }}>
            <Text
              style={{
                color: "#43686A",
                fontSize: moderateScale(20),
                fontFamily: FONTS.PoppinsSemiBold,
              }}
            >
              Cargar imagen
            </Text>
            <View
              style={{
                flexDirection: "row",
                alignItems: "center",
                marginTop: verticalScale(10),
              }}
            >
              <Image source={require("../../assets/Home/gallery.png")} />
              <TouchableOpacity onPress={chooseFromGalleryimage}>
                <Text
                  style={{
                    color: "#738485",
                    fontFamily: FONTS.PoppinsRegular,
                    fontSize: moderateScale(18),

                    marginLeft: moderateScale(10),
                  }}
                >
                  Elegir de la galería
                </Text>
              </TouchableOpacity>
            </View>
           
            <TouchableOpacity
              style={{ justifyContent: "center", alignItems: "center" }}
              onPress={toggleModallimage}
            >
              <Text
                style={{
                  color: "#05A1AB",
                  marginTop: verticalScale(10),
                  fontFamily: FONTS.PoppinsMedium,
                  fontSize: moderateScale(16),
                }}
              >
                Cancelar
              </Text>
            </TouchableOpacity>
          </View>
        </View>
      </Modal>
    );
  };
  const generateThumbnail = async (filepath) => {
    try {
      const response = await createThumbnail({
        url: filepath,
        timeStamp: 1,
      });
      setImage(response);
      uploadthumb(response)
    } catch (e) {
      console.warn(e);
    }
  };
  const uploadImages = async (videoData) => {
    if (selected.length > 0) {
      setbtndisabled(true)
      setAnimating(true)
     // console.log(videoData)
      AsyncStorage.getItem('auth_token').then(async (datatoken) => {
        console.log(datatoken)
        const formData = new FormData();

        const fileExtension = getExtension(videoData.path);
        const imageData = {
          uri:
            Platform.OS === "android"
              ? videoData.path
              : videoData.path.replace("file://", ""),

          type: videoData.mime,

          name: `video_.${fileExtension}`,
        };

        console.log("check image data ", imageData);

        formData.append("user_id", user && user?.userinfo?.user.id);
        formData.append("video_type", 3);
        formData.append("url", imageData);
        formData.append("description", description);
        formData.append("channel_name", selected);
        //formData.append("video_thumbnail", thumbpath);
        formData.append("video_thumbnail", thumbpath ? thumbpath : null);

        console.log(formData)
        axios({
          url: "https://youuup.es/mobile-api/video/create",

          method: "POST",

          data: formData,

          headers: {
            "Content-Type": "multipart/form-data",
            Accept: "application/json",
            Authorization: "Bearer " + datatoken,

          },
        })
          .then((resp) => {
            setbtndisabled(false)
            console.log(resp)
            setAnimating(false)
            showMessage({
              message: "video subido con exito",
              type: "success",
            });
            setVideo('');
            setVideoData('')
            setdescription('')
            setthumbpath('')
            setSelected([])
            //  resolve(resp.data.payload.url);
            // setVideoUri(resp.data.payload.url);
          })
          .catch((error) => {
            console.log(error)

            showMessage({
              message: "video No cargando.",
              type: "danger",
            }); 
            setAnimating(false)
            setbtndisabled(false)

          }
            // console.error("opdioeueo", error)
          );
      });
    }
    else {
      showMessage({
        message: "Por favor seleccione canales.",
        type: "danger",
      });
    }
  };
  const PopUp2 = () => {
    return (

      <Modal transparent visible={isModalVisiblee}>
        <View
          style={{
            flex: 1,
            backgroundColor: "#000000aa",
            padding: 20,
            justifyContent: "center",
          }}
        >
          <View style={{
            backgroundColor: "white", backgroundColor: "#FFFFFF",
            padding: 20,
            borderRadius: moderateScale(20),
          }}>
            <Text
              style={{
                color: "#43686A",
                fontSize: moderateScale(20),
                fontFamily: FONTS.PoppinsSemiBold,
              }}
            >
              Cargar vídeo
            </Text>
            <View
              style={{
                flexDirection: "row",
                alignItems: "center",
                marginTop: verticalScale(10),
              }}
            >
              <Image source={require("../../assets/Home/gallery.png")} />
              <TouchableOpacity onPress={chooseFromGallery}>
                <Text
                  style={{
                    color: "#738485",
                    fontFamily: FONTS.PoppinsRegular,
                    fontSize: moderateScale(18),

                    marginLeft: moderateScale(10),
                  }}
                >
                  Elegir de la galería
                </Text>
              </TouchableOpacity>
            </View>
            <View
              style={{
                flexDirection: "row",
                alignItems: "center",
                marginTop: verticalScale(10),
              }}
            >
              <Image
                style={{ width: scale(19), height: scale(17), tintColor: "#43686A" }}
                source={require("../../assets/Drawer/shortvideo.png")}
              />
              <TouchableOpacity onPress={takeFromCamera}>
                <Text
                  style={{
                    color: "#738485",
                    fontFamily: FONTS.PoppinsRegular,
                    fontSize: moderateScale(18),
                    marginLeft: moderateScale(10),
                  }}
                >
                  Grabar un video
                </Text>
              </TouchableOpacity>
            </View>
            <TouchableOpacity
              style={{ justifyContent: "center", alignItems: "center" }}
              onPress={toggleModall}
            >
              <Text
                style={{
                  color: "#05A1AB",
                  marginTop: verticalScale(10),
                  fontFamily: FONTS.PoppinsMedium,
                  fontSize: moderateScale(16),
                }}
              >
                Cancelar
              </Text>
            </TouchableOpacity>
          </View>
        </View>
      </Modal>
    );
  };
  const savedata = async (videoData) => {
    if(!thumbpath || thumbpath=='')
   {
     Alert.alert('Agregue una imagen en miniatura del video')
   }
   else if(!Videopath || Videopath=='')
   {
     Alert.alert('Por favor agregue video')
   }
   else if(!description || description=='')
   {
     Alert.alert('Por favor ingrese la descripción')
   }
   else if(selected.length==0)
   {
     Alert.alert('Por favor seleccione Canales')
   }
   else{
   uploadImages(videoData)
   }
 }
  return (
    <ImageBackground
      style={{ flex: 1, }}
      resizeMode={"stretch"}
      backgroundColor={'black'}
      source={require("../../assets/images/editprofileback.png")}
    >

      <StatusBar translucent backgroundColor="transparent" />
      <Header back={true} {...props} title='Blink' subtitle='Vídeo máximo 15 segundos' />
      {/* {showModal && <PopUp />} */}
      {isModalVisiblee1 && <PopUp1 />}
      {isModalVisiblee && <PopUp2 />}
      <KeyboardAwareScrollView>
        <View style={styles.mainContainer}>
    
          {paymentStatus == true ?

            <View style={{ alignContent: 'flex-end', marginTop: 80, alignSelf: "center", justifyContent: 'center', alignItems: 'center' }}>
              <View style={{ margin: 10, marginLeft: 10, marginRight: 10,width:Dimensions.get('window').width/1.1}}>
                <TouchableOpacity onPress={() => chooseFromGalleryimage()} style={{marginBottom:10, flexDirection:'row', justifyContent:'flex-start',alignContent:'center',alignItems:'center', width: '67%', height: 30, backgroundColor: "#08DDFD", borderRadius: 5}}>
                <Image style={{marginLeft:5,tintColor:"white"}} source={require("../../assets/Home/gallery.png")} />
                <Text style={{paddingLeft:10, fontSize: 17, color: 'white', fontFamily: FONTS.PoppinsRegular, }}>{'Agregar portada'}</Text>
                </TouchableOpacity>
              </View>
              <View style={{}}>
                {Videopath ? (
                  <>
                    <Video
                      style={styles.backgroundVideo}
                      source={{ uri: Videopath }}
                      poster={Apiurl + thumbpath}
                      posterResizeMode="cover"
                      paused={pausetatus}
                      resizeMode="cover"
                      onTouchStart={() =>
                        setpausestatus(!pausetatus)
                      }
                    />
                    {pausetatus &&
                      <TouchableOpacity style={{ zIndex: 9999999, position: "absolute",alignSelf:'center', bottom: '50%'}}
                        onPress={() => setpausestatus(!pausetatus)}
                      >
                        <Image style={{ alignSelf: 'center' }} resizeMode='center' source={require("../../assets/splash/Shape.png")} />
                      </TouchableOpacity>
                    }
                  </>
                ) : (
                  <ImageBackground resizeMode="stretch"  style={{width:360,
                    height:500,}}  source={{ uri: Apiurl+thumbpath }}>
                  <TouchableOpacity onPress={toggleModall} style={{
                     alignItems: 'center', justifyContent: 'center', width: Dimensions.get('window').width-40,alignSelf:'center',
                    height: 500, borderWidth: 1, borderColor: 'white', borderRadius: 10, borderStyle: 'dashed'
                  }}>

                    <Image style={{
                      width: 131,
                      height: 130,
                      borderRadius: moderateScale(70),
                      tintColor: '#08DDFD'
                    }} source={require("../../assets/images/videoaddicon.png")} />
                  </TouchableOpacity>
                  </ImageBackground>

                )}

              </View>
              <View style={{ width: Dimensions.get('window').width / 1.1, margin: 10, marginLeft: 10, marginRight: 10 }}>
                <Text style={styles.placeNameTextStyle}>Descripción</Text>
                <InputField
                  onChangeText={(text) => {
                    setdescription(text)
                  }}
                  numberOfLines={5}
                  multiline={true}
                  value={description}
                  color={"white"}
                  mainViewStyle={{ width: 350 }}
                  maxLength={86}
                  // style={{width:'80%'}}
                  // icon={"account"}
                  // title={"Full Name"}
                  //  placeholder={"Ingresar Nombre o nick"}
                  placeholderColor={"white"}
                />
              </View>
              <View style={{ width: Dimensions.get('window').width / 1.1, margin: 10, marginLeft: 10 }}>
                <Text style={styles.placeNameTextStyle}>Canales</Text>
              </View>
              <View style={{ margin: 10, marginLeft: 10, marginRight: 10 }}>
                <View
                  style={{
                    zIndex: 1000,
                    borderRadius: moderateScale(15),
                    borderRadius: 25,
                    height: 60,
                    justifyContent: 'center',
                    alignContent: 'center'
                  }}
                >

                  <MultiSelect
                    style={{
                      height: 70,
                      paddingHorizontal: 10,
                      backgroundColor: 'red',
                      marginTop: 50,
                      borderRadius: 25,
                      color: 'white',
                      position: "absolute",
                      alignSelf: 'center',
                      // justifyContent:'left',
                      width: Dimensions.get('window').width / 1.1,
                      backgroundColor: isFocus ? "rgba(26, 91, 101, 1)" : "rgba(97, 156, 165, 0.09)"
                    }}
                    placeholderStyle={styles.placeholderStyle}
                    selectedTextStyle={styles.selectedTextStyle}
                    inputSearchStyle={styles.inputSearchStyle}
                    activeColor={'darkgray'}
                    itemTextStyle={{color:'black'}}
                    iconStyle={styles.iconStyle}
                    // search
                    //dropdownPosition={"bottom"}
                    data={chnlList}
                    labelField="channel_name"
                    valueField="id"
                    placeholder={!isFocus ? '' : ''}
                    searchPlaceholder="Search..."
                    value={selected}
                    onChange={item => {
                      // alert(item)
                      if (item.length > 3) {
                        Alert.alert('información', 'Máximo etiquetar 3 canales por vídeo', [
                          { text: 'DE ACUERDO', onPress: () => console.log('OK Pressed') },
                        ]);

                      }
                      else {
                        setSelected(item);
                        setIsFocus(false);
                      }
                    }}
                    renderRightIcon={() => (
                      <Image
                        style={{ marginTop: verticalScale(20) }}

                        source={require("../../assets/reg/downarrow.png")}
                      />
                    )}
                    selectedStyle={{ marginLeft: 5, position: 'relative', backgroundColor: '#08DDFD', borderRadius: 9, }}
                  />
                </View>
              </View>
              <TouchableOpacity
                disabled={btndisabled}
                onPress={() => savedata(videoData)} style={{ justifyContent: "center", alignContent: 'center', alignItems: 'center', width: 150, height: 50, backgroundColor: "#08DDFD", borderRadius: 10, marginTop: 90, padding: 5, zIndex: 99999, position: 'relative', bottom: 30, alignSelf: "center", left: 15 }}>
                <Text style={{ fontSize: 16, color: 'white', fontFamily: FONTS.PoppinsRegular, }}>{Videopath ? 'Publicar vídeo' : 'Publicar vídeo'}</Text>
              </TouchableOpacity>
            </View>
            :
            <View style={{ marginTop: 80, justifyContent: "center", alignContent: 'center', alignItems: 'center' }}>
              <Text style={{ color: 'white', fontFamily: FONTS.PoppinsMedium, paddingTop: 100 }}>Actualice su membresía</Text>
            </View>
          }
        </View>
        {animating == true && (
          <ActivityIndicator
            animating
            color={'white'}
            size="large"
            style={styles.activityIndicator}
          />
        )}
      </KeyboardAwareScrollView>
    </ImageBackground>
  );
};

export default AddVideoBlink;
