import { StyleSheet } from 'react-native';
import { COLOR } from '../../constants/colors/colors';
import Scale, { scale, verticalScale } from '../../helper/Scale';
import { FONTS } from '../../theme/fonts';
export const styles = StyleSheet.create({
  underlineStyleBase: {
    width: 54,
    height: 65,
    borderWidth: 1,
    borderBottomWidth: 1,
    borderColor: '#619ca517',
    //opacity:0.09,
    borderRadius:15,
    color: COLOR.AppColor,
    fontSize: 32,
    paddingVertical: 5,
    fontWeight: '800',
    marginHorizontal: 10,
    fontFamily: FONTS.PoppinsMedium,
    backgroundColor:'#619ca517'
  },
  otpOuterView: {
    alignSelf: 'center',
    alignItems: 'center',
    justifyContent: 'center',
  },
  otpStyle: {
    width: '50%',
    height: 100,
    alignSelf: 'center',
    alignContent: 'center',
  },
  underlineStyleHighLighted: {
    borderBottomColor:'#619ca517',
  },

  loginContainer: {
    backgroundColor: 'white',
    height: verticalScale(400),
    position: 'absolute',
    bottom: -50,
    width: '100%',
    borderRadius: 50,
    paddingVertical: verticalScale(30),
    paddingHorizontal: scale(20),
  },
  formContainer: {
    borderRadius: 5,
    padding: 20,
    width: '100%',
  },
  submitButton: {
    marginTop: 30,
  },
  Title: {
    fontFamily: FONTS.PoppinsSemiBold,
    fontStyle: 'normal',
    fontSize: Scale.moderateScale(32),
    color: '#000000',
    fontWeight: '600',
  },
  TitleDis: {
    fontFamily: FONTS.PoppinsRegular,
    paddingTop: 10,
    fontSize: Scale.moderateScale(14),
    color: '#615B5B',
    fontWeight: '400',
  },
  textTitle: {
    fontFamily: FONTS.PoppinsRegular,
    paddingTop: 10,
    fontSize: Scale.moderateScale(14),
    color: '#313131',
    fontWeight: '400',
  },
  bottomView: {
    alignSelf: 'center',
    flexDirection: 'row',
    alignItems:'center',
    justifyContent:'center',
    alignContent:'center',
    marginTop: verticalScale(20),
    marginBottom:verticalScale(20)
  },
});
