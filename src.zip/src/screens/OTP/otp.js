import OTPInputView from "@twotalltotems/react-native-otp-input";
import { useCallback, useEffect, useState } from "react";
import {
  Image, ImageBackground, Text,
  TouchableOpacity, View
} from "react-native";
import { showMessage } from "react-native-flash-message";
import { KeyboardAwareScrollView } from 'react-native-keyboard-aware-scroll-view';
import { useDispatch } from "react-redux";
import { GetOtPRequestt, resendOtp } from "../../actions/UserActions";
import { Button } from "../../components/Button";
import { Header } from "../../components/Header";
import { COLOR } from "../../constants/colors/colors";
import { verticalScale } from "../../helper/Scale";
import { TextStyles } from "../../theme/TextStyles";
import { FONTS } from "../../theme/fonts";
import { styles } from "./otp.styles";

export default function OTP(props) {
  const dispatch = useDispatch();
  const { navigation, route } = props;
  const { data,resetpass } = route.params;
  const [Otpp, setOtpp] = useState("");
  const [timer, setTimer] = useState(30);
  const [active, setactive] = useState(timer == 0 ? false : true);
  useEffect(() => {
    //console.log('data',data)
 
 }, []);
 const timeOutCallback = useCallback(
  () => setTimer((currTimer) => currTimer - 1),
  []
);
useEffect(() => {
  timer > 0 ? setTimeout(timeOutCallback, 1000) : setactive(false);
}, [timer, timeOutCallback]);
  // const isLoading = useSelector(state =>
  //   isLoadingSelector([TYPES.LOGIN], state)
  // );

  // const errors = useSelector(
  //   state => errorsSelector([TYPES.LOGIN], state),
  //   shallowEqual
  // );
  const validation = () => {
    if (!Otpp.trim()) {
      showMessage({
        message: "Por favor ingrese OTP",
        type: "danger",
      });
    } else if (Otpp.length < 4) {
      showMessage({
        message: "Ingrese una OTP válida",
        type: "danger",
      });
    } else {
      OtpRequest();
    }
  };
  const OtpRequest = async () => {
   // console.log("email", email, Otpp);
    const dataapi = {
      email: data.email,
    //  role_id: 4,
      otp: Number(Otpp),
    };
   // navigation.navigate(NAVIGATION.home)
    dispatch(GetOtPRequestt(dataapi,resetpass?resetpass:''));
  };
  const resetTimer = function () {
    if (!timer) {
      setactive(true);
      setTimer(30);
    }
  };
  const OtpresenedRequest = async () => {
  //  console.log("email of resend otp request", email);
    const dataresend = {
      email: data.email,
    };
    dispatch(resendOtp(dataresend));
  };
  return (
    <>
        <ImageBackground
      style={{ flex: 1,  }}
      resizeMode={"stretch"}
      backgroundColor={'black'}
      source={require("../../assets/splash/bg.png")}
    >
        <Header back={true} {...props} />
        <KeyboardAwareScrollView>

        <View style={{ marginTop: verticalScale(60), alignSelf: "center" }}>
        <Image source={require("../../assets/splash/Logo.png")} />
      </View>
      {/* <Text style={TextStyles.title}>Keep it Real</Text> */}

        <View style={{ padding: 30 }}>
        <Text style={TextStyles.titlereglabel}>Introduce el código que te hemos enviado por email. </Text>
          <View style={styles.otpOuterView}>
          <OTPInputView
              onCodeChanged={(Otpp) => {
                setOtpp(Otpp);
              }}
              style={styles.otpStyle}
              pinCount={4}
              selectionColor={COLOR.AppColor}
              autoFocusOnLoad={false}
              codeInputFieldStyle={styles.underlineStyleBase}
              codeInputHighlightStyle={styles.underlineStyleHighLighted}
              onCodeFilled={(code) => {
                // setOtpp(code);
              }}
            />
          </View>
          <View style={styles.bottomView}>
            <Text style={[TextStyles.resendlable, { fontSize: 14 }]}>
            ¿No has recibido el código?{" "}
            </Text>
            <TouchableOpacity 
          // style={{backgroundColor:"red"}}
             activeOpacity={0.2}
            disabled={active}
              onPress={() => {
               // resetTimer();
                OtpresenedRequest();
              }} >
              {active ? (
                <Text
                  style={{
                    fontFamily: FONTS.PoppinsMedium,
                    fontSize: 14,
                    color: COLOR.AppColor,
                  }}
                >
                  Reenviar
                </Text>
              ) : (
                <Text
                  style={{
                    fontFamily: FONTS.PoppinsMedium,
                    fontSize: 14,
                    color: COLOR.AppColor,
                  }}
                >
                  Reenviar
                </Text>
              )}
            </TouchableOpacity>
            {/* {timer <= 0 ? (
              <Text></Text>
            ) : (
              <Text style={{ marginLeft: moderateScale(5) }}>
                {"(" + timer + ")"}
              </Text>
            )} */}
          </View>
          <Button onPress={validation}  title={"Enviar"} />

        </View>
        </KeyboardAwareScrollView>
      </ImageBackground>
    </>
  );
}
