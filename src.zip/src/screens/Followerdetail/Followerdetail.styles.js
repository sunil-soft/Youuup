import { StyleSheet } from "react-native";
import { moderateScale, scale } from "react-native-size-matters";
import { verticalScale } from "../../helper/Scale";
import { FONTS } from "../../theme/fonts";

export const styles = StyleSheet.create({
  backImage: {
    position: "absolute",

    width: "100%",
    height: "42%",
    //   resizeMode: 'center',
  },

  MyprofileText: {
    fontSize: moderateScale(19),
    color: "#FFFFFF",
    fontFamily: FONTS.PoppinsSemiBold,
    marginLeft: verticalScale(10),
  },
  setstatusStyle: {
    color: "#FFFFFF",
    fontSize: moderateScale(14),
    fontFamily: FONTS.PoppinsRegular,
  },
  RadiologyStyle: {
    fontSize: moderateScale(11),
    color: "#FFFFFF",
    fontFamily: FONTS.PoppinsRegular,
    paddingTop:10,
    paddingLeft:20,
    paddingRight:20
  },
  gmailStyle: {
    fontSize: moderateScale(11),
    color: "#FFFFFF",
    fontFamily: FONTS.PoppinsRegular,
    marginTop: verticalScale(5),
  },
  adressStyle: {
    fontSize: scale(16),
    color: "#43686A",
    fontFamily: FONTS.PoppinsRegular,
    marginLeft: moderateScale(5),
  },
  overViewStyle: {
    fontSize: scale(16),
    color: "#43686A",
    fontFamily: FONTS.PoppinsSemiBold,
    marginTop: verticalScale(8),
  },
  followtext:
  {color:'#E6E6E6',textAlign:'center',fontSize:17},
  followtextlabel:
  {color:'#8C8D91',textAlign:'center',fontSize:12},
  label:
  {
    color:'#FFFFFF',
    paddingLeft:6
  },
  rowview:
  {
    flexDirection:'row',
    justifyContent:'center',
    alignContent:"center",
    alignItems:'center'
  },
  backgroundVideo: {
  //  width:105,
  //  height:153,
 //  borderRadius:50
 borderRadius: moderateScale(15),

 //margin:10,
// marginTop:7,
 //backgroundColor:"white"
   // alignItems: "center",
  //   position: "absolute",
  //  height: 300,
  //   left: 0,
  //   top: 0,
  //   right: 0,
  //   bottom: 0,
},
activityIndicator: {
  position: 'absolute',
  left: 0,
  right: 0,
  top: 50,
  bottom: 0,
  alignItems: 'center',
  justifyContent: 'center',
  zIndex: 9999,
 // backgroundColor:'translucent'
},
modalView: {
  flex: 1,
  backgroundColor: '#000000aa',
  padding: 20,
  justifyContent: 'center',
},
modalInnerView: {
  backgroundColor: 'white',
  borderRadius: 15,
  padding: verticalScale(20),
  paddingVertical: verticalScale(20),
},
modalTitleTxt: {
  fontFamily: FONTS.PoppinsSemiBold,
  color: '#43686A',
  fontSize: 20,
},
modalContentView: {
  // paddingRight: verticalScale(30),
  // borderBottomWidth: 2,
  // borderBottomColor: '#EBF0F1',
  // paddingVertical: verticalScale(0),
  paddingBottom:20,
},dropdown: {
  // marginTop:20,
   height: 70,
   paddingHorizontal: 10,
   borderRadius:25,
   color:'white',
   borderColor: '#08DDFD', borderWidth: 1, borderRadius: 12,
   marginBottom:10
 },
 icon: {
   marginRight: 5,
 },
 label2: {
   position: 'absolute',
   backgroundColor: 'white',
   left: 22,
   top: 8,
   zIndex: 999,
   paddingHorizontal: 8,
   fontSize: 14,
 },
 placeholderStyle: {
   fontSize: 16,
 },
 selectedTextStyle: {
   fontSize: 16,
   color:'black'
 },
 iconStyle: {
   width: 20,
   height: 20,
 },
 inputSearchStyle: {
   height: 40,
   fontSize: 16,
 },
 activityIndicator: {
   position: 'absolute',
   left: 0,
   right: 0,
   top: 50,
   bottom: 0,
   alignItems: 'center',
   justifyContent: 'center',
   zIndex: 9999,
 },
 placeNameTextStyle: {
   color: "black",
   fontSize: moderateScale(15),
   fontWeight:'400',
   fontFamily: FONTS.PoppinsRegular,
  //marginLeft: moderateScale(10),
  marginBottom:10
 },
});

