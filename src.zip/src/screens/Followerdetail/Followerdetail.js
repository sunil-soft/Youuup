import AsyncStorage from '@react-native-async-storage/async-storage';
import { useFocusEffect } from "@react-navigation/native";
import axios from "axios";
import React, { useState } from "react";

import { Apiurl } from "@/constants/Apiurl";
import { ActivityIndicator, FlatList, Image, Linking, Modal, ScrollView, StatusBar, Text, TextInput, TouchableOpacity, View } from "react-native";
import { moderateScale, verticalScale } from "react-native-size-matters";
import { logout } from "../../actions/UserActions";

import moment from 'moment/min/moment-with-locales';
import { Dropdown } from 'react-native-element-dropdown';
import { showMessage } from "react-native-flash-message";
import { useDispatch, useSelector } from "react-redux";
import { Createrprofileapi, Creatervideosapi } from "../../actions/UserActions";
import { Header } from "../../components/Header";
import { NAVIGATION } from "../../constants";
import { getUser } from "../../selectors/UserSelectors";
import { FONTS } from "../../theme/fonts";
import { styles } from "./Followerdetail.styles";
moment.locale('es')
// const APIBASEURL = 'https://youuup.com/youuupapi/'
const APIBASEURL = 'https://youuup.es/mobile-api/'

const DATA = [
  {
    id: 'bd7acbea-c1b1-46c2-aed5-3ad53abb28ba',
    title: 'First Item',
  },
  {
    id: '3ac68afc-c605-48d3-a4f8-fbd91aa97f63',
    title: 'Second Item',
  },
  {
    id: '58694a0f-3da1-471f-bd96-145571e29d72',
    title: 'Third Item',
  },
  {
    id: '58694a0f-3da1-471f-bd96-145571e29d72',
    title: 'Third Item',
  },
  {
    id: '58694a0f-3da1-471f-bd96-145571e29d72',
    title: 'Third Item',
  },
  {
    id: '58694a0f-3da1-471f-bd96-145571e29d72',
    title: 'Third Item',
  },
  {
    id: '58694a0f-3da1-471f-bd96-145571e29d72',
    title: 'Third Item',
  },
];
let rptselectopnreason = ''
const Followerdetail = (props) => {
  const dispatch = useDispatch();
  const { navigation, route } = props;
  const { creater_id, user_type_id } = route.params;
  const user = useSelector(getUser);

  const [animating, setAnimating] = useState(false);
  const [showpromocion, setshowpromocion] = useState(false);
  const [isModalVisiblee, setModalVisiblee] = useState(false);
  const [btnactivestatus, setactivestatus] = useState(0);
  const [blockedstatus, setblockedstatus] = useState(false);
  const [showModal, setShowModal] = useState(false);
  const [selectedSite, setSelectedSite] = useState(null);
  const [siteList, setSiteList] = useState(
    [
    { label: "Contenido sexual", value: "Contenido sexual" },
    { label: "Contenido violento o repulsivo", value: "Contenido violento o repulsivo" },
    { label: "Contenido que incite al odio o abusivo", value: "Contenido que incite al odio o abusivo" },
    { label: "Acoso o intimidación", value: "Acoso o intimidación" },
    { label: "Actos nocivos o peligrosos", value: "Actos nocivos o peligrosos" },
    { label: "Desinformación", value: "Desinformación" },
    { label: "Abuso infantil", value: "Abuso infantil" },
    { label: "Promueve el terrorismo", value: "Promueve el terrorismo" },
    { label: "Spam o engañoso", value: "Spam o engañoso" },
    { label: "Cuestión jurídica", value: "Cuestión jurídica" },
    { label: "Problema de subtítulos", value: "Problema de subtítulos" }
  ]
    );
  // const userData = useSelector(getProfile);
  useFocusEffect(
    React.useCallback(() => {
      // const response =  createThumbnail({
      //   url: "http://103.15.67.180:4006/data/videoUpload/1678715227353-butterfly-12060.mp4",
      //   timeStamp: parseInt(1000, 10),
      // });
      // console.log(response)
      UserProfilee();
     // alert(creater_id)

     // return () => unsubscribe;
    }, [])
  );
  const UserProfilee = () => {
    setAnimating(true)
    setTimeout(() => {
      setAnimating(false)
    }, 1000);
     console.log(creater_id)
    const data = {
      "user_id": creater_id,
      "video_type": 1,
      "offset": 0,
      "limit": 1000
    };
    dispatch(Creatervideosapi(data));
    const data2 = {
      "creator_id": creater_id,
    };
    console.log(creater_id)
    dispatch(Createrprofileapi(data2));

  };
  const handleInputSubmit = (ev) => {
    rptmessage = ev
  };
  const addfollow = (follow_to_id, status) => {

    // console.log({"follow_to_id":follow_to_id,"follow_status":status==true?2:1})
    AsyncStorage.getItem('auth_token').then(async (datatoken) => {
      console.log(datatoken)
      axios({
        url: APIBASEURL + "user/follow",
        method: "POST",
        data: { "follow_to_id": follow_to_id, "follow_status": status == true ? 2 : 1 },
        headers: {
          Accept: "application/json",
          Authorization: "Bearer " + datatoken,
        },
      })
        .then((response) => {
          console.log(response)
          UserProfilee()
          // videolistapi(activevideotype)
        })
        .catch(function (error) {
          console.log("error", error);
          if(error?.response?.data?.message=='Unauthorized')
          {
         
           dispatch(logout());
          }
        });
    });
  };
  const toggleModall = () => {
    setModalVisiblee(!isModalVisiblee);
  };

  const addreport = (status) => {
    setactivestatus(1)
    setShowModal(true)

  };

  const addreportsave = () => {

    setactivestatus(1)
    //alert(rptmessage)
    if (!rptselectopnreason) {
      showMessage({
        message: "Por favor seleccione razón",
        type: "danger",
      });
    }
    else if (!rptmessage.trim()) {
      showMessage({
        message: "Por favor Ingrese el mensaje de informe",
        type: "danger",
      });
    }
    else{
    // console.log({"follow_to_id":follow_to_id,"follow_status":status==true?2:1})
    AsyncStorage.getItem('auth_token').then(async (datatoken) => {
      console.log(datatoken)
      axios({
        url: Apiurl + "report/report-user",
        method: "POST",
        data: { "report_to_id": creater_id, "report_message": rptmessage },
        headers: {
          Accept: "application/json",
          Authorization: "Bearer " + datatoken,
        },
      })
        .then((response) => {
          console.log('response', response)
          setShowModal(false)
          showMessage({
            message: "Informe enviado exitosamente.",
            type: "success",
          });
          rptselectopnreason=''
          rptmessage=''

        })
        .catch(function (error) {
          console.log("error11", error);
        });
    });
  }
  };
  const addblock = (status) => {
    setactivestatus(2)
    AsyncStorage.getItem('auth_token').then(async (datatoken) => {
      console.log(datatoken)
      axios({
        url: Apiurl + "block/block-user",
        method: "POST",
        data: { "block_to_id": creater_id, "block_status": status },
        headers: {
          Accept: "application/json",
          Authorization: "Bearer " + datatoken,
        },
      })
        .then((response) => {
          //console.log('response', response)
          setblockedstatus(true)
          props.navigation.goBack()
        })
        .catch(function (error) {
          console.log("error11", error);
        });
    });
  };
  const formatCash = (n) => {
    if (n < 1e3) return n;
    if (n >= 1e3 && n < 1e6) return +(n / 1e3).toFixed(1) + "K";
    if (n >= 1e6 && n < 1e9) return +(n / 1e6).toFixed(1) + "M";
    if (n >= 1e9 && n < 1e12) return +(n / 1e9).toFixed(1) + "B";
    if (n >= 1e12) return +(n / 1e12).toFixed(1) + "T";
  };
  // const PopUp = () => {
  //   return (
  //     // <KeyboardAwareScrollView   keyboardShouldPersistTaps='handled'>
  //     <Modal transparent visible={showModal}>
  //       <View style={styles.modalView} keyboardShouldPersistTaps=''>
  //         <View style={styles.modalInnerView}>
  //           <View style={styles.modalContentView}>
  //             <TextInput
  //               //  ref={ref_input1}
  //               autoFocus={true}
  //               // ref={input => {
  //               //   this.nameOrId = input;
  //               // }}
  //               //value={report_message}
  //               numberOfLines={5}
  //               multiline={true}
  //               style={{ borderColor: '#08DDFD', borderWidth: 1, borderRadius: 12, padding: 10 }}
  //               placeholder="Ingrese el mensaje de informe"
  //               // onBlur={handleInputSubmit(ev)}
  //               onChangeText={(text) => handleInputSubmit(text)}
  //               // onBlur={alert(4)}

  //               // onChangeText={text => { setreport_message(text) }} 

  //               textAlignVertical='top'
  //             />



  //           </View>
  //           <View style={{ flexDirection: 'row', justifyContent: 'space-around' }}>
  //             <TouchableOpacity
  //               onPress={() => addreportsave()}
  //               style={{ width: 130, padding: 10, borderRadius: 12, backgroundColor: '#08DDFD', justifyContent: "center", alignContent: 'center', alignItems: 'center' }}
  //             >
  //               <Text style={{ color: "white", fontSize: 15, fontFamily: FONTS.PoppinsMedium }}>Enviar</Text>
  //             </TouchableOpacity>
  //             <TouchableOpacity
  //               onPress={() => setShowModal(false)}
  //               style={{ width: 130, padding: 10, borderRadius: 12, backgroundColor: '#08DDFD', justifyContent: "center", alignContent: 'center', alignItems: 'center' }}
  //             >
  //               <Text style={{ color: "white", fontSize: 15, fontFamily: FONTS.PoppinsMedium }}>Cancelar</Text>
  //             </TouchableOpacity>
  //           </View>
  //         </View>
  //       </View>
  //     </Modal>
  //     // </KeyboardAwareScrollView>
  //   );
  // };
  const PopUp = () => {
    return (
      // <KeyboardAwareScrollView   keyboardShouldPersistTaps='handled'>
      <Modal transparent visible={showModal}>
        <View style={styles.modalView} >
          <View style={styles.modalInnerView}>
          <Text style={styles.placeNameTextStyle}>Seleccionar motivo de denuncia</Text>
          <Dropdown
                style={[styles.dropdown]}
                placeholderStyle={styles.placeholderStyle}
                selectedTextStyle={styles.selectedTextStyle}
                inputSearchStyle={styles.inputSearchStyle}
                itemTextStyle={{color:'black'}}
                iconStyle={styles.iconStyle}
                containerStyle={{
                  bottom: verticalScale(25),
                }}
                data={siteList}
                search
                maxHeight={300}
                labelField="label"
                valueField="value"
              //  placeholder={!isFocus ? '' : ''}
              placeholder="Seleccionar motivo de denuncia"
                searchPlaceholder="Buscar..."
                value={selectedSite}
               // onFocus={() => setIsFocus(true)}
              //  onBlur={() => setIsFocus(false)}
              onChange={(item) => {
                rptselectopnreason=item
               // alert(item.value)
                 // setSelectedSite(item.value);setShowModal(true)
                // setIsFocus(true);
                }}
                renderRightIcon={() => (
                  <Image
                    style={{ marginTop: verticalScale(8) }}
                    source={require("../../assets/reg/downarrow.png")}
                  />
                )}
              />
            <View style={styles.modalContentView}>
            <Text style={styles.placeNameTextStyle}>Ingrese el mensaje de informe</Text>
              <TextInput
                //  ref={ref_input1}
              //  autoFocus={true}
                // ref={input => {
                //   this.nameOrId = input;
                // }}
                //value={report_message}
                minHeight={80}
                numberOfLines={5}
                multiline={true}
                style={{ borderColor: '#08DDFD', borderWidth: 1, borderRadius: 12, padding: 10 }}
                placeholder="Ingrese el mensaje de informe"
                // onBlur={handleInputSubmit(ev)}
                onChangeText={(text) => handleInputSubmit(text)}
                // onBlur={alert(4)}
                // onChangeText={text => { setreport_message(text) }}
                textAlignVertical='top'
              />
            </View>
            <View style={{ flexDirection: 'row', justifyContent: 'space-around' }}>
              <TouchableOpacity
                onPress={() => addreportsave()}
                style={{ width: 130, padding: 10, borderRadius: 12, backgroundColor: '#08DDFD', justifyContent: "center", alignContent: 'center', alignItems: 'center' }}
              >
                <Text style={{ color: "white", fontSize: 15, fontFamily: FONTS.PoppinsMedium }}>Enviar</Text>
              </TouchableOpacity>
              <TouchableOpacity
                onPress={() => setShowModal(false)}
                style={{ width: 130, padding: 10, borderRadius: 12, backgroundColor: '#08DDFD', justifyContent: "center", alignContent: 'center', alignItems: 'center' }}
              >
                <Text style={{ color: "white", fontSize: 15, fontFamily: FONTS.PoppinsMedium }}>Cancelar</Text>
              </TouchableOpacity>
            </View>
          </View>
        </View>
      </Modal>
      // </KeyboardAwareScrollView>
    );
  };

  return (
    // <ScrollView>
    <View style={{ flex: 1, backgroundColor: "#181A1B" }}>
        {showModal && <PopUp />}
      <Header {...props} midle={true} />
      <StatusBar
        translucent
        barStyle="light-content"
        backgroundColor={"transparent"}
      />

<ScrollView>
      <View style={{ justifyContent: "center", alignItems: "center", marginTop: 100 }}>
        <View>
            <Image style={{ width: 100, height: 100, borderRadius: moderateScale(50), }}
              source={{ uri: user && user.creator_profile && user.creator_profile?.profile_photo }}
            />
            <TouchableOpacity onPress={toggleModall} style={{ padding: 5, zIndex: 99999, position: 'absolute', top: 65, alignSelf: "flex-end", left: 75 }}>
              <Image source={require("../../assets/images/dotsmenu.png")} />
            </TouchableOpacity>
            {isModalVisiblee &&
              <View style={{ zIndex: 99999, position: 'absolute', top: 40, alignSelf: "flex-end", left: 110, width: 117, height: 63 }}>
                <TouchableOpacity onPress={() => addreport(1)} style={{ padding: 3, borderTopLeftRadius: 6, borderTopRightRadius: 6, backgroundColor: btnactivestatus == 1 ? "#08DDFD" : "#8C8D91", paddingTop: 8, flexDirection: 'row', justifyContent: 'space-around' }}>
                  <Image style={{ tintColor: btnactivestatus == 1 ? "#000000" : "#FFFFFF" }} source={require("../../assets/images/userreport.png")} />
                  <Text style={{ fontFamily: FONTS.PoppinsMedium, color: btnactivestatus == 1 ? "#000000" : "#FFFFFF", fontSize: 14 }}>Denunciar</Text>
                </TouchableOpacity>

                <TouchableOpacity onPress={() => addblock(1)} style={{ padding: 3, borderBottomLeftRadius: 6, borderBottomRightRadius: 6, backgroundColor: btnactivestatus == 2 ? "#08DDFD" : "#8C8D91", paddingTop: 8, flexDirection: 'row', justifyContent: 'space-around' }}>
                  <Image style={{ tintColor: btnactivestatus == 2 ? "#000000" : "#FFFFFF" }} source={require("../../assets/images/userreport.png")} />
                  <Text style={{ fontFamily: FONTS.PoppinsMedium, color: btnactivestatus == 2 ? "#000000" : "#FFFFFF", fontSize: 14 }}> {blockedstatus == false ? "Bloquear" : "Desbloquear"}</Text>
                </TouchableOpacity>
              </View>
            }
          </View>
        <Text style={{ fontSize: moderateScale(16), color: "#FFFFFF", marginTop: 5 }}>
          {user && user.creator_profile && user.creator_profile?.name}
        </Text>
        {user_type_id == 3 &&
          <Text style={styles.RadiologyStyle}>
            {user && user.creator_profile && user.creator_profile?.bio}
          </Text>
        }
      </View>

      <View style={{ flexDirection: 'row', justifyContent: "center", marginTop: 20 }}>
        <TouchableOpacity
          onPress={() => user && user.creator_profile && user.creator_profile.following_count > 0 ? props.navigation.replace(NAVIGATION.Followerlist, { tabactivestatus: 1, usernameshow: user && user.creator_profile && user.creator_profile.name, creater_id: creater_id }) : ''}
          style={{ marginRight: 10 }}>
          <Text style={styles.followtext}>{user && user.creator_profile && user.creator_profile?.following_count}</Text>
          <Text style={styles.followtextlabel}>Siguiendo</Text>
        </TouchableOpacity>

        {user_type_id == 3 &&
          <>
            <View style={{ backgroundColor: "#08DDFD", width: 0.5 }}>
            </View>
            <TouchableOpacity onPress={() => user && user.creator_profile && user.creator_profile?.followers_count > 0 ? props.navigation.replace(NAVIGATION.Followerlist, { tabactivestatus: 2, usernameshow: user && user.creator_profile && user.creator_profile.name, creater_id: creater_id }) : ''} style={{ marginRight: 15, marginLeft: 15 }}>
              <Text style={styles.followtext}>{user && user.creator_profile && user.creator_profile?.followers_count}</Text>
              <Text style={styles.followtextlabel}>Seguidores</Text>
            </TouchableOpacity>
            <View style={{ backgroundColor: "#08DDFD", width: 0.5 }}>
            </View>
            <View style={{ marginLeft: 10 }}>
              <Text style={styles.followtext}>
                {user && user.creator_profile && user.creator_profile.i_like}
              </Text>
              <Text style={styles.followtextlabel}>Me gusta</Text>
            </View>
          </>
        }
      </View>
      {user_type_id == 2 &&
        <TouchableOpacity
        onPress={() => props.navigation.navigate('Message', { receiverID: user?.creator_profile?.id })}
          style={{ width: '50%', justifyContent: "center", alignSelf: "center", alignContent: "center", marginTop: 10, backgroundColor: '#08DDFD', borderRadius: 25, paddingLeft: 25, paddingRight: 25, padding: 8 }}>
          <Text style={{ color: '#000000', fontSize: 15, fontFamily: FONTS.PoppinsRegular, fontWeight: '600', textAlign: 'center' }}>Mensaje</Text>
        </TouchableOpacity>
      }
      {user_type_id == 3 &&
        <View style={{ flexDirection: 'row', justifyContent: "space-evenly", marginTop: 20 }}>
          <TouchableOpacity
            onPress={() => addfollow(user?.creator_profile.id, user?.creator_profile?.follow_by_logged_user)}
            style={{ backgroundColor: '#08DDFD', borderRadius: 25, paddingLeft: 25, paddingRight: 25, padding: 8 }}>
            <Text style={{ color: '#000000', fontSize: 15, fontFamily: FONTS.PoppinsRegular, fontWeight: '600' }}>{user && user?.creator_profile?.follow_by_logged_user ? "Siguiendo" : "Seguir"}</Text>
          </TouchableOpacity>
          <TouchableOpacity
            onPress={() => user && user?.creator_profile && user?.creator_profile?.website_url ? Linking.openURL(user && user.creator_profile && user.creator_profile?.website_url) : ''}
            style={{ backgroundColor: '#08DDFD', borderRadius: 25, paddingLeft: 25, paddingRight: 25, padding: 8 }}>
            <Text style={{ color: '#000000', fontSize: 15, fontFamily: FONTS.PoppinsRegular, fontWeight: '600' }}>Web</Text>
          </TouchableOpacity>
          <TouchableOpacity
            onPress={() => user && user?.creator_profile && user?.creator_profile?.facebook_url ? Linking.openURL(user.creator_profile?.facebook_url) : ''}
          >
            <Image source={require("../../assets/images/fbicn.png")} />
          </TouchableOpacity>
          <TouchableOpacity
            onPress={() => user && user?.creator_profile && user?.creator_profile?.instagram_url ? Linking.openURL(user && user.creator_profile && user.creator_profile?.instagram_url) : ''}
          >
            <Image source={require("../../assets/images/insta.png")} />
          </TouchableOpacity>
          <TouchableOpacity onPress={() => user && user.creator_profile && user.creator_profile?.youtube_url ? Linking.openURL(user && user.creator_profile && user.creator_profile?.youtube_url) : ''} >
            <Image source={require("../../assets/images/youtube.png")} />
          </TouchableOpacity>
        </View>
      }
      <View style={{ backgroundColor: '#2A2A2A', height: 0.5, marginTop: 20 }}>
      </View>
      {user_type_id == 3 &&
      <>
        <View style={{ marginTop: 10, flexDirection: "row", justifyContent: 'space-around' }}>
          <TouchableOpacity style={[styles.rowview, { padding: 5 }]} onPress={() => props.navigation.navigate('Message', { receiverID: user?.creator_profile?.id })} >
            <Image source={require("../../assets/images/chaticonprof.png")} />
            <Text style={styles.label}>Mensaje</Text>
          </TouchableOpacity>
          <TouchableOpacity
            onPress={() => user && user.creator_profile && user.creator_profile?.email?Linking.openURL('mailto:' + (user && user.creator_profile && user.creator_profile?.email) + ''):''} style={styles.rowview}
          >
            <Image source={require("../../assets/images/emailiconprof.png")} />
            <Text style={styles.label}>Email</Text>
          </TouchableOpacity>
          <TouchableOpacity onPress={() => user && user.creator_profile && user.creator_profile?.email_collaboration?Linking.openURL('mailto:' + (user && user.creator_profile && user.creator_profile?.email_collaboration) + ''):''} style={styles.rowview}>
            <Image source={require("../../assets/images/emailiconprof.png")} />
            <Text style={styles.label}>Colaboración</Text>
          </TouchableOpacity>
        </View>
        <TouchableOpacity onPress={() => setshowpromocion(!showpromocion)} style={{ alignContent: 'center', justifyContent: 'center', alignItems: 'center', marginLeft: 20, marginRight: 20, marginTop: 10, backgroundColor: '#08DDFD', borderRadius: 10, paddingLeft: 20, paddingRight: 20, padding: 5 }}>
          <Text style={{ color: '#000000', fontSize: 15, fontFamily: FONTS.PoppinsMedium, fontWeight: '600' }}>Enlance a promoción</Text>
        </TouchableOpacity>
        {showpromocion &&
          <View style={{ marginTop: 5, borderRadius: 10, minHeight: 50, backgroundColor: 'white', marginLeft: 20, marginRight: 20, paddingLeft: 15, paddingTop: 5 }}>
            {user && user.creator_profile && user?.creator_profile?.promotion_title_one && 
            <TouchableOpacity
              onPress={() => user && user.creator_profile && user.creator_profile.promotion_title_one_link ? Linking.openURL(user?.creator_profile.promotion_title_one_link) : ''}
            >
             <Text style={{ color: 'black', fontFamily: FONTS.PoppinsMedium }}>1. {user && user.creator_profile && user.creator_profile.promotion_title_one}</Text>
           </TouchableOpacity>
            }
            {user && user.creator_profile && user?.creator_profile?.promotion_title_two && 
             <TouchableOpacity
             onPress={() => user && user.creator_profile && user.creator_profile.promotion_title_two_link ? Linking.openURL(user?.creator_profile.promotion_title_two_link) : ''}
            >
             <Text style={{ color: 'black', fontFamily: FONTS.PoppinsMedium }}>2. {user && user.creator_profile && user.creator_profile.promotion_title_two}</Text>
            </TouchableOpacity>
           }
            {user && user.creator_profile && user?.creator_profile?.promotion_title_three && 
             <TouchableOpacity
             onPress={() => user && user.creator_profile && user.creator_profile.promotion_title_three_link ? Linking.openURL(user?.creator_profile.promotion_title_three_link) : ''}
              >
            <Text style={{ color: 'black', fontFamily: FONTS.PoppinsMedium }}>3. {user && user.creator_profile && user.creator_profile.promotion_title_three}</Text>
            </TouchableOpacity>
            }
            {user && user.creator_profile && !user?.creator_profile?.promotion_title_three && !user?.creator_profile?.promotion_title_two && !user?.creator_profile?.promotion_title_one && <Text style={{ color: 'black', fontFamily: FONTS.PoppinsMedium, textAlign: 'center' }}>Sin promoción</Text>
            }
          </View>
        }

        </>

        
      }
      <View style={{ flex: 1, paddingLeft: verticalScale(10), paddingRight: verticalScale(10), width: '100%', flexDirection: 'row' }}>
        <View
          style={{
            marginTop: verticalScale(10),
            flexDirection: "row",
            width: "100%",
            //backgroundColor:"red"
          }}
        >
          {user_type_id == 3 &&
            user?.creatervideos?.length > 0 ?
            <FlatList
              data={user && user.creatervideos}
              numColumns={3}
              renderItem={({ item,index }) =>
              <View style={{flex:1,  borderRadius: moderateScale(15), margin: 5, marginTop: 7, backgroundColor: "transparent" }}>
              <View style={{ zIndex: 99999, position: 'relative', top: 25, marginLeft: 5 }}>
                <Text style={{ fontSize: 12, paddingLeft: 3, color: '#08DDFD', fontFamily: FONTS.PoppinsRegular }}>{moment.utc(item.upload_date).local().startOf('seconds').fromNow(true)}</Text>
              </View>
              <TouchableOpacity 
              //  onPress={()=>navigation.navigate(NAVIGATION.mainHome,{firstvideo_id:item.id})}
                onPress={()=>{
                 // navigation.goBack()
                  navigation.replace(NAVIGATION.Selfvideolist,{selfvideodata:user && user.creatervideos,startindex:index})
                  }
                  }
              style={styles.backgroundVideo}> 
                <Image resizeMode='cover' style={{width:'100%',height:153,borderRadius:15}} source={ item?.video_thumbnail=='null'?require("../../assets/Home/New/videothumb.png"):{ uri:Apiurl + item?.video_thumbnail} }/>
              </TouchableOpacity>
              <View style={{position:"absolute", zIndex:9999999,bottom:1,flexDirection:"row",justifyContent:"flex-start",marginLeft:7,marginRight:4,alignItems:'center'}}>
  {item?.view_count>0 &&
  <View 
 // onPress={() => deletenotify(item.id)} 
style={{padding:5, alignSelf:'flex-end',right:5,flexDirection:'row',alignItems:'center'}}
  >
   <Image
   // style={{height:18,width:18}}
    source={require("../../assets/images/videoview.png")}
    />
    <Text style={{paddingTop:5, color:'white',paddingLeft:5,fontSize:12,fontFamily:FONTS.PoppinsRegular}}>{formatCash(item?.view_count)}</Text>
  </View>
     }

  </View>
            </View>
              }
            //  keyExtractor={item => item.id}
            />
            :
            <View style={{ width: "100%" }}>
              <Image resizeMode="center" style={{ alignSelf: 'center' }} source={require("../../assets/images/defaultimage.png")} />
            </View>
          }
        </View>
      </View>

      {animating == true && (
        <ActivityIndicator
          animating
          color={'white'}
          size="large"
          style={styles.activityIndicator}
        />
      )}
       </ScrollView>
    </View>
   
  );
};

export default Followerdetail;
