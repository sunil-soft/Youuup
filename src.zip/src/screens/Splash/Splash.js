import { ImageBackground } from "react-native";
import styles from "./Splash.styles";
export function Splash({ navigation }) {
  //StatusBar.setHidden(true);
  return (
    <>
    {/* <StatusBar translucent backgroundColor="transparent" /> */}
    <ImageBackground
     resizeMode="cover"
      style={styles.mainContainer}
      source={require("../../assets/splash/splash.png")}
    >
     
    </ImageBackground>
    </>
  );
}
export default Splash;
