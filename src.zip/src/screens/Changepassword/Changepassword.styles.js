import { StyleSheet } from "react-native";
import Scale from "../../helper/Scale";
import { FONTS } from "../../theme/fonts";
export const styles = StyleSheet.create({
  loginContainer: {
//backgroundColor: "white",
    // height: verticalScale(430),
    // position: "absolute",
    // bottom: -50,
     width: "100%",
     justifyContent:'center',
    // alignContent:'center',
     alignItems:'center'
    // borderRadius: 50,
    // paddingVertical: verticalScale(30),
    // paddingHorizontal: scale(20),
    // bottom: verticalScale(-310),
  },
  formContainer: {
    borderRadius: 5,
    padding: 20,
    width: "100%",
  },
  submitButton: {
    marginTop: 30,
  },
  Title: {
    fontFamily: FONTS.PoppinsSemiBold,
    fontStyle: "normal",
    fontSize: Scale.moderateScale(32),
    color: "#000000",
    fontWeight: "600",
  },
  TitleDis: {
    fontFamily: FONTS.PoppinsRegular,
    paddingTop: 10,
    fontSize: Scale.moderateScale(14),
    color: "#615B5B",
    fontWeight: "400",
  },
  textTitle: {
    fontFamily: FONTS.PoppinsRegular,
    paddingTop: 10,
    fontSize: Scale.moderateScale(14),
    color: "#313131",
    fontWeight: "400",
  },
  

  bottomView: {
    alignSelf: "center",
    flexDirection: "row",
    marginTop:20
   // marginTop: "18%",
  },
});
