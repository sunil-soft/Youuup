import { Apiurl } from "@/constants/Apiurl";
import { FONTS } from "@/theme/fonts";
import AsyncStorage from '@react-native-async-storage/async-storage';
import axios from "axios";
import moment from 'moment/min/moment-with-locales';
import { useEffect, useState } from "react";
import { ActivityIndicator, Alert, FlatList, Image, ImageBackground, StatusBar, Text, View } from "react-native";
import { Dropdown } from 'react-native-element-dropdown';
import { TouchableOpacity } from "react-native-gesture-handler";
import { KeyboardAwareScrollView } from 'react-native-keyboard-aware-scroll-view';
import { moderateScale, verticalScale } from "react-native-size-matters";
import { useDispatch, useSelector } from "react-redux";
import { blocklistapi, logout } from "../../actions/UserActions";
import { Header } from "../../components/Header";
import { InputField } from "../../components/InputField";
import { NAVIGATION } from "../../constants";
import { getUser } from "../../selectors/UserSelectors";
import { styles } from "./Searchuserliststyles";

const APIBASEURL = 'https://youuup.es/mobile-api/'
const Searchuserlist = (props) => {
  const dispatch = useDispatch();
  const { navigation, route } = props;
  const user = useSelector(getUser);
  //const { usernameshow,creater_id,tabactivestatus } = route.params;

  const [serachtext, setserachtext] = useState('');
  const [searchlist, setsearchlist] = useState([]);
  const [animating, setAnimating] = useState(false);
  const [chnlList, setchnlList] = useState([]);
  const [createrlist, setcreaterList] = useState([]);
  const [createrlisttemp, setcreaterListtemp] = useState([]);

  const [themnticchnlList, setthmenticchnlList] = useState([]);


 // const [chnlList, setchnlList] = useState([]);
  const [selected, setSelected] = useState([]);
  const [isFocus, setIsFocus] = useState(false);
  const [tabactive, settabactive] = useState(1);

  
  // const [activetab, setactivetab] = useState(tabactivestatus==1?2:1);
  //const [activestatus, setactivestatus] = useState(2);


  // useFocusEffect(
  //   React.useCallback(() => {
  //     const unsubscribe = followerlist(tabactivestatus);

  //     return () => unsubscribe;
  //   }, [])
  // );


  const blocklist = () => {
    dispatch(blocklistapi());
  };
  useEffect(() => {
    // alert(3)
   // getchannellist()
   callbyname()
  }, []);
  const getchannellist = () => {
    setSelected([])
    setsearchlist([])
    settabactive(2)
    setAnimating(true)
    axios({
      url: Apiurl + "video/chennel-list",
      method: "GET",
      headers: {
        Accept: "application/json",
      },
    })
      .then((response) => {
        setAnimating(false)
        console.log('channellist', response.data?.result)
        setchnlList(response.data?.result)
      })
      .catch(function (error) {
        setAnimating(false)
        console.log("error", error);
      });
  };

  const getthematicchannellist = () => {
    setSelected([])
    setsearchlist([])
    settabactive(3)
    setAnimating(true)
    axios({
      url: Apiurl + "thematic/thematic-channel-list",
      method: "GET",
      headers: {
        Accept: "application/json",
      },
    })
      .then((response) => {
        setAnimating(false)
        console.log('themnticchannellist', response.data?.result)
        setthmenticchnlList(response.data?.result)
      })
      .catch(function (error) {
        setAnimating(false)
        console.log("error", error);
      });
  };
  const callbyname = () => {
    setSelected([])
    setsearchlist([])
    settabactive(1)
  //  setAnimating(true)
    axios({
      url: Apiurl + "user/creators-list",
      method: "GET",
      //  data: {"video_id":video_id,"favourite_status":status==true?2:1},
      headers: {
        Accept: "application/json",
        //  Authorization:"Bearer "+datatoken,
      },
    })
      .then((response) => {
        console.log('userist', response.data?.result)
       // setAnimating(false)
        // console.log('channellist', response.data?.result)
        setcreaterList(response.data?.result)
      })
      .catch(function (error) {
        setAnimating(false)
        console.log("error", error);
      });
  };
  const searchlistcreater = (text) => {
  console.log(text)
  if(text)
  {
    const updatedData = createrlist.filter(
    (listItem) =>
      listItem.name
        .toLowerCase()
        .includes(text.toLowerCase()) ||
      listItem.name.toLowerCase().includes(text.toLowerCase()),
  );
  setsearchlist(updatedData)
    }
    else{
      setsearchlist([])
 
    }
  }
  const serachtextsave = (text) => {
    setserachtext(text)
    searchlistcreater(text)

  };
  const searchuser = (selected) => {

    console.log(selected)
    setAnimating(true)
    AsyncStorage.getItem('auth_token').then(async (datatoken) => {
      //  if(text.length>=3)
      //  {
      axios({
        url: APIBASEURL + "user/search-user",
        method: "POST",
        data: { "search": [selected] },
        headers: {
          Accept: "application/json",
          Authorization: "Bearer " + datatoken,
        },
      })
        .then((response) => {
          console.log('response', response.data.users)
          setAnimating(false)
          setsearchlist(response.data?.users)
         // setsearchlist(response.data?.users)
          // blocklist()
        })
        .catch(function (error) {
          setAnimating(false)
          if(error?.response?.data?.message=='Unauthorized')
          {
         
           dispatch(logout());
          }
          console.log("error11", error);
        });
      // }
      // else{
      //   setsearchlist([])
      // }
    });
  };

  

  const searchuserbythemntic = (selected) => {
    //alert(selected)
    setAnimating(true)
    AsyncStorage.getItem('auth_token').then(async (datatoken) => {
      //  if(text.length>=3)
      //  {
      axios({
        url: APIBASEURL + "user/search-user-by-thematic",
        method: "POST",
        data: { "search": [selected] },
        headers: {
          Accept: "application/json",
          Authorization: "Bearer " + datatoken,
        },
      })
        .then((response) => {
          console.log('response', response.data.users)
          setAnimating(false)
          setsearchlist(response.data?.users)
         // setsearchlist(response.data?.users)
          // blocklist()
        })
        .catch(function (error) {
          setAnimating(false)
          if(error?.response?.data?.message=='Unauthorized')
          {
         
           dispatch(logout());
          }
          console.log("error11", error);
        });
      // }
      // else{
      //   setsearchlist([])
      // }
    });
  };
  const formatCash = (n) => {
    if (n < 1e3) return n;
    if (n >= 1e3 && n < 1e6) return +(n / 1e3).toFixed(1) + "K";
    if (n >= 1e6 && n < 1e9) return +(n / 1e6).toFixed(1) + "M";
    if (n >= 1e9 && n < 1e12) return +(n / 1e9).toFixed(1) + "B";
    if (n >= 1e12) return +(n / 1e12).toFixed(1) + "T";
  };
  return (
    <ImageBackground
      style={{ flex: 1, }}
      resizeMode={"stretch"}
      backgroundColor={'black'}
      // source={require("../../assets/images/editprofileback.png")}
      source={require("../../assets/splash/bg.png")}
    >
      <StatusBar translucent backgroundColor="transparent" />
      <Header back={true} {...props} title={'Buscar'} />
      {/* {showModal && <PopUp/>} */}
      <KeyboardAwareScrollView>
        <View style={styles.mainContainer}>
          <View style={{ backgroundColor: "#2A2A2A", height: 0.5, marginTop: 60, width: '90%', justifyContent: 'center', alignSelf: 'center' }}></View>
          <View style={{ marginLeft: 20, alignItems: "center", marginTop: 5, width: '90%', marginTop: 10 }}>
         
            <Text style={{ color: 'white', fontFamily: FONTS.PoppinsRegular }}>
           {tabactive==1 ?"Cuentas de perfil por nombre":tabactive==2?"Cuentas de perfil por canales":"Canales temáticos"}
            </Text>

            <View style={{paddingTop:5, width:'100%', flexDirection:'row',justifyContent:"space-around"}}>
              <TouchableOpacity onPress={()=>callbyname()}>
                 <Image style={{ width:70,height:70}}
                   source={tabactive==1?require("../../assets/images/Namesearch_active.png"):require("../../assets/images/Namesearch.png")}
                 />
              </TouchableOpacity>
         
              <TouchableOpacity 
              onPress={()=>getthematicchannellist()}

              >
              <Image style={{ width:70,height:70}} thamntic_ch_active
                   source={tabactive==3?require("../../assets/images/thamntic_ch_active.png"):require("../../assets/images/thamntic_ch.png")}

                 />
              </TouchableOpacity>
              <TouchableOpacity onPress={()=> getchannellist()}>
               <Image style={{ width:70,height:70}}
                 source={tabactive==2?require("../../assets/images/chnl_serach_active.png"):require("../../assets/images/chnl_serach.png")}
                 />
              </TouchableOpacity>
            </View> 
          {tabactive==1 ?
           <View style={{marginTop:5, flexDirection:'row',justifyContent:'center',alignContent:'center',alignItems:"center"}}>
            <View 
           // onPress={()=> {setisActiveviewstatus(1), setsecureText(!secureText)}} 
            style={{position:'relative', zIndex:9999999999,left:40,padding:4}} >
           <Image source={require("../../assets/Home/New/searchicon.png")} />
          </View> 
            <InputField
          placeholderColor={"white"}
          placeholder={""}
          mainViewStyle={{ width: "100%",height:60,paddingLeft:25}}
          onChangeText={(text) => {
            serachtextsave(text);
        }}
        /> 
           </View>
            :
            <View
              style={{
                width: '100%',
                backgroundColor: isFocus ? "rgba(26, 91, 101, 1)" : "rgba(97, 156, 165, 0.09)",
                zIndex: 1000,
                borderRadius: moderateScale(15),
                // marginBottom: 20,
                borderRadius: 25,
                height: 60,
                justifyContent: 'center',
                alignContent: 'center',
                marginTop: 20
              }}
            >

              <Dropdown
                style={styles.dropdown}
                placeholderStyle={styles.placeholderStyle}
                selectedTextStyle={styles.selectedTextStyle}
                itemTextStyle={{color:'black'}}
                activeColor={'darkgray'}
                // selectedStyle={{backgroundColor:"red"}}
                inputSearchStyle={styles.inputSearchStyle}
                // itemContainerStyle={{backgroundColor:'red'}}
                // containerStyle={{backgroundColor:'red'}}
                iconStyle={styles.iconStyle}
                search

                //dropdownPosition={"bottom"}
                data={
                  tabactive==2
                  ? chnlList
                  : tabactive==3
                  ? themnticchnlList
                  : []
                }
              //  labelField="channel_name"

                labelField={
                  tabactive==2
                  ? "channel_name"
                  : tabactive==3
                  ? "thematic_channel_name"
                  : ""
                }
                valueField="id"
                placeholder={!isFocus ? '' : ''}
                searchPlaceholder="Buscar..."
                value={selected}
                onChange={item => {
                 //  alert(item)
                   console.log('item',item)
                  if (item.length > 3) {
                    Alert.alert('información', 'Máximo etiquetar 3 canales por vídeo', [
                      { text: 'DE ACUERDO', onPress: () => console.log('OK Pressed') },
                    ]);
                  }
                  else {
                    setSelected(item.id);
                    setIsFocus(false);
                    if(tabactive==2)
                    {
                    searchuser(item.id)
                    }
                    else{
                      searchuserbythemntic(item.id)

                    }
                  }

                }}
                renderRightIcon={() => (
                  <View style={{ position: 'relative' }}>
                    <Image
                      style={{ marginTop: verticalScale(10), marginRight: 5 }}

                      source={require("../../assets/reg/downarrow.png")}
                    />
                  </View>
                )}
                renderLeftIcon={() => (
                  <Image source={require("../../assets/Home/New/searchicon.png")} />
                )}
                selectedStyle={{ position: "relative", marginLeft: 20, marginLeft: 5, marginRight: 10, backgroundColor: '#08DDFD', borderRadius: 9, }}
              />
            </View>
            }
          </View>
              {/* User Result */}
          {
          tabactive==1 && 
          searchlist?.length > 0 ?
            <FlatList
              data={searchlist}
              renderItem={({ item }) =>
                <View style={{ marginTop: 30, flexDirection: "row", marginLeft: 15, marginRight: 15, alignContent: 'center', alignItems: 'center' }}>
                  <View style={{ width: '20%' }}>
                    <TouchableOpacity 
                    onPress={() => navigation.navigate(NAVIGATION.Followerdetail, { creater_id: item.id, user_type_id: 3 })}
                    >

                      {/* <Image style={{width:56,height:56,borderRadius:50}} source={{uri:item.profile_photo}} /> */}
                      {item?.profile_photo ?
                        <Image style={{ width: 60, height: 60, borderRadius: 50 }}
                          source={{ uri: APIBASEURL + item.profile_photo }}
                        />
                        :
                        <Image style={{ width: 60, height: 60, borderRadius: 50 }}
                          source={require("../../assets/images/defaultuser.png")}
                        />
                      }
                    </TouchableOpacity>
                  </View>
                  <TouchableOpacity onPress={() => navigation.navigate(NAVIGATION.Followerdetail, { creater_id: item.id, user_type_id: 3 })} style={{ width: '100%' }}>
                    <View style={{ width: '100%' }}>
                      <Text style={{ color: '#08DDFD', fontSize: 14, fontWeight: "600", fontFamily: FONTS.PoppinsMedium }}>{item.name}</Text>
                    </View>
                  </TouchableOpacity>
                  {/* <View style={{width:'35%',justifyContent:"center",alignItems:'center',alignContent:'center'}}>
      <TouchableOpacity 
      onPress={()=>addblock(item.id,2)}

      style={{width:120, backgroundColor:"#08DDFD",padding:8,paddingLeft:10,paddingRight:10, borderWidth:1,borderColor:'#08DDFD', borderRadius:20,justifyContent:'center',alignContent:"center",alignItems:'center'}}>
       <Text style={{color:"#000000",fontSize:14,fontFamily:FONTS.PoppinsMedium}}>Desatascar</Text>
       </TouchableOpacity>
      </View> */}
                </View>
              }
              keyExtractor={item => item.id}
            />
            :
            tabactive==1 &&
            <View style={{ justifyContent: "center", alignContent: 'center', alignItems: 'center', marginTop: 40 }}>
              {/* <Text style={{ color: 'white' }}>
                No hay resultados
              </Text> */}
            </View>
          }
        {/* Themnatic Result */}

        {(tabactive==2 || tabactive==3) && searchlist?.length>0?
         <View style={{ paddingLeft: verticalScale(10), paddingRight: verticalScale(10), width: '99%', flexDirection: 'row' }}>
           <View
           style={{
             marginTop: verticalScale(10),
             flexDirection: "row",
             width: "99%",
             marginRight: 10,
           }}
         >
             <FlatList
               data={searchlist}
               numColumns={3}
               renderItem={({ item,index }) =>
       <View style={{flex:1}}>
          <View style={{width:"100%",  position:"absolute", zIndex:9999999,top:5,flexDirection:"row", justifyContent:"space-between",alignItems:'center',}}>
          <View 
            style={{padding:5, alignSelf:'flex-end',flexDirection:'row',alignItems:'center'}}
            >
        <Text style={{ fontSize: 12, paddingLeft: 8, color: '#08DDFD', fontFamily: FONTS.PoppinsRegular }}>{moment.utc(item.upload_date).local().startOf('seconds').fromNow(true)}</Text>
          </View>
      </View>
         <TouchableOpacity onPress={()=>navigation.replace(NAVIGATION.Selfvideolist,{selfvideodata:searchlist && searchlist,startindex:index})} style={{  borderRadius: moderateScale(15), margin: 5, marginTop: 7, backgroundColor: "transparent" }}>
               {/* <View style={{ zIndex: 99999, position: 'relative', top: 25, marginLeft: 5 }}>
                 <Text style={{ fontSize: 12, paddingLeft: 3, color: '#08DDFD', fontFamily: FONTS.PoppinsRegular }}>{moment.utc(item.upload_date).local('es').startOf('seconds').fromNow(true)} </Text>
               </View> */}
               <View  style={styles.backgroundVideo}> 
                 <Image resizeMode="cover"  style={{width:'100%',height:153,borderRadius:15}} source={ item?.video_thumbnail=='null'?require("../../assets/Home/New/videothumb.png"):{ uri:Apiurl + item?.video_thumbnail} }/>
              </View>
           </TouchableOpacity>
      <View style={{position:"absolute", zIndex:9999999,bottom:5,flexDirection:"row",justifyContent:"flex-start",marginLeft:15,marginRight:4,alignItems:'center'}}>
        {item?.view_count>0 &&
        <View 
        style={{padding:5, alignSelf:'flex-end',right:5,flexDirection:'row',alignItems:'center'}}
         >
         <Image
         // style={{height:18,width:18}}
         source={require("../../assets/images/videoview.png")}
         />
        <Text style={{paddingTop:4, color:'white',paddingLeft:5,fontSize:12,fontFamily:FONTS.PoppinsRegular}}>{formatCash(item?.view_count)}</Text>
       </View>
       }
       </View>
     </View>
               }
             />
         </View>
         </View>
         :
         searchlist.length==0 &&
         <View style={{ justifyContent: "center", alignContent: 'center', alignItems: 'center', marginTop: 40 }}>
         <Text style={{ color: 'white' }}>
           No hay resultados
         </Text>
         </View>
         }

        </View>
        {animating == true && (
          <ActivityIndicator
            animating
            color={'white'}
            size="large"
            style={styles.activityIndicator}
          />
        )}
      </KeyboardAwareScrollView>
    </ImageBackground>
  );
};

export default Searchuserlist;
