import { useState } from "react";
import { ImageBackground, StatusBar, View } from "react-native";
import { WebView } from 'react-native-webview';
import { Header } from "../../components/Header";
import { styles } from "./TutorialStyles";

const Tutorial = (props) => {
  const [animating, setAnimating] = useState(false);

  return (
    <ImageBackground
    style={{ flex: 1,  }}
    resizeMode={"stretch"}
    
    source={require("../../assets/images/editprofileback.png")}
  >
    <StatusBar translucent backgroundColor="transparent" />
     <Header back={true} {...props} title='' />
    <View style={styles.mainContainer}>
    <WebView source={{ uri: 'https://youtu.be/llkrObsT8G0' }} style={{ flex: 1 }} />
    </View>
 </ImageBackground>
  );
};

export default Tutorial;
