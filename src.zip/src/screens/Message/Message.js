import AsyncStorage from '@react-native-async-storage/async-storage';
import axios from "axios";
import { useCallback, useEffect, useRef, useState } from 'react';
import { ActivityIndicator, FlatList, ImageBackground, StatusBar, Text, TouchableOpacity, View } from "react-native";
import { showMessage } from "react-native-flash-message";
import { useDispatch } from "react-redux";
import { logout } from "../../actions/UserActions";
import { Header } from "../../components/Header";
import { InputField } from "../../components/InputField";
import { Apiurl } from "../../constants/Apiurl";
import { FONTS } from "../../theme/fonts";
import { styles } from "./Message.styles";
const Message = (props) => {
  const dispatch = useDispatch();
  //receiverID
  const { navigation, route } = props;
  const { receiverID } = route.params;

  const [animating, setAnimating] = useState(false);
  const [message, setMessage] = useState('');
  const [comment, setcomment] = useState("");
  const [messagelist, setmessagelist] = useState([]);
  const [btndisabled, setbtndisabled] = useState(false);
  const yourRef = useRef(null);
  // useFocusEffect(
  //   React.useCallback(() => {
  //     alert(44)
  //     messagelistapi(receiverID)
  //   }, [])
  // );
  useEffect(() => {
   // alert('fgf')
    // setMessages([
    //   {
    //     _id: 1,
    //     text: 'Hello developer',
    //     //  createdAt: new Date(),
    //     // user: {
    //     //   _id: 2,
    //     //   name: 'React Native',
    //     //   avatar: 'https://placeimg.com/140/140/any',
    //     // },
    //   },
    // ])
  }, [])
  const onSend = useCallback((messages = []) => {
    //setMessages(previousMessages => GiftedChat.append(previousMessages, messages))
  }, [])

  useEffect(() => {
    setAnimating(true)
    messagelistapi(receiverID)
  }, []);
  useEffect(() => {
    const interval = setInterval(() => {
      messagelistapi(receiverID)
    }, 1500);
    return () => clearInterval(interval);
  }, []);

  const messagelistapi = (receiverID) => {
    //alert(receiverID)
    AsyncStorage.getItem('auth_token').then(async (datatoken) => {
      if (datatoken) {
        axios({
          url: Apiurl + "user/my-chat",

          method: "POST",

          data: { "receiverID": receiverID },

          headers: {
            //  "Content-Type": "",
            Accept: "application/json",
            Authorization: "Bearer " + datatoken,
          },
        })
          .then((response) => {
            console.log(response.data)
            setAnimating(false)
            setmessagelist(response.data.result);
          })
          .catch(function (error) {
            setAnimating(false)
            if(error?.response?.data?.message=='Unauthorized')
            {
           
             dispatch(logout());
            }
            console.log("error", error.response);
          });
      }
    });

  };

  const Validation = () => {
    if (!message.trim()) {
      showMessage({
        message: "Por favor ingrese un Mensaje",
        type: "danger",
      });
    }
    else {
      setbtndisabled(true)
      sendmessage();
      //setShowModal(true);
      // props.navigation.navigate("EditUserDetail");
    }
  };
  const sendmessage = async () => {

    AsyncStorage.getItem('auth_token').then(async (datatoken) => {
      console.log({ "receiverID": receiverID, message: message })

      axios({
        url: Apiurl + "user/send-message",

        method: "POST",

        data: { "receiverID": receiverID, message: message },

        headers: {
          //  "Content-Type": "",
          Accept: "application/json",
          Authorization: "Bearer " + datatoken,
        },
      })
        .then((response) => {
          setMessage('')
          messagelistapi(receiverID)
          setbtndisabled(false)

        })
        .catch(function (error) {

          console.log("error", error);

        });
    });

    //console.log(data)
    //dispatch(editprofileapi(data));
  };


  return (
    <ImageBackground
      style={{ flex: 1 }}
     resizeMode={"stretch"}
     backgroundColor={'black'}
      source={require("../../assets/images/editprofileback.png")}
    >
      <StatusBar translucent backgroundColor="transparent" />
      <Header back={true} {...props} title='Mensajes' />

      {/* <GiftedChat
        messages={messagelist}
        onSend={messages => onSend(messages)}
      // user={{
      //   _id: 1,
      // }}
      /> */}
      {/* <ScrollView style={{ height: '100%' }}  > */}

      <View style={{ height: '100%', flexDirection: 'column', justifyContent: "space-around" }}>
        <View style={{ height: '75%', marginTop: 80 }} >
          {messagelist.length > 0 ?
            <FlatList
              data={messagelist}
              ref={yourRef}
              onContentSizeChange={() => yourRef.current.scrollToEnd() }
              onLayout={() => yourRef.current.scrollToEnd() }
              // inverted
              renderItem={({ item }) =>
                <>
                  <View style={{ marginTop: 10, flexDirection: "row", marginLeft: 20, marginRight: 20, alignContent: 'center', alignItems: 'center' }}>

                    <View style={{ width: '100%', alignItems: item.receiverID == receiverID ? 'flex-end' : 'flex-start' }}>
                      <View style={{ minWidth: 100, backgroundColor: item.receiverID == receiverID ? '#08DDFD' : 'white', alignItems: 'flex-start', paddingLeft: 15, paddingTop: 10, paddingBottom: 10, paddingRight: 15, borderRadius: 10 }}>
                        <Text style={{ color: item.receiverID == receiverID ? 'black' : 'black', fontSize: 13, fontWeight: "600", fontFamily: FONTS.PoppinsRegular }}>
                          {item.message}
                        </Text>
                      </View>
                    </View>
                  </View>
                </>
              }
            />
            :
            <View style={{ alignSelf: 'center', marginTop: "50%" }}>
              <Text style={{ color: 'white' }}>Sin Mensajes</Text>
            </View>
          }
        </View>

        <View style={{ height: "7%", marginLeft: '2%', marginBottom: 40, marginTop: 20, }} >
          <View
            style={{
              position: 'relative',
              top: 0,
              flexDirection: "row",


            }}
          >
            <InputField
              autoFocus={true}
              onChangeText={(text) => {
                setMessage(text)
              }}
              maxLength={300}
              value={message}
              color={"white"}
              mainViewStyle={{ width: "97%", paddingRight: '11%' }}

              placeholderColor={"white"}
            />
            <TouchableOpacity
              disabled={btndisabled}
              onPress={() => Validation()}
              style={{ height: 60, position: 'relative', right: 52, justifyContent: 'center' }}>
              <Text style={{ color: "#08DDFD" }}>Enviar</Text>
            </TouchableOpacity>
          </View>
        </View>
      </View>
      {/* </ScrollView> */}
      {animating == true && (
        <ActivityIndicator
          animating
          color={'black'}
          size="large"
          style={styles.activityIndicator}
        />
      )}
    </ImageBackground>
  )
}

export default Message