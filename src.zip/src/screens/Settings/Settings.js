import { newIcon } from "@/assets";
import { Apiurl } from "@/constants/Apiurl";
import AsyncStorage from '@react-native-async-storage/async-storage';
import { useFocusEffect } from "@react-navigation/native";
import axios from "axios";
import React, { useState } from 'react';
import { NAVIGATION } from "../../constants";

import {
  ActivityIndicator,
  Alert,
  Image,
  ImageBackground,
  Text,
  TouchableOpacity,
  View
} from "react-native";
import { moderateScale } from "react-native-size-matters";
import { useDispatch, useSelector } from "react-redux";
import { logout } from "../../actions/UserActions";
import { Header } from "../../components/Header";
import { getUser } from "../../selectors/UserSelectors";
import { FONTS } from "../../theme/fonts";
import { styles } from "./SettingsStyles";

const data = [
  {
    id: 1,
    status: "Notifications",
    image: require("../../assets/Home/notification.png"),
  },
  {
    id: 2,
    status: "About Us",
    image: newIcon.about_us,
    Screen: "AboutUs",
  },
  {
    id: 3,
    status: "Terms & Conditions",
    image: require("../../assets/Home/terms.png"),
    Screen: "Terms",
  },
  {
    id: 4,
    status: "Privacy Policy",
    image: require("../../assets/Home/privacy.png"),
    Screen: "Privacy",
  },
  {
    id: 5,
    status: "Contact Us",
    image: require("../../assets/Home/contact.png"),
    Screen: "ContactUs",
  },
];

const Settings = (props) => {
  const dispatch = useDispatch();
  const user = useSelector(getUser);
  // console.log(props);
  //const [accepted,SetAccepted ] = useState(false)
  const [Enabled, setEnabled] = useState(true);
  const [likeEnabled, setlikeEnabled] = useState(true);
  const [commentEnabled, setcommentEnabled] = useState(true);
  const [followEnabled, setfollowEnabled] = useState(true);
  const [postEnabled, setpostEnabled] = useState(true);
  const [soundEnabled, setsoundEnabled] = useState(true);
  const [animating, setAnimating] = useState(false);
  const toggleSwitch = () => setEnabled(!Enabled);
  const updatenotification = async (type,status) => {

    AsyncStorage.getItem('auth_token').then(async (datatoken) => {
      axios({
        url: Apiurl + "user/notification-setting",
        method: "POST",
        data: { "notification_type": type, "notification_status": status },
        headers: {
          Accept: "application/json",
          Authorization: "Bearer " + datatoken,
        },
      })
        .then((response) => {
          console.log('updatesetting', response)
          getsetting()
          // setpostEnabled(response?.data?.result.add_new_video_notification)
          // setEnabled(response?.data?.result.all_notification)
          // setcommentEnabled(response?.data?.result.comment_notification)
          // setfollowEnabled(response?.data?.result.follow_notification)
          // setlikeEnabled(response?.data?.result.like_notification)
          // setsoundEnabled(response?.data?.result.notification_sound)
        })
        .catch(function (error) {
          console.log('error-setting', error)
        });
  
  });

    // if(type==6)
    // {
    // setEnabled(status)
    // }
    // if(type==1)
    // {
    // setlikeEnabled(status)
    // }
    // if(type==2)
    // {
    // setcommentEnabled(status)
    // }
    // if(type==3)
    // {
    // setfollowEnabled(status)
    // }
    // if(type==4)
    // {
    //   setpostEnabled(status)
    // }
    // if(type==5)
    // {
    //   setsoundEnabled(status)
    // }
   // console.log('user',user?.userinfo?.payload.id)
   // setEnabled(!Enabled)
    // const data = {
    //   is_notification:true,
    // };
    // console.log(data)
    // dispatch(updatenotificationapi(data,user?.userinfo?.payload.id));
  };
  useFocusEffect(
    React.useCallback(() => {
      getsetting()
    }, [])
  );

  const getsetting = () => {
    setAnimating(true)

    AsyncStorage.getItem('auth_token').then(async (datatoken) => {
      axios({
        url: Apiurl + "user/notification-setting-detail",
        method: "GET",
       // data: shavideo_id ? { "video_type": video_type_status, "offset": offset, "limit": 4, "video_id": shavideo_id } : { "video_type": video_type_status, "offset": offset, "limit": 4 },
        headers: {
          Accept: "application/json",
          Authorization: "Bearer " + datatoken,
        },
      })
        .then((response) => {
          setAnimating(false)
          console.log('notification-setting', response?.data?.result)
          setpostEnabled(response?.data?.result.add_new_video_notification)
          setEnabled(response?.data?.result.all_notification)
          setcommentEnabled(response?.data?.result.comment_notification)
          setfollowEnabled(response?.data?.result.follow_notification)
          setlikeEnabled(response?.data?.result.like_notification)
          setsoundEnabled(response?.data?.result.notification_sound)
        })
        .catch(function (error) {
          setAnimating(false)

          console.log('error-setting', error)
        });
  
  });
  }
  const deleteaccount = () => {
    Alert.alert('', 'desea eliminar su cuenta de perfil definitivamente?', [
      //   { text: 'OK', onPress: () => dispatch(logout()) },
      { text: 'Sí', onPress: () =>deleteuser() },
      {
        text: 'Cancelar',
        onPress: () => console.log('Cancel Pressed'),
        style: 'cancel',
      },
    ]);
  }
  const deleteuser = () => {
    setAnimating(true)
    AsyncStorage.getItem('auth_token').then(async (datatoken) => {
      axios({
        url: Apiurl + "user/delete-profile",
        method: "GET",
        headers: {
          Accept: "application/json",
          Authorization: "Bearer " + datatoken,
        },
      })
        .then((response) => {
          setAnimating(false)
          dispatch(logout())
          Alert.alert('', 'Éxito Su cuenta de perfil ha sido eliminada definitivamente.', [
            //   { text: 'OK', onPress: () => dispatch(logout()) },
            { text: 'Sí', onPress: () =>console.log()},
           
          ]);
       
        })
        .catch(function (error) {
          setAnimating(false)
          // showMessage({
          //   message: "Éxito Su cuenta de perfil ha sido eliminada definitivamente.",
          //   type: "danger",
          // });
      
          console.log('error-setting', error)
        });
  
  });
  }
  return (


      <ImageBackground
        style={{ flex: 1,  }}
        resizeMode={"stretch"}
        backgroundColor={'black'}
        source={require("../../assets/splash/bg.png")}
        >
      <Header back={true} {...props} title={'Ajustes'}   />
    <View style={{ flex: 1,marginTop:70}}>
    <View
          style={{
            flexDirection: "row",
            justifyContent: "space-between",
            //padding: verticalScale(15),
            paddingTop:10,
            paddingLeft:15,
            paddingRight:15,
            alignItems: "center",
          }}
        >
          <View style={{ flexDirection: "row", alignItems: "center" }}>
         

            <Text
              style={{
                marginLeft: moderateScale(8),
                fontSize: moderateScale(15),
                fontf: FONTS.PoppinsRegular,
                color: "white",
              }}
            >
             Notificación mensajes
            </Text>
          </View>
          <TouchableOpacity style={{padding:5,}} onPress={()=>updatenotification(6,!Enabled)}>
            <Image
              source={
                Enabled
                  ? require("../../assets/Home/ontoggle.png")
                  : require("../../assets/Home/offtoggle.png")
              }
            />
          </TouchableOpacity>
        </View>
        <View
          style={{
            flexDirection: "row",
            justifyContent: "space-between",
            //padding: verticalScale(15),
            paddingTop:10,
            paddingLeft:15,
            paddingRight:15,
            alignItems: "center",
          }}
        >
          <View style={{ flexDirection: "row", alignItems: "center" }}>
         

            <Text
              style={{
                marginLeft: moderateScale(8),
                fontSize: moderateScale(15),
                fontf: FONTS.PoppinsRegular,
                color: "white",
              }}
            >
           Notificación me gusta 
            </Text>
          </View>
          <TouchableOpacity style={{padding:5,}} onPress={()=>updatenotification(2,!likeEnabled)}>
            <Image
              source={
                likeEnabled
                  ? require("../../assets/Home/ontoggle.png")
                  : require("../../assets/Home/offtoggle.png")
              }
            />
          </TouchableOpacity>
        </View>
        <View
          style={{
            flexDirection: "row",
            justifyContent: "space-between",
            //padding: verticalScale(15),
            paddingTop:10,
            paddingLeft:15,
            paddingRight:15,
            alignItems: "center",
          }}
        >
          <View style={{ flexDirection: "row", alignItems: "center" }}>
         

            <Text
              style={{
                marginLeft: moderateScale(8),
                fontSize: moderateScale(15),
                fontf: FONTS.PoppinsRegular,
                color: "white",
              }}
            >
            Notificación comentario vídeo
            </Text>
          </View>
          <TouchableOpacity style={{padding:5,}} onPress={()=>updatenotification(3,!commentEnabled)}>
            <Image
              source={
                commentEnabled
                  ? require("../../assets/Home/ontoggle.png")
                  : require("../../assets/Home/offtoggle.png")
              }
            />
          </TouchableOpacity>
        </View>
        <View
          style={{
            flexDirection: "row",
            justifyContent: "space-between",
            //padding: verticalScale(15),
            paddingTop:10,
            paddingLeft:15,
            paddingRight:15,
            alignItems: "center",
          }}
        >
          <View style={{ flexDirection: "row", alignItems: "center" }}>
         

            <Text
              style={{
                marginLeft: moderateScale(8),
                fontSize: moderateScale(15),
                fontf: FONTS.PoppinsRegular,
                color: "white",
              }}
            >
           Notificación nuevo seguidor
            </Text>
          </View>
          <TouchableOpacity style={{padding:5,}} onPress={()=>updatenotification(1,!followEnabled)}>
            <Image
              source={
                followEnabled
                  ? require("../../assets/Home/ontoggle.png")
                  : require("../../assets/Home/offtoggle.png")
              }
            />
          </TouchableOpacity>
        </View>

        <View
          style={{
            flexDirection: "row",
            justifyContent: "space-between",
            //padding: verticalScale(15),
            paddingTop:10,
            paddingLeft:15,
            paddingRight:15,
            alignItems: "center",
          }}
        >
          <View style={{ flexDirection: "row", alignItems: "center",width:'70%' }}>
         

            <Text
              style={{
                marginLeft: moderateScale(8),
                fontSize: moderateScale(15),
                fontf: FONTS.PoppinsRegular,
                color: "white",
              }}
            >
        Notificación nueva publicación perfiles que sigo</Text>
          </View>
          <TouchableOpacity style={{padding:5,}} onPress={()=>updatenotification(4,!postEnabled)}>
            <Image
              source={
                postEnabled
                  ? require("../../assets/Home/ontoggle.png")
                  : require("../../assets/Home/offtoggle.png")
              }
            />
          </TouchableOpacity>
        </View>


        <View
          style={{
            flexDirection: "row",
            justifyContent: "space-between",
            //padding: verticalScale(15),
            paddingTop:10,
            paddingLeft:15,
            paddingRight:15,
            alignItems: "center",
          }}
        >
          <View style={{ flexDirection: "row", alignItems: "center",width:'70%' }}>
         

            <Text
              style={{
                marginLeft: moderateScale(8),
                fontSize: moderateScale(15),
                fontf: FONTS.PoppinsRegular,
                color: "white",
              }}
            >
           Sonido notificaciones
         </Text>
          </View>
          <TouchableOpacity style={{padding:5,}} onPress={()=>updatenotification(5,!soundEnabled)}>
            <Image
              source={
                soundEnabled
                  ? require("../../assets/Home/ontoggle.png")
                  : require("../../assets/Home/offtoggle.png")
              }
            />
          </TouchableOpacity>
        </View>

        <View
          style={{
            flexDirection: "row",
            justifyContent: "space-between",
            //padding: verticalScale(15),
            paddingTop:10,
            paddingLeft:15,
            paddingRight:15,
            alignItems: "center",
          }}
        >
          <View style={{ flexDirection: "row", alignItems: "center",width:'70%' }}>
         

            <Text
              style={{
                marginLeft: moderateScale(8),
                fontSize: moderateScale(15),
                fontf: FONTS.PoppinsRegular,
                color: "white",
              }}
            >
          Eliminar mi cuenta perfil
         </Text>
          </View>
          <TouchableOpacity style={{padding:10,}} onPress={()=>deleteaccount()}>
          <Image style={{marginRight:5, tintColor:'white'}} source={require("../../assets/images/backbutton.png")} />
          </TouchableOpacity>

        </View>
        <View
          style={{
            flexDirection: "row",
            justifyContent: "space-between",
            //padding: verticalScale(15),
            paddingTop:10,
            paddingLeft:15,
            paddingRight:15,
            alignItems: "center",
          }}
        >
          <View style={{ flexDirection: "row", alignItems: "center",width:'70%' }}>
         

            <Text
              style={{
                marginLeft: moderateScale(8),
                fontSize: moderateScale(15),
                fontf: FONTS.PoppinsRegular,
                color: "white",
              }}
            >
          Cambiar mi contraseña
         </Text>
          </View>
          <TouchableOpacity style={{padding:10,}} onPress={()=>props.navigation.navigate(NAVIGATION.Changepassword)}>
          <Image style={{marginRight:5, tintColor:'white'}} source={require("../../assets/images/backbutton.png")} />
          </TouchableOpacity>

        </View>
    </View>
    {animating == true && (
          <ActivityIndicator
            animating
            color={'white'}
            size="large"
            style={styles.activityIndicator}
          />
        )}
      </ImageBackground>

    
  );
};

export default Settings;
