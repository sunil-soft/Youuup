import { FONTS } from "@/theme/fonts";
import AsyncStorage from '@react-native-async-storage/async-storage';
import axios from "axios";
import { useEffect, useState } from "react";
import { ActivityIndicator, FlatList, Image, ImageBackground, StatusBar, Text, View } from "react-native";
import { TouchableOpacity } from "react-native-gesture-handler";
import { KeyboardAwareScrollView } from 'react-native-keyboard-aware-scroll-view';
import { useDispatch, useSelector } from "react-redux";
import { blocklistapi, logout } from "../../actions/UserActions";
import { Header } from "../../components/Header";
import { moderateScale } from "../../helper/Scale";
import { getUser } from "../../selectors/UserSelectors";
import { styles } from "./Blockliststyles";

//const APIBASEURL='http://103.15.67.180:4006/'
const APIBASEURL='https://youuup.es/mobile-api/'



  const Blocklist = (props) => {
  const dispatch = useDispatch();
  const { navigation, route } = props;
  const user = useSelector(getUser);
  //const { usernameshow,creater_id,tabactivestatus } = route.params;

  const [animating, setAnimating] = useState(false);
 // const [activetab, setactivetab] = useState(tabactivestatus==1?2:1);
  //const [activestatus, setactivestatus] = useState(2);


  // useFocusEffect(
  //   React.useCallback(() => {
  //     const unsubscribe = followerlist(tabactivestatus);
     
  //     return () => unsubscribe;
  //   }, [])
  // );
  

  const blocklist = () => {
    dispatch(blocklistapi());
  };
   useEffect(() => {
  // console.log('fgf',user && user.followerslist)
   blocklist()
    }, []);
    const addblock = (creater_id,status) => {

    // console.log({"follow_to_id":follow_to_id,"follow_status":status==true?2:1})
     AsyncStorage.getItem('auth_token').then(async (datatoken) => { 
       console.log(datatoken)
     axios({
       url: APIBASEURL+"block/block-user",
       method: "POST",
       data: {"block_to_id":creater_id,"block_status":status},
       headers: {
         Accept: "application/json",
         Authorization:"Bearer "+datatoken,
       },
     })
     .then((response) => {
       console.log('response', response)
       blocklist()
      })
     .catch(function (error) {
       console.log("error11", error);
       if(error?.response?.data?.message=='Unauthorized')
       {
      
        dispatch(logout());
       }
     });
    });
     };

  return (
    <ImageBackground
      style={{ flex: 1,  }}
      backgroundColor={'black'}
      resizeMode={"stretch"}
     // source={require("../../assets/images/editprofileback.png")}
      source={require("../../assets/splash/bg.png")}
    >
      <StatusBar translucent backgroundColor="transparent" />
      <Header back={true} {...props} title={'Bloqueados'}  />
      {/* {showModal && <PopUp />} */}
  <KeyboardAwareScrollView>
  <View style={styles.mainContainer}>
      <View style={{ backgroundColor:"#2A2A2A",height:0.5,marginTop:60,width:'90%',justifyContent:'center',alignSelf:'center'}}></View>
       {user?.blockUserList?.length>0 ?
      <FlatList
        data={user && user.blockUserList}
         renderItem={({item}) => 
      <View style={{marginTop:10, flexDirection:"row",marginLeft:15,marginRight:15, alignContent:'center',alignItems:'center'}}>
      <View style={{width:'20%'}}>
      {/* <Image style={{width:56,height:56,borderRadius:50}} source={{uri:item.profile_photo}} /> */}
       {item?.profile_photo?
          <Image style={{width: 60, height: 60,borderRadius:50 }} 
           source={{uri:APIBASEURL+item.profile_photo}}
             />
             :
             <Image style={{width: 60, height: 60,borderRadius:50 }} 
             source={require("../../assets/images/defaultuser.png")}
             />
          } 
      </View>
      <View style={{width:'44%',marginLeft:3}}>
      <TouchableOpacity>
      <Text style={{color:'#08DDFD', fontSize: moderateScale(14),fontWeight:"600",fontFamily:FONTS.PoppinsMedium}}>{item.name}</Text>
      </TouchableOpacity>
      </View>
      <View style={{width:'38%',justifyContent:"center",alignItems:'center',alignContent:'center'}}>
      <TouchableOpacity 
      onPress={()=>addblock(item.id,2)}
      style={{ backgroundColor:"#08DDFD",padding:8,paddingLeft:5,paddingRight:5, borderWidth:1,borderColor:'#08DDFD', borderRadius:20,justifyContent:'center',alignContent:"center",alignItems:'center'}}>
       <Text style={{color:"#000000",
       fontSize: moderateScale(14),
      // fontSize: 14,
       fontFamily:FONTS.PoppinsMedium}}>Desbloqueo</Text>
       </TouchableOpacity>
      </View>
     </View>
        }
        keyExtractor={item => item.id}
      /> 
      :
      <View style={{justifyContent:"center",alignContent:'center',alignItems:'center',marginTop:40}}>
      <Text style={{color:'white'}}>
        No hay resultados
       </Text>
       </View>
     }  
  </View>
          {animating == true && (
           <ActivityIndicator
            animating
           color={'black'}
           size="large"
           style={styles.activityIndicator}
           />
           )} 
           </KeyboardAwareScrollView>
   </ImageBackground>
  );
};

export default Blocklist;
