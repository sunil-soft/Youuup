import React, { useEffect, useRef, useState } from 'react';

import { useFocusEffect } from "@react-navigation/native";
import { Dimensions, Image, ImageBackground, Platform, StatusBar, StyleSheet, Text, TouchableOpacity, View } from 'react-native';
import RtcEngine, {
  ChannelProfile,
  RtcRemoteView
} from 'react-native-agora';
import { useSelector } from "react-redux";
import { Header } from "../../components/Header";
import { getUser } from "../../selectors/UserSelectors";
const SCREEN_HEIGHT = Dimensions.get('window').height;
const SCREEN_WIDTH = Dimensions.get('window').width;
export default   livevideoNew = (props) => {
   const { navigation, route } = props;
   const user = useSelector(getUser);
   //const {chanelname,token} = route.params;
  // const { type } = route.params;
 //  const isBroadcaster = route.params.type === 'create';
   //const isBroadcaster ='create';

  //const isBroadcaster = 'create';
  //const channelId = route.params.chanelname;
  const channelId = route.params?.chanelname;
  //const channelId = 'test';


  const [joined, setJoined] = useState(false);
  const [isBroadcastersts, setisBroadcaster] = useState('');
  const [peerIds, setpeerids] = useState([]);
  const [callmutests, setcallmutestatus] = useState(false);
  const AgoraEngine = useRef();
  
  useFocusEffect(
    React.useCallback(() => {
  
    }, [])
  );
  const callmute = async(status) => 
  {
    try {
      AgoraEngine.current?.enableLocalAudio(!status);
      setcallmutestatus(!status)
    
  } catch (e) {
      console.log(e);
  }
  }
  useEffect(() => {
    if (Platform.OS === 'android') getPermission();
    init().then(() =>
      AgoraEngine.current.joinChannel(route.params.token, channelId, null, 5)
    );
    return () => {
      AgoraEngine.current?.leaveChannel();
      //AgoraEngine.current.destroy();
    };
  }, []);
  const getPermission = async () => {
    if (Platform.OS === 'android') {
        await PermissionsAndroid.requestMultiple([
            PermissionsAndroid.PERMISSIONS.RECORD_AUDIO,
            PermissionsAndroid.PERMISSIONS.CAMERA,
        ]);
    }
};

  const init = async () => {
    AgoraEngine.current = await RtcEngine.create('6e80f1084211439492a257f8f4b41539');
    AgoraEngine.current.enableVideo();
    AgoraEngine.current.setChannelProfile(ChannelProfile.LiveBroadcasting);
    AgoraEngine.current.enableLocalAudio(false);

    
    // if (isBroadcaster)
    //   AgoraEngine.current.setClientRole(ClientRole.Broadcaster);

    AgoraEngine.current.addListener(
      'JoinChannelSuccess',
      (channelId, uid, elapsed) => {
        console.log('JoinChannelSuccess', channelId, uid, elapsed);
        setJoined(true);
      },
    );
    AgoraEngine.current.addListener(
        'UserJoined',
        (uid, elapsed) => {
          console.log('UserJoined11', uid, elapsed);
         
        setpeerids(peerIds => [...peerIds,uid]);
    
         // setJoined(true);
        },
        );
        
        AgoraEngine.current.addListener(
          'LeaveChannel',
          (uid, elapsed) => {
            console.log('LeaveChannel', uid, elapsed);
           
        //  setpeerids(peerIds => [...peerIds,uid]);
      
           // setJoined(true);
          },
          );
          AgoraEngine.current.addListener(
            'UserOffline',
            (uid, elapsed) => {
              console.log('UserOffline', uid, elapsed);
              props.navigation.goBack()
          // setpeerids(peerIds => [...peerIds,uid]);
        
             // setJoined(true);
            },
            );
          console.log(AgoraEngine.current)
  };
 

 // const onSwitchCamera = () => AgoraEngine.current.switchCamera();
  const callbacks = {
    EndCall: () => setVideoCall(false),
};

  return (
    <ImageBackground
      style={{ flex: 1,  }}
      resizeMode={"stretch"}
      source={require("../../assets/images/editprofileback.png")}
    >
       <Header back={true} {...props} title={route.params?.chanelname} />
       <StatusBar translucent backgroundColor="transparent" />

      <View style={{}}>
   
          <View style={styles.buttonContainer}>
            <Text>{peerIds.length}</Text>
          </View>
      {/* {!joined ? (
        <>
          <ActivityIndicator
            size={60}
            color="#222"
            style={styles.activityIndicator}
          />
          <Text style={styles.loadingText}>
            {'Joining Stream, Please Wait'}
          </Text>
        </>
      ) : ( */}
        <>
          {/* {isBroadcaster ? ( */}
            {/* <RtcLocalView.SurfaceView
              style={styles.fullscreen}
              channelId={channelId}
            /> */}
          {/* ) : ( */}
            {/* <RtcRemoteView.SurfaceView
              uid={1}
              style={styles.fullscreen}
              channelId={channelId}
            /> */}
         
                 {peerIds.length>0 && peerIds.map((value, index, array) => {
                    return (
                        <RtcRemoteView.SurfaceView
                        style={styles.fullscreen}

                              uid={value}
                          //  channelId={'test'}
                          //  renderMode={VideoRenderMode.Hidden}
                            zOrderMediaOverlay={true}/>
                    )
                })} 
       
       <View style={{flexDirection:'row',justifyContent:'space-around'}}>
          <TouchableOpacity style={styles.buttonstyle} onPress={()=>callmute(callmutests)}>
              <Image style={{height:60,width:60}} source={!callmutests?require("../../assets/Home/New/unmute.png"):require("../../assets/Home/New/mute.png")} />
          </TouchableOpacity> 
           <TouchableOpacity style={styles.buttonstyle} onPress={()=>props.navigation.goBack()}>
              <Image style={{height:60,width:60}} source={require("../../assets/Home/New/callcancel.png")} />
          </TouchableOpacity> 
        </View>
          
        </>
    </View>
    </ImageBackground>
  );
}

const styles = StyleSheet.create({
  loadingText: {
    fontSize: 18,
    color: '#222',
  },
  fullscreen: {
    width: SCREEN_WIDTH,
    height: SCREEN_HEIGHT-70,
  },
  buttonstyle: {
     position:'relative',
     zIndex:100000,
     bottom:70,
   },
});