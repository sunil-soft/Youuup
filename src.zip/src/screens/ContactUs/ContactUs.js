// import AsyncStorage from '@react-native-async-storage/async-storage';
import axios from "axios";
import { useEffect, useState } from "react";
import { ActivityIndicator, ImageBackground, StatusBar, View } from "react-native";
import { KeyboardAwareScrollView } from 'react-native-keyboard-aware-scroll-view';

import { useDispatch, useSelector } from "react-redux";
import { Header } from "../../components/Header";
import { getUser } from "../../selectors/UserSelectors";
// import { FONTS } from "../../theme/fonts";
//import { aboutus } from "../../actions/UserActions";
import RenderHtml from 'react-native-render-html';
import { styles } from "./ContactUsStyles";
const tagsStyles = {
  body: {
    whiteSpace: 'normal',
    color: 'white'
  },
  a: {
  //  color: 'green'
  }
};
const ContactUs = (props) => {
  const dispatch = useDispatch();
  const { navigation, route } = props;
  const [animating, setAnimating] = useState(false);
  const [contactdata, setcontactdata] = useState('');
  const user = useSelector(getUser);

  useEffect(() => {
    setAnimating(true)
    axios({
      url: "https://youuup.es/mobile-api/managepages/pages-list",
      method: "GET",
      headers: {
        Accept: "application/json",
       // Authorization: "Bearer " + datatoken,
      },
    })
      .then((response) => {
        setAnimating(false)
         console.log(response.data.result)
         var index = response.data.result.findIndex(img => img.page_url == 'contactandsuggestions');
       console.log()
         setcontactdata(response.data.result[index].page_description)
         
        // if (response.data?.paymentStatus == false) {
        //   navigation.navigate(NAVIGATION.Membership)

        // }
        // setpaymentStatus(response.data?.paymentStatus)


      })
      .catch(function (error) {
        setAnimating(false)
        console.log("error", error);
      });
 
}, []);
const sourcehtml = {
  html: "<div><p style='color:white;'>"+contactdata+"</p></div>"

};
  return (
    <ImageBackground
      style={{ flex: 1, }}
      resizeMode={"stretch"}
      source={require("../../assets/images/editprofileback.png")}
    >

      <StatusBar translucent backgroundColor="transparent" />
      <Header back={true} {...props} title='Contacto y sugerencias' />
      <KeyboardAwareScrollView>
        <View style={styles.mainContainer}>
          <View style={{ marginTop: 100, marginLeft: 20, marginRight: 7 }}>
            {/* <Text style={{ color: 'white', fontFamily: FONTS.PoppinsRegular, fontSize: 14 }}>
              Titularidad {`\n`}
              Se informa a los usuarios de la presente página Web/app, en adelante Usuario, particular y/o profesional/creador de contenido, que el titular de Youuup en adelante Sitio Web/app, es Bobili-Bobili Solutions S.L.{`\n`}{`\n`}
              BARCELONA SPAIN{`\n`}
              © Bobili-Bobili Solutions 2023 - 2024{`\n`}
              ® Youuup{`\n`}
              ©© Youuup ™{`\n`}
              © Youuup app 2023 - 2024{`\n`}
              <Text onPress={() => Linking.openURL('https://www.bobili-bobili-solutions.com/')}>www.bobili-bobili.com</Text>{`\n`}
              <Text onPress={() => Linking.openURL('https://www.youuup.com/')}>www.youuup.com</Text>{`\n`}
              Youuup app :{`\n`}
              Google Play Store{`\n`}
              App Store{`\n`}
              Email de contacto:<Text onPress={() => Linking.openURL('mailto:Info@youuup.com')}>Info@youuup.com</Text>{`\n`}
              Copyright - Todos los derechos reservados:{`\n`}
              © 2023/2024 Bobili-Bobili Solutions S.L.{`\n`}

              <Text onPress={() => Linking.openURL('https://www.bobili-bobili-solutions.com/')}>www.bobili-bobili.com</Text>{`\n`}
              Contacto:{`\n`}
              Si quieres ponerte en contacto con nosotros por una cuestión informativa{`\n`}
              comercial etc. sobre Youuup o nuestros proyectos:{`\n`}
              Manda un correo electrónico{`\n`}
              detallando el motivo y/o necesidad{`\n`}
              y datos de contacto y lo derivaremos al departamento oportuno para que puedan darte contestación.{`\n`}

              Email: <Text onPress={() => Linking.openURL('mailto:info@bobili-bobili-solutions.com')}>info@bobili-bobili-solutions.com</Text>{`\n`}
              Facturación:{`\n`}
              Si deseas solicitar factura/s del pago de servicio Membresía Youuup, remitir un email a:{`\n`}
              <Text onPress={() => Linking.openURL('mailto:Info@bobili-bobili-solutions.com')}>Info@bobili-bobili-solutions.com</Text>{`\n`}
              Asunto: Solicitar factura{`\n`}
              Incluir datos:{`\n`}
              Nombre fiscal{`\n`}
              DNI ó NIF{`\n`}
              Dirección Fiscal{`\n`}
              Correo electrónico que tienes registrado en Youuup app. {`\n`}
              En el plazo de 5 días máximo recibirás la documentación vía email. {`\n`}
              Gracias por tu colaboración. {`\n`}
              Dpto. Contable Youuup{`\n`}
              Sugerencias:{`\n`}
              Si tienes algo que decir o aportar para mejorar el servicio y/o funcionalidad{`\n`}
              de Youuup app{`\n`}
              mándanos un correo electrónico{`\n`}
              y estudiaremos tu propuesta{`\n`}
              agradeciendo de antemano el interés.{`\n`}
              Email:{`\n`}
              <Text onPress={() => Linking.openURL('mailto:Info@youuup.com')}>Info@youuup.com</Text>{`\n`}
              Gracias por tu colaboración{`\n`}

            </Text> */}
            <RenderHtml
     // contentWidth={500}
     customHTMLElementModels
      source={sourcehtml}
      tagsStyles={tagsStyles}
    />  
          </View>
        </View>
        {animating == true && (
          <ActivityIndicator
            animating
            color={'white'}
            size="large"
            style={styles.activityIndicator}
          />
        )}
      </KeyboardAwareScrollView>
    </ImageBackground>
  );
};

export default ContactUs;
