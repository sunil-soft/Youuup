import { FONTS } from "@/theme/fonts";
import AsyncStorage from '@react-native-async-storage/async-storage';
import { useFocusEffect } from "@react-navigation/native";
import axios from "axios";
import React, { useEffect, useState } from 'react';
import { ActivityIndicator, Alert, FlatList, Image, ImageBackground, StatusBar, Text, TouchableOpacity, View } from "react-native";
import { showMessage } from "react-native-flash-message";
import { useDispatch, useSelector } from "react-redux";
import { logout } from "../../actions/UserActions";
import { Header } from "../../components/Header";
import { NAVIGATION } from "../../constants";
import { Apiurl } from "../../constants/Apiurl";
import { moderateScale } from "../../helper/Scale";
import { getUser } from "../../selectors/UserSelectors";
import { styles } from "./ChatUSerListstyles";

//const APIBASEURL = 'http://103.15.67.180:4006/'
const APIBASEURL = 'https://youuup.es/mobile-api/'


const ChatUSerList = (props) => {
  const dispatch = useDispatch();
  const { navigation, route } = props;
  const user = useSelector(getUser);
  //const { usernameshow,creater_id,tabactivestatus } = route.params;

  const [animating, setAnimating] = useState(false);

  const [userlist, setuserlist] = useState([]);
  useFocusEffect(
    React.useCallback(() => {
      userlistapi()

    }, [])
  );
  const userlistapi = () => {
    AsyncStorage.getItem('auth_token').then(async (datatoken) => {
      if (datatoken) {
        axios({
          url: Apiurl + "user/my-chat-users",

          method: "GET",

          //  data: { "receiverID": receiverID },

          headers: {
            //  "Content-Type": "",
            Accept: "application/json",
            Authorization: "Bearer " + datatoken,
          },
        })
          .then((response) => {
            console.log(response.data.result)
            setuserlist(response.data.result)
            //  setmessagelist(response.data.result);
          })
          .catch(function (error) {
            console.log("error", error);
            if(error?.response?.data?.message=='Unauthorized')
            {
           
             dispatch(logout());
            }
          });
      }
    });

  };

  useEffect(() => {
    //console.log('fgf', user.userinfo?.user.id)
    userlistapi()
  }, []);
  const delete_message = (id) => {
    Alert.alert('', '¿Quieres eliminar mensajes?', [
      //   { text: 'OK', onPress: () => dispatch(logout()) },
      { text: 'Sí', onPress: () =>delete_message_api(id) },
      {
        text: 'Cancelar',
        onPress: () => console.log('Cancel Pressed'),
        style: 'cancel',
      },
    ]);
  }
  const delete_message_api = (id) => {
    AsyncStorage.getItem('auth_token').then(async (datatoken) => {
     console.log({ "receiverID": id })
      if (datatoken) {
        axios({
          url: Apiurl + "user/delete-my-chat",
          method: "POST",
          data: { "receiverID": id },
          headers: {
            Accept: "application/json",
            Authorization: "Bearer " + datatoken,
          },
        })
          .then((response) => {
            console.log(response)
            showMessage({
              message: "Borrado exitosamente.",
              type: "success",
            });
            userlistapi()
          })
          .catch(function (error) {
           console.log(error)
           if(error?.response?.data?.message=='Unauthorized')
           {
          
            dispatch(logout());
           }

          });
      }

    });
  };
  // const addblock = (creater_id, status) => {

  //   // console.log({"follow_to_id":follow_to_id,"follow_status":status==true?2:1})
  //   AsyncStorage.getItem('auth_token').then(async (datatoken) => {
  //     console.log(datatoken)
  //     axios({
  //       url: APIBASEURL + "block/block-user",
  //       method: "POST",
  //       data: { "block_to_id": creater_id, "block_status": status },
  //       headers: {
  //         Accept: "application/json",
  //         Authorization: "Bearer " + datatoken,
  //       },
  //     })
  //       .then((response) => {
  //         console.log('response', response)
  //         blocklist()
  //       })
  //       .catch(function (error) {
  //         console.log("error11", error);
  //       });
  //   });
  // };

  return (
    <ImageBackground
      style={{ flex: 1, }}
      resizeMode={"stretch"}
      backgroundColor={'black'}
      // source={require("../../assets/images/editprofileback.png")}
      source={require("../../assets/splash/bg.png")}
    >
      <StatusBar translucent backgroundColor="transparent" />
      <Header back={true} {...props} title={'Mensajes'} />
      {/* {showModal && <PopUp />}   // item?.receiverID != user.userinfo?.user.id ?*/}

      <View style={styles.mainContainer}>
        <View style={{ backgroundColor: "#2A2A2A", height: 0.5, marginTop: 60, width: '90%', justifyContent: 'center', alignSelf: 'center' }}></View>
        {userlist?.length > 0 ?
          <FlatList
            data={userlist}
            renderItem={({ item }) =>

              item.receiverID != user.userinfo?.user.id &&
              <View style={{ marginTop: 10, flexDirection: "row", marginLeft: 15, marginRight: 15, alignContent: 'center', alignItems: 'center' }}>
                <TouchableOpacity onPress={()=>navigation.navigate(NAVIGATION.Followerdetail,{creater_id:item.id,user_type_id:item.user_type_id})} style={{ width: '20%' }}>
                  {/* <Image style={{width:56,height:56,borderRadius:50}} source={{uri:item.profile_photo}} /> */}
                  {item?.profile_photo ?
                    <Image style={{ width: 60, height: 60, borderRadius: 50 }}
                      source={{ uri: APIBASEURL + item.profile_photo }}
                    />
                    :
                    <Image style={{ width: 60, height: 60, borderRadius: 50 }}
                      source={require("../../assets/images/defaultuser.png")}
                    />
                  }
                </TouchableOpacity>
                <TouchableOpacity onPress={()=>navigation.navigate(NAVIGATION.Followerdetail,{creater_id:item.id,user_type_id:item.user_type_id})} style={{ width: '44%', marginLeft: 3 }}>
                  <View>
                    <Text style={{ color: '#08DDFD', fontSize: moderateScale(14), fontWeight: "600", fontFamily: FONTS.PoppinsMedium }}>{item.name}</Text>
                  </View>
                </TouchableOpacity>
                <View style={{ flexDirection:'row', width: '38%', justifyContent: "space-around", alignItems: 'center', alignContent: 'center' }}>
                  <TouchableOpacity
                  style={{padding:7}}
                    onPress={() => delete_message(item.id)} 
                  >
                    <Image
                     style={{tintColor:'#08DDFD'}}
                     source={require("../../assets/Home/bin.png")}
                    />
                  </TouchableOpacity>
                  <TouchableOpacity
                    //  onPress={() => addblock(item.id, 2)}
                    onPress={() => props.navigation.navigate('Message', { receiverID: item.id })}

                    style={{ backgroundColor: "#08DDFD", padding: 8, paddingLeft: 5, paddingRight: 5, borderWidth: 1, borderColor: '#08DDFD', borderRadius: 20, justifyContent: 'center', alignContent: "center", alignItems: 'center' }}>
                    <Text style={{
                      color: "#000000",
                      fontSize: moderateScale(14),
                      // fontSize: 14,
                      fontFamily: FONTS.PoppinsMedium
                    }}>Mensajes</Text>
                  </TouchableOpacity>
                </View>
              </View>

            }
          //keyExtractor={item => item.id}
          />
          :
          <View style={{ justifyContent: "center", alignContent: 'center', alignItems: 'center', marginTop: 40 }}>
            <Text style={{ color: 'white' }}>
              No hay resultados
            </Text>
          </View>
        }
      </View>
      {animating == true && (
        <ActivityIndicator
          animating
          color={'black'}
          size="large"
          style={styles.activityIndicator}
        />
      )}

    </ImageBackground>
  );
};

export default ChatUSerList;
