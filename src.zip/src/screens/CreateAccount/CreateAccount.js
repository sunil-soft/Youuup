import { useEffect, useState } from 'react';
import {
  ActivityIndicator,
  FlatList, Image, ImageBackground,
  Modal, Platform, StatusBar, Text, TouchableOpacity, View
} from "react-native";
// import DropDownPicker from "react-native-dropdown-picker";
import { newIcon } from "@/assets";
import { getExtension } from "@/helper/GlobalMethods";
import { getUser } from "@/selectors/UserSelectors";
import axios from "axios";
import { NAVIGATION } from "../../constants";
//import { register } from "../../actions/UserActions";
import { Apiurl } from '@/constants/Apiurl';
import messaging from "@react-native-firebase/messaging";
import { Dropdown } from 'react-native-element-dropdown';
import { showMessage } from "react-native-flash-message";
import ImagePicker from "react-native-image-crop-picker";
import { KeyboardAwareScrollView } from 'react-native-keyboard-aware-scroll-view';
import { check, PERMISSIONS, request, RESULTS } from "react-native-permissions";
import { moderateScale } from "react-native-size-matters";
import { useDispatch, useSelector } from "react-redux";
import { Button } from "../../components/Button";
import { Header } from "../../components/Header";
import { InputField } from "../../components/InputField";
import { COLOR } from "../../constants/colors/colors";
import { scale, verticalScale } from "../../helper/Scale";
import { FONTS } from "../../theme/fonts";
import { TextStyles } from "../../theme/TextStyles";
import { styles } from "./CreateAccount.styles";

export default function CreateAccount(props) {
  const { navigation, route } = props;

  // const {navigation, route} = props;
  const dispatch = useDispatch();

  //***********************HOOKS **************************/
  const [email, setEmail] = useState("");
  const [emailconfirm, setEmailConfirm] = useState("");
  const [fullName, setFullName] = useState("");
  const [password, setpassword] = useState("");
  const [password2, setpassword2] = useState("");
  const [isActive, setActive] = useState(false);
  const [showModal, setShowModal] = useState(false);
  const [accepted, setAccepted] = useState(false);
  const [open, setOpen] = useState(false);
  const [selectedSite, setSelectedSite] = useState(null);
  const [address, setAddress] = useState("");
  const [image, setImage] = useState();
  const [secureText, setsecureText] = useState(true);
  const [secureText2, setsecureText2] = useState(true);



  const [radioButtonActive, SetRadioButtonActive] = useState(
    true
  );
  const [selectRole, setselectRole] = useState(0);

  const [emailError, setEmailError] = useState("");
  const [selectedId, setSelectedId] = useState(-1);
  const [imageurll, setimageUrll] = useState();

  const [ImageUri, setImageUri] = useState();
  const selector = useSelector(getUser);
  const [isFocus, setIsFocus] = useState(false);
  const [animating, setAnimating] = useState(false);
  const [isModalVisiblee, setModalVisiblee] = useState(false);
  const [isActiveviewstatus, setisActiveviewstatus] = useState(2);
  const [isActiveviewstatus2, setisActiveviewstatus2] = useState(2);

  var validRegex =
    /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9-]+(?:\.[a-zA-Z0-9-]+)*$/;

  const toggleModall = () => {
    setModalVisiblee(!isModalVisiblee);
  };
  useEffect(() => {
    requestUserPermission();
  }, []);
  const requestUserPermission = async () => {
    const authStatus = await messaging().requestPermission();
    const enabled =
      authStatus === messaging.AuthorizationStatus.AUTHORIZED ||
      authStatus === messaging.AuthorizationStatus.PROVISIONAL;

    if (enabled) {
      console.log('Authorization status:', authStatus);
      // setPermission(true);
    }
  };
  const Validation = () => {
    //alert(image)
    if (!image) {
      showMessage({
        message: "La foto de perfil es obligatoria",
        type: "danger",
      });
    }
    //else
    else if (!fullName.trim()) {
      showMessage({
        message: "Por favor, escriba su nombre",
        type: "danger",
      });
    }

    else if (!email.trim()) {
      showMessage({
        message: "El campo de correo electrónico es obligatorio",
        type: "danger",
      });
    }
    else if (!email.match(validRegex)) {
      showMessage({
        message: "Por favor ingrese una dirección de correo electrónico válida",
        type: "danger",
      });
    }
    else if (!emailconfirm.trim()) {
      showMessage({
        message: "El campo de correo electrónico Repetir es obligatorio",
        type: "danger",
      });
    }
    else if (!emailconfirm.match(validRegex)) {
      showMessage({
        message: "Ingrese una dirección de correo electrónico Repetir válida",
        type: "danger",
      });
    }
    else if (email.trim() != emailconfirm.trim()) {
      showMessage({
        message: "Ingrese el mismo correo electrónico y confirme el correo electrónico",
        type: "danger",
      });
    }
    else if (!password.trim()) {
      showMessage({
        message: "El campo de contraseña es obligatorio",
        type: "danger",
      });
    }
    else if (!password2.trim()) {
      showMessage({
        message: "El campo Confirmar contraseña es obligatorio",
        type: "danger",
      });
    }
    else if (password.trim() != password2.trim()) {
      showMessage({
        message: "Ingrese la contraseña y confirme la misma contraseña.",
        type: "danger",
      });
    }
    else if (!selectedSite) {
      showMessage({
        message: "Por favor seleccione país",
        type: "danger",
      });
    }




    else if (!radioButtonActive) {
      showMessage({
        message: "Por favor acepte los Términos y Condiciones",
        type: "danger",
      });
    } else {
      // navigatereplace(NAVIGATION.EditUserDetail);
      createAccountAuth();
      //setShowModal(true);
      // props.navigation.navigate("EditUserDetail");
    }
  };

  const HideModal = () => {
    //  setShowModal(false);
  };

  useEffect(() => {
    setEmail("");
    setEmailConfirm("");
    setFullName("");
    setpassword("");
    setpassword2("");
    setSelectedSite(null);
    setImage("");
    SetRadioButtonActive(false)
  }, []);

  const [roleList, setRoleList] = useState([{ name: 'Usuario', value: 2 }, { name: 'Creador de contenido', value: 3 }]);
  // const [siteList, setSiteList] = useState([{ label: 'Spain', value: 'Spain' }, { label: 'India', value: 'India' }]);
  const [siteList, setSiteList] = useState(
    [{ label: "Afghanistan", value: "Afghanistan" },
    { label: "land Islands", value: "land Islands" },
    { label: "Albania", value: "Albania" },
    { label: "Algeria", value: "Algeria" },
    { label: "American Samoa", value: "American Samoa" },
    { label: "AndorrA", value: "AndorrA" },
    { label: "Angola", value: "Angola" },
    { label: "Anguilla", value: "Anguilla" },
    { label: "Antarctica", value: "Antarctica" },
    { label: "Antigua and Barbuda", value: "Antigua and Barbuda" },
    { label: "Argentina", value: "Argentina" },
    { label: "Armenia", value: "Armenia" },
    { label: "Aruba", value: "Aruba" },
    { label: "Australia", value: "Australia" },
    { label: "Austria", value: "Austria" },
    { label: "Azerbaijan", value: "Azerbaijan" },
    { label: "Bahamas", value: "Bahamas" },
    { label: "Bahrain", value: "Bahrain" },
    { label: "Bangladesh", value: "Bangladesh" },
    { label: "Barbados", value: "Barbados" },
    { label: "Belarus", value: "Belarus" },
    { label: "Belgium", value: "Belgium" },
    { label: "Belize", value: "Belize" },
    { label: "Benin", value: "Benin" },
    { label: "Bermuda", value: "Bermuda" },
    { label: "Bhutan", value: "Bhutan" },
    { label: "Bolivia", value: "Bolivia" },
    { label: "Bosnia and Herzegovina", value: "Bosnia and Herzegovina" },
    { label: "Botswana", value: "Botswana" },
    { label: "Bouvet Island", value: "Bouvet Island" },
    { label: "Brazil", value: "Brazil" },


    { label: "Bosnia and Herzegovina", value: "Bosnia and Herzegovina" },
    { label: "Botswana", value: "Botswana" },
    { label: "Bouvet Island", value: "Bouvet Island" },
    { label: "Brazil", value: "Brazil" },
    { label: "British Indian Ocean Territory", value: "British Indian Ocean Territory" },
    { label: "Brunei Darussalam", value: "Brunei Darussalam" },
    { label: "Bulgaria", value: "Bulgaria" },
    { label: "Burkina Faso", value: "Burkina Faso" },
    { label: "Burundi", value: "Burundi" },
    { label: "Cambodia", value: "Cambodia" },
    { label: "Cameroon", value: "Cameroon" },
    { label: "Canada", value: "Canada" },
    { label: "Cape Verde", value: "Cape Verde" },
    { label: "Cayman Islands", value: "Cayman Islands" },
    { label: "Central African Republic", value: "Central African Republic" },
    { label: "Chad", value: "Chad" },
    { label: "Chile", value: "Chile" },
    { label: "China", value: "China" },
    { label: "Christmas Island", value: "Christmas Island" },
    { label: "Cocos (Keeling) Islands", value: "Cocos (Keeling) Islands" },
    { label: "Colombia", value: "Colombia" },
    { label: "Comoros", value: "Comoros" },
    { label: "Congo", value: "Congo" },
    { label: "Congo, The Democratic Republic of the", value: "Congo, The Democratic Republic of the" },
    { label: "Cook Islands", value: "Cook Islands" },
    { label: "Costa Rica", value: "Costa Rica" },
    { label: "Cote D'Ivoire", value: "Cote D'Ivoire" },
    { label: "Croatia", value: "Croatia" },
    { label: "Cuba", value: "Cuba" },
    { label: "Cyprus", value: "Cyprus" },
    { label: "Czech Republic", value: "Czech Republic" },
    { label: "Denmark", value: "Denmark" },
    { label: "Djibouti", value: "Djibouti" },
    { label: "Dominica", value: "Dominica" }, { label: "Dominican Republic", value: "Dominican Republic" }, { label: "Ecuador", value: "Ecuador" }, { label: "Egypt", value: "Egypt" }, { label: "El Salvador", value: "El Salvador" }, { label: "Equatorial Guinea", value: "Equatorial Guinea" }, { label: "Eritrea", value: "Eritrea" }, { label: "Estonia", value: "Estonia" }, { label: "Ethiopia", value: "Ethiopia" }, { label: "Falkland Islands (Malvinas)", value: "Falkland Islands (Malvinas)" }, { label: "Faroe Islands", value: "Faroe Islands" }, { label: "Fiji", value: "Fiji" }, { label: "Finland", value: "Finland" }, { label: "France", value: "France" }, { label: "French Guiana", value: "French Guiana" }, { label: "French Polynesia", value: "French Polynesia" }, { label: "French Southern Territories", value: "French Southern Territories" }, { label: "Gabon", value: "Gabon" }, { label: "Gambia", value: "Gambia" }, { label: "Georgia", value: "Georgia" }, { label: "Germany", value: "Germany" }, { label: "Ghana", value: "Ghana" }, { label: "Gibraltar", value: "Gibraltar" }, { label: "Greece", value: "Greece" }, { label: "Greenland", value: "Greenland" }, { label: "Grenada", value: "Grenada" }, { label: "Guadeloupe", value: "Guadeloupe" }, { label: "Guam", value: "Guam" }, { label: "Guatemala", value: "Guatemala" }, { label: "Guernsey", value: "Guernsey" }, { label: "Guinea", value: "Guinea" }, { label: "Guinea-Bissau", value: "Guinea-Bissau" }, { label: "Guyana", value: "Guyana" }, { label: "Haiti", value: "Haiti" }, { label: "Heard Island and Mcdonald Islands", value: "Heard Island and Mcdonald Islands" }, { label: "Holy See (Vatican City State)", value: "Holy See (Vatican City State)" }, { label: "Honduras", value: "Honduras" }, { label: "Hong Kong", value: "Hong Kong" }, { label: "Hungary", value: "Hungary" }, { label: "Iceland", value: "Iceland" },
    { label: "India", value: "India" },
    { label: "Indonesia", value: "Indonesia" }, { label: "Iran, Islamic Republic Of", value: "Iran, Islamic Republic Of" },
    { label: "Iraq", value: "Iraq" }, { label: "Ireland", value: "Ireland" }, { label: "Isle of Man", value: "Isle of Man" }, { label: "Israel", value: "Israel" },
    { label: "Italy", value: "Italy" }, { label: "Jamaica", value: "Jamaica" }, { label: "Japan", value: "Japan" }, { label: "Jersey", value: "Jersey" }, { label: "Jordan", value: "Jordan" }, { label: "Kazakhstan", value: "Kazakhstan" },
    { label: "Kenya", value: "Kenya" }, { label: "Kiribati", value: "Kiribati" }, { label: "Korea, Democratic People'S Republic of", value: "Korea, Democratic People'S Republic of" }, { label: "Korea, Republic of", value: "Korea, Republic of" }, { label: "Kuwait", value: "Kuwait" }, { label: "Kyrgyzstan", value: "Kyrgyzstan" }, { label: "Latvia", value: "Latvia" }, { label: "Lebanon", value: "Lebanon" }, { label: "Lesotho", value: "Lesotho" }, { label: "Liberia", value: "Liberia" }, { label: "Libyan Arab Jamahiriya", value: "Libyan Arab Jamahiriya" }, { label: "Liechtenstein", value: "Liechtenstein" }, { label: "Lithuania", value: "Lithuania" }, { label: "Luxembourg", value: "Luxembourg" }, { label: "Macao", value: "Macao" }, { label: "Macedonia, The Former Yugoslav Republic of", value: "Macedonia, The Former Yugoslav Republic of" }, { label: "Madagascar", value: "Madagascar" }, { label: "Malawi", value: "Malawi" }, { label: "Malaysia", value: "Malaysia" }, { label: "Maldives", value: "Maldives" }, { label: "Mali", value: "Mali" }, { label: "Malta", value: "Malta" }, { label: "Marshall Islands", value: "Marshall Islands" }, { label: "Martinique", value: "Martinique" }, { label: "Mauritania", value: "Mauritania" }, { label: "Mauritius", value: "Mauritius" }, { label: "Mayotte", value: "Mayotte" }, { label: "Mexico", value: "Mexico" }, { label: "Micronesia, Federated States of", value: "Micronesia, Federated States of" }, { label: "Moldova, Republic of", value: "Moldova, Republic of" }, { label: "Monaco", value: "Monaco" },
    { label: "Mongolia", value: "Mongolia" }, { label: "Montenegro", value: "Montenegro" }, { label: "Montserrat", value: "Montserrat" },
    { label: "Morocco", value: "Morocco" },
    { label: "Mozambique", value: "Mozambique" },
    { label: "Myanmar", value: "Myanmar" }, { label: "Namibia", value: "Namibia" },
    { label: "Nauru", value: "Nauru" },
    { label: "Nepal", value: "Nepal" },
    { label: "Netherlands", value: "Netherlands" },
    { label: "Netherlands Antilles", value: "Netherlands Antilles" }, { label: "New Caledonia", value: "New Caledonia" }, { label: "New Zealand", value: "New Zealand" },
    { label: "Nicaragua", value: "Nicaragua" }, { label: "Niger", value: "Niger" }, { label: "Nigeria", value: "Nigeria" }, { label: "Niue", value: "Niue" },
    { label: "Norfolk Island", value: "Norfolk Island" }, { label: "Northern Mariana Islands", value: "Northern Mariana Islands" }, { label: "Norway", value: "Norway" }, { label: "Oman", value: "Oman" }, { label: "Pakistan", value: "Pakistan" }, { label: "Palau", value: "Palau" }, { label: "Palestinian Territory, Occupied", value: "Palestinian Territory, Occupied" },
    { label: "Panama", value: "Panama" }, { label: "Papua New Guinea", value: "Papua New Guinea" }, { label: "Paraguay", value: "Paraguay" }, { label: "Peru", value: "Peru" }, { label: "Philippines", value: "Philippines" }, { label: "Pitcairn", value: "Pitcairn" }, { label: "Poland", value: "Poland" }, { label: "Portugal", value: "Portugal" }, { label: "Puerto Rico", value: "Puerto Rico" }, { label: "Qatar", value: "Qatar" }, { label: "Reunion", value: "Reunion" }, { label: "Romania", value: "Romania" }, { label: "Russian Federation", value: "Russian Federation" }, { label: "RWANDA", value: "RWANDA" }, { label: "Saint Helena", value: "Saint Helena" }, { label: "Saint Kitts and Nevis", value: "Saint Kitts and Nevis" }, { label: "Saint Lucia", value: "Saint Lucia" }, { label: "Saint Pierre and Miquelon", value: "Saint Pierre and Miquelon" }, { label: "Saint Vincent and the Grenadines", value: "Saint Vincent and the Grenadines" }, { label: "Samoa", value: "Samoa" }, { label: "San Marino", value: "San Marino" }, { label: "Sao Tome and Principe", value: "Sao Tome and Principe" }, { label: "Saudi Arabia", value: "Saudi Arabia" }, { label: "Senegal", value: "Senegal" }, { label: "Serbia", value: "Serbia" }, { label: "Seychelles", value: "Seychelles" }, { label: "Sierra Leone", value: "Sierra Leone" },
    { label: "Singapore", value: "Singapore" }, { label: "Slovakia", value: "Slovakia" }, { label: "Slovenia", value: "Slovenia" }, { label: "Solomon Islands", value: "Solomon Islands" }, { label: "Somalia", value: "Somalia" }, { label: "South Africa", value: "South Africa" }, { label: "South Georgia and the South Sandwich Islands", value: "South Georgia and the South Sandwich Islands" }, { label: "Spain", value: "Spain" }, { label: "Sri Lanka", value: "Sri Lanka" }, { label: "Sudan", value: "Sudan" }, { label: "Surilabel", value: "Surilabel" }, { label: "Svalbard and Jan Mayen", value: "Svalbard and Jan Mayen" }, { label: "Swaziland", value: "Swaziland" }, { label: "Sweden", value: "Sweden" }, { label: "Switzerland", value: "Switzerland" }, { label: "Syrian Arab Republic", value: "Syrian Arab Republic" }, { label: "Taiwan, Province of China", value: "Taiwan, Province of China" }, { label: "Tajikistan", value: "Tajikistan" }, { label: "Tanzania, United Republic of", value: "Tanzania, United Republic of" }, { label: "Thailand", value: "Thailand" }, { label: "Timor-Leste", value: "Timor-Leste" }, { label: "Togo", value: "Togo" }, { label: "Tokelau", value: "Tokelau" }, { label: "Tonga", value: "Tonga" }, { label: "Trinidad and Tobago", value: "Trinidad and Tobago" }, { label: "Tunisia", value: "Tunisia" }, { label: "Turkey", value: "Turkey" }, { label: "Turkmenistan", value: "Turkmenistan" }, { label: "Turks and Caicos Islands", value: "Turks and Caicos Islands" }, { label: "Tuvalu", value: "Tuvalu" }, { label: "Uganda", value: "Uganda" }, { label: "Ukraine", value: "Ukraine" }, { label: "United Arab Emirates", value: "United Arab Emirates" },
    { label: "United Kingdom", value: "United Kingdom" }, { label: "United States", value: "United States" }, { label: "United States Minor Outlying Islands", value: "United States Minor Outlying Islands" },
    { label: "Uruguay", value: "Uruguay" }, { label: "Uzbekistan", value: "Uzbekistan" }, { label: "Vanuatu", value: "Vanuatu" }, { label: "Venezuela", value: "Venezuela" }, { label: "Viet Nam", value: "Viet Nam" }, { label: "Virgin Islands, British", value: "Virgin Islands, British" }, { label: "Virgin Islands, U.S.", value: "Virgin Islands, U.S." }, { label: "Wallis and Futuna", value: "Wallis and Futuna" }, { label: "Western Sahara", value: "Western Sahara" }, { label: "Yemen", value: "Yemen" }, { label: "Zambia", value: "Zambia" },
    { label: "Zimbabwe", value: "Zimbabwe" }]
  );

  useEffect(() => {
    let sitearr = []
    let countryarr = []
    if (selector && selector?.site.length > 0) {
      selector?.site.map((x, index) => {
        sitearr.push({ value: x.id, label: x.name })
      })
      // setSiteList(sitearr)
    }
    siteList.map((userData) => {
      //console.log(userData.label);
      countryarr.push({ "label": userData.label, "value": userData.label })
    });
    // for (var k = 0; k <= siteList.length; k++) {
    //   for (let siteList of this.state.users) {
    //   console.log(siteList[k])
    //   // countryarr.push({ "label": siteList[k]["label"], "value": siteList[k]["value"] })
    // }
    console.log(countryarr)

  }, []);
  //******function call for create Account********************
  const createAccountAuth = async () => {
    //alert(image.path)
    //const fileExtension = getExtension(image.path);

    setAnimating(true)
   // setTimeout(() => { setAnimating(false) }, 700)
    const fcmToken = await messaging().getToken();
    const data = image ? {
      email: email,
      user_type_id: selectRole == 0 ? 2 : 3,
      name: fullName,
      //  file :image.replace("file:///", "") ,
      // file : {
      //   uri:
      //     Platform.OS === "android"
      //       ? image.path
      //       : image.path.replace("file://", ""),

      //   type: image.mime,

      //   name: `profile_image_.${fileExtension}`,
      // },
      password: password,
      device_token: "455454",
      device_type: 1,
      fcmToken: fcmToken,
      country:selectedSite
    } : {
      email: email,
      user_type_id: selectRole == 0 ? 2 : 3,
      name: fullName,
      password: password,
      device_token: "455454",
      device_type: 1,
      fcmToken: fcmToken,
      country:selectedSite

    };
    console.log(data)


    const formData = new FormData();

    if (image.path) {
      const fileExtension = getExtension(image.path);
      const imageData = {
        uri:
          Platform.OS === "android"
            ? image.path
            : image.path.replace("file://", ""),

        type: image.mime,

        name: `profile_image_.${fileExtension}`,
      };

      formData.append("file", imageData);
    }
    formData.append("email", email);
    formData.append("user_type_id", selectRole == 0 ? 2 : 3);
    formData.append("name", fullName);
    formData.append("password", password);
    formData.append("device_token", fcmToken);
    formData.append("device_type", 1);
    formData.append("country",selectedSite);
    console.log("check formData data ", formData);
    // dispatch(imageuploadServer(formData));
    axios({
      url: Apiurl + "user/register",
      method: "POST",
      data: formData,
      headers: {
        "Content-Type": "multipart/form-data",
        Accept: "application/json",
      },
    })
      .then((resp) => {
       // console.log(resp.response.data);
        setAnimating(false)
        navigation.navigate(NAVIGATION.otp, { data: data })
      })
      // .catch((error) => 
      // {console.log(error)
      //   showMessage({
      //     message: error.message,
      //     type: "danger",
      //   });
      //  setAnimating(false)}
      //  );
       .catch(function (error) {
        {
        console.log("error", error.response.data.message);
        if(error.response.data.message=='"email" must be a valid email')
        {
            showMessage({
          message:'Por favor ingrese una dirección de correo electrónico válida',
          type: "danger",
        });
        }
        else{
          showMessage({
            message:error.response.data.message,
            type: "danger",
          });
        }
       setAnimating(false)
      }
      });

    //dispatch(register(data));
  };

  //****************************call Image Picker *************/

  const uploadImages = async (image) => {
    const formData = new FormData();

    const fileExtension = getExtension(image.path);
    const imageData = {
      uri:
        Platform.OS === "android"
          ? image.path
          : image.path.replace("file://", ""),

      type: image.mime,

      name: `profile_image_.${fileExtension}`,
    };
    console.log("check image data ", imageData);
    formData.append("photo", imageData);
  };

  const PopUp2 = () => {
    return (

      <Modal transparent visible={isModalVisiblee}>
        <View
          style={{
            flex: 1,
            backgroundColor: "#000000aa",
            padding: 20,
            justifyContent: "center",
          }}
        >
          <View style={{
            backgroundColor: "white", backgroundColor: "#FFFFFF",
            padding: 20,
            borderRadius: moderateScale(20),
          }}>
            <Text
              style={{
                color: "#43686A",
                fontSize: moderateScale(20),
                fontFamily: FONTS.PoppinsSemiBold,
              }}
            >
              Cargar imagen
            </Text>
            <View
              style={{
                flexDirection: "row",
                alignItems: "center",
                marginTop: verticalScale(10),
              }}
            >
              <Image source={require("../../assets/Home/gallery.png")} />
              <TouchableOpacity onPress={chooseFromGallery}>
                <Text
                  style={{
                    color: "#738485",
                    fontFamily: FONTS.PoppinsRegular,
                    fontSize: moderateScale(18),

                    marginLeft: moderateScale(10),
                  }}
                >
                  Elegir de la galería
                </Text>
              </TouchableOpacity>
            </View>
            <View
              style={{
                flexDirection: "row",
                alignItems: "center",
                marginTop: verticalScale(10),
              }}
            >
              <Image
                style={{ width: scale(19), height: scale(15.2) }}
                source={require("../../assets/Home/photo-camera.png")}
              />
              <TouchableOpacity onPress={takeFromCamera}>
                <Text
                  style={{
                    color: "#738485",
                    fontFamily: FONTS.PoppinsRegular,
                    fontSize: moderateScale(18),
                    marginLeft: moderateScale(10),
                  }}
                >
                  Toma una foto
                </Text>
              </TouchableOpacity>
            </View>
            <TouchableOpacity
              style={{ justifyContent: "center", alignItems: "center" }}
              onPress={toggleModall}
            >
              <Text
                style={{
                  color: "#05A1AB",
                  marginTop: verticalScale(10),
                  fontFamily: FONTS.PoppinsMedium,
                  fontSize: moderateScale(16),
                }}
              >
                Cerrar
              </Text>
            </TouchableOpacity>
          </View>
        </View>
      </Modal>
    );
  };
  const takeFromCamera = () => {
    setModalVisiblee(false);
    ImagePicker.openCamera({
      width: 300,
      height: 400,
      cropping: true,
      mediaType: 'photo',
      cropperToolbarWidgetColor: '#5A67FC',
      cropperActiveWidgetColor: '#5A67FC',
    }).then(image => {

      setImage(image);
      // uploadImages(image);

    })
      .catch(error => {
        if (error.code === "E_NO_CAMERA_PERMISSION") {
          // alert(error);
          // Alert.alert(
          //   `Activa el permiso de la cámara.`,
          //   "",
          //   [
          //     { text: "Ir a la configuración", onPress: () => Linking.openURL('app-settings:') },
          //     { text: "No use fotos", onPress: () => { } },
          //   ],
          // );
          // setModalVisiblee(false);
        }
      });



  }
  const chooseFromGallery = () => {
    setModalVisiblee(false);
    const response = check(
      Platform.select({
        ios: PERMISSIONS.IOS.CAMERA,
        android: PERMISSIONS.ANDROID.CAMERA,
      })
    );
    if (response !== RESULTS.GRANTED && response !== RESULTS.UNAVAILABLE) {
      request(Platform.OS === 'ios' ? PERMISSIONS.IOS.CAMERA : PERMISSIONS.ANDROID.CAMERA).then((result) => {
      });

    }
    else {
      request(Platform.OS === 'ios' ? PERMISSIONS.IOS.CAMERA : PERMISSIONS.ANDROID.CAMERA).then((result) => {
      });
    }

    ImagePicker.openPicker({
      mediaType: 'photo',
      cropping: true,
    }).then(async (image) => {
      console.log('image response => ', image);
      // setLocalURL(file.path);
      // setImageFile(file);
      setImage(image);
      // uploadImages(image);
    })
      .catch(error => {
        if (error.code === "E_NO_LIBRARY_PERMISSION") {
          // setModalVisiblee(false);
          // Alert.alert(
          //   `Active el permiso de la biblioteca de fotos para permitir el acceso a su galería de fotos para cargar fotos`,
          //   "",
          //   [
          //     { text: "Ir a la configuración", onPress: () => Linking.openURL('app-settings:') },
          //     { text: "No use fotos", onPress: () => { } },
          //   ],
          // );
        }
      });
  };
  return (
    // <View style={{ height: '100%', backgroundColor: "#FFFFFF" }}>
    <ImageBackground
      style={{ flex: 1, }}
      resizeMode={"stretch"}
      backgroundColor={'black'}
      source={require("../../assets/splash/bg.png")}
    >
      {/* {showModal && <PopUp />} */}
      {isModalVisiblee && <PopUp2 />}
      <StatusBar translucent backgroundColor="transparent" />
      <Header back={true} {...props} />
      <KeyboardAwareScrollView>
        <View style={styles.mainContainer}>
          <View style={{ alignItems: 'flex-end', alignContent: 'flex-end', marginTop: 10, alignSelf: "center", justifyContent: 'center', alignItems: 'center' }}>
            <Image style={{ marginTop: 40, alignSelf: 'flex-end' }} resizeMode='center' source={require("../../assets/splash/Logo.png")} />
          </View>

          <View style={styles.contentView}>
            {/* <Text style={TextStyles.title}>Keep it Real</Text> */}
            <TouchableOpacity onPress={toggleModall} style={styles.picView}>
              {image ? (
                <Image
                  style={{
                    width: 96,
                    height: 96,
                    borderRadius: moderateScale(25),
                  }}
                  source={{ uri: image.path }}
                />
              ) : (
                <Image source={require("../../assets/images/profileback.png")} />

              )}

              {/* <TouchableOpacity
            //  onPress={launchGallery}
            onPress={toggleModall}
              style={{ position: "absolute", bottom: -1, right: -10 }}
            >
              <Image source={newIcon.Edit} />
            </TouchableOpacity> */}
            </TouchableOpacity>
            <Text style={TextStyles.titlereglabel}>Registro de perfil </Text>
            <View style={{ marginLeft: 5 }}>
              <FlatList
                data={roleList}
                numColumns={2}
                contentContainerStyle={{
                  marginTop: 5,
                }}
                renderItem={({ item, index }) => (
                  <TouchableOpacity
                    onPress={() => {
                      // setSelectedId(item.id);
                      setselectRole(index);
                    }}
                    style={{ flexDirection: "row", margin: 7, right: scale(4) }}
                  >
                    <Image
                      style={{ height: 16, width: 16 }}
                      source={
                        selectRole == index
                          ? newIcon.radioButton
                          : newIcon.Blankradiobutton
                      }
                    />
                    <Text style={styles.roletextStyle}>{item.name}</Text>
                  </TouchableOpacity>
                )}
              />
            </View>
            <Text style={TextStyles.titledis}>{selectRole == 0 ? "Como usuario, tendrás derecho a disfrutar de todo el contenido disponible, pero no a crearlo y siempre será gratuito." : "Como creador de contenido, tendrás derecho a disfrutar de todo el contenido disponible y también a crearlo, será previa membresía mensual detallada en información."}</Text>
            <Text style={styles.placeNameTextStyle}>Nombre o nick</Text>
            <InputField
              onChangeText={(text) => {
                if (text.includes(" ")) {
                  setFullName(text);
                }
                // else if (
                //   text.replace(
                //     /[^0-9,&,!,@,#,$,%,^,&,*,*,(,).,_,_,-,/,`,~,`]/g,
                //     ""
                //   )
                // ) {
                // } 
                else {
                  setFullName(text);
                }
              }}

              value={fullName}
              color={"white"}
              mainViewStyle={{ width: "100%" }}
              // icon={"account"}
              // title={"Full Name"}
              //  placeholder={"Ingresar Nombre o nick"}
              placeholderColor={"white"}
            />
            <Text style={styles.placeNameTextStyle}>Email</Text>
            <InputField
              onChangeText={(email) => setEmail(email.replace(/\s/g, ''))}
              value={email}
              // icon={"email"}
              color={"grey"}
              // title={" Ingresar Email"}
              // placeholder={"Ingresar Email"}
              placeholderColor={"#93AFB1"}
              mainViewStyle={{ marginTop: 0, width: "100%" }}
            />
            <Text style={styles.placeNameTextStyle}>Repetir Email</Text>
            <InputField
              onChangeText={(emailconfirm) => setEmailConfirm(emailconfirm.replace(/\s/g, ''))}
              value={emailconfirm}
              // icon={"email"}
              color={"grey"}
              // title={"Email Address"}
              // placeholder={"Enter your Email"}
              placeholderColor={"#93AFB1"}
              mainViewStyle={{ marginTop: 0, width: "100%" }}
            />
            <Text style={styles.placeNameTextStyle}>Contraseña</Text>
            <View style={{ flexDirection: 'row', alignItems: "center" }}>

              <InputField
                onChangeText={(password) => setpassword(password)}
                value={password}
                secureTextEntry={secureText2}
                // icon={"email"}
                color={"grey"}
                // title={"Email Address"}
                // placeholder={"Enter your Email"}
                placeholderColor={"#93AFB1"}
                mainViewStyle={{ marginTop: 0, width: "100%" }}
              />
              <TouchableOpacity
                onPress={() => { setisActiveviewstatus2(1), setsecureText2(!secureText2) }}
                style={{ position: 'relative', zIndex: 999999, right: 30, padding: 4 }} >
                <Image source={secureText2 ? require("../../assets/login/closeeye.png") : require("../../assets/login/openeye.png")} />
              </TouchableOpacity>
            </View>
            <Text style={styles.placeNameTextStyle}>Repetir Contraseña</Text>
            <View style={{ flexDirection: 'row', alignItems: "center" }}>

              <InputField
                onChangeText={(password2) => setpassword2(password2)}
                value={password2}
                // icon={"email"}
                color={"grey"}
                secureTextEntry={secureText}

                //title={"Email Address"}
                //  placeholder={"Enter your Email"}
                placeholderColor={"#93AFB1"}
                mainViewStyle={{ marginTop: 0, width: "100%" }}
              />
              <TouchableOpacity
                onPress={() => { setisActiveviewstatus(1), setsecureText(!secureText) }}
                style={{ position: 'relative', zIndex: 999999, right: 30, padding: 4 }} >
                <Image source={secureText ? require("../../assets/login/closeeye.png") : require("../../assets/login/openeye.png")} />
              </TouchableOpacity>
            </View>
            <Text style={styles.placeNameTextStyle}>País</Text>
            <View
              style={{
                //backgroundColor: "#08DDFD",
                backgroundColor: isFocus ? "rgba(26, 91, 101, 1)" : "rgba(97, 156, 165, 0.09)",

                // opacity:isFocus   ? 0.5 : 0.09,
                zIndex: 1000,
                borderRadius: moderateScale(15),
                marginBottom: 20,
                borderRadius: 25,
                height: 60,
                //   alignItems:'center',
                justifyContent: 'center',
                alignContent: 'center'
              }}
            >

              <Dropdown
                style={[styles.dropdown, isFocus && { borderWidth: 0 }]}
                placeholderStyle={styles.placeholderStyle}
                selectedTextStyle={styles.selectedTextStyle}
                inputSearchStyle={styles.inputSearchStyle}
                itemTextStyle={{color:'black'}}
                iconStyle={styles.iconStyle}
             
                containerStyle={{
                  bottom: verticalScale(25),
                }}
                data={siteList}
                search
                maxHeight={300}
                labelField="label"
                valueField="value"
                placeholder={!isFocus ? '' : ''}
                searchPlaceholder="Buscar..."
                value={selectedSite}
                onFocus={() => setIsFocus(true)}
                onBlur={() => setIsFocus(false)}
                onChange={item => {
                  setSelectedSite(item.value);
                  setIsFocus(false);
                }}
                // renderLeftIcon={() => (
                //   <AntDesign
                //     style={styles.icon}
                //     color={isFocus ? 'blue' : 'black'}
                //     name="Safety"
                //     size={20}
                //   />
                // )}
                renderRightIcon={() => (
                  <Image
                    style={{ marginTop: verticalScale(8) }}
                    source={require("../../assets/reg/downarrow.png")}
                  />
                )}
              />
            </View>
            <View style={styles.termsView}>
              <TouchableOpacity
                onPress={() => SetRadioButtonActive(!radioButtonActive)}
              >
                {radioButtonActive ? (
                  <Image
                    style={{ width: 20, height: 20, marginRight: 10, marginTop: verticalScale(16) }}
                    source={newIcon.checkedcheck}
                  />
                ) : (
                  <Image
                    style={{ width: 20, height: 20, marginTop: verticalScale(16), marginRight: 10, }}
                    source={newIcon.Checkbox}
                  />
                )}
              </TouchableOpacity>
              <Text style={[TextStyles.terms, { fontSize: 13, }]}>
                He leído y acepto <Text onPress={() => navigation.navigate(NAVIGATION.Privacy, { pageshow: 1 })} style={{ color: '#08DDFD' }}>La política de privacidad y</Text> las <Text style={{ color: '#08DDFD' }} onPress={() => navigation.navigate(NAVIGATION.Terms)}>Condiciones de uso.</Text>
              </Text>
            </View>
            <Button
              onPress={Validation}
              title={"Entrar"}
            />
            <View style={styles.bottomView}>
              <Text style={[TextStyles.light2, { fontSize: 14 }]}>
                ¿Ya tienes una cuenta?{""}
              </Text>
              <TouchableOpacity
                onPress={() => props.navigation.goBack()}
              >
                <Text
                  style={[
                    TextStyles.light2,
                    {
                      fontSize: 14,
                      color: COLOR.AppColor,
                      fontFamily: FONTS.PoppinsMedium,
                      marginLeft: moderateScale(5),
                    },
                  ]}
                >
                  Inicia sesión
                </Text>
              </TouchableOpacity>
            </View>
          </View>
        </View>
        {animating == true && (
          <ActivityIndicator
            animating
            color={'white'}
            size="large"
            style={styles.activityIndicator}
          />
        )}
      </KeyboardAwareScrollView>
    </ImageBackground>
  );
}
