import { StyleSheet } from "react-native";
import { COLOR } from "../../constants/colors/colors";
import Scale, { moderateScale, verticalScale } from "../../helper/Scale";
import { FONTS } from "../../theme/fonts";
export const styles = StyleSheet.create({
  contentView: {
    paddingLeft: 20,
    paddingRight:20,
   // marginVertical: verticalScale(20),
    width: "100%",
    height:'100%',
    alignSelf: "center",
  },
  mainContainer: {
    //flex: 1,
    height:'100%',
    // paddingVertical: verticalScale(40),
    // paddingHorizontal: verticalScale(20),
  },
  listItemView: {
    flexDirection: "row",
    alignItems: "center",
    width: "50%",
  },
  listTitleTxt: {
    paddingHorizontal: 5,
    fontFamily: FONTS.PoppinsLight,
    color: "#93AFB1",
  },
  termsView: {
    flexDirection: "row",
    padding: verticalScale(10),
    alignSelf: "center",
    alignItems: "flex-start",
  },
  termsHighlightTxt: {
    color: COLOR.AppColor,
    fontFamily: FONTS.PoppinsMedium,
  },
  termsTxt: {
    fontFamily: FONTS.PoppinsLight,
    paddingHorizontal: 10,
    textAlign: "center",
  },
  picView: {
    width: verticalScale(90),
    height: verticalScale(90),
    marginTop:15,
    marginBottom:15,
  //  backgroundColor: "#EBF0F1",
    // backgroundColor: 'red',
    alignSelf: "center",

    borderRadius: 20,
    alignItems: "center",
    justifyContent: "center",
  },
  desTxt: {
    color: "#738485",
    paddingLeft: verticalScale(5),
    fontFamily: FONTS.PoppinsLight,
    width: "95%",
    fontSize: moderateScale(14),
  },
  headTxt: {
    marginTop: 40,
    paddingHorizontal: verticalScale(20),
    color: "#43686A",
    fontSize: 30,
    fontFamily: FONTS.PoppinsSemiBold,
  },
  submitButton: {
    marginTop: 30,
  },
  Title: {
    fontFamily: FONTS.PoppinsSemiBold,
    fontStyle: "normal",
    fontSize: Scale.moderateScale(32),
    color: "#000000",
    fontWeight: "600",
  },
  TitleDis: {
    fontFamily: FONTS.PoppinsRegular,
    paddingTop: 10,
    fontSize: Scale.moderateScale(14),
    color: "#615B5B",
    fontWeight: "400",
  },
  textTitle: {
    fontFamily: FONTS.PoppinsRegular,
    paddingTop: 10,
    fontSize: Scale.moderateScale(14),
    color: "#313131",
    fontWeight: "400",
  },
  bottomView: {
    alignSelf: "center",
    flexDirection: "row",
    marginTop: verticalScale(10),
    marginBottom:10
  },
  placeNameTextStyle: {
    color: "#08DDFD",
    fontSize: moderateScale(12),
    fontWeight:'400',
    fontFamily: FONTS.PoppinsRegular,
    marginLeft: moderateScale(10),
    marginTop: verticalScale(5),
  },
  AddressViewStyle: {
    backgroundColor: "#EBF0F1",
    padding: 10,
    borderRadius: moderateScale(15),
    marginTop: verticalScale(2),
  },
  AddressTextStyle: {
    color: "#43686A",
    fontSize: moderateScale(14),
    fontFamily: FONTS.PoppinsRegular,
    textAlignVertical: "top",
  },
  roletextStyle: {
    paddingHorizontal: 5,
    color: "#93AFB1",
    marginLeft: moderateScale(5),
  },


  dropdown: {
    height: 70,
    paddingHorizontal: 10,
    borderRadius:25,
    color:'white'
  },
  icon: {
    marginRight: 5,
  },
  label: {
    position: 'absolute',
    backgroundColor: 'white',
    left: 22,
    top: 8,
    zIndex: 999,
    paddingHorizontal: 8,
    fontSize: 14,
  },
  placeholderStyle: {
    fontSize: 16,
  },
  selectedTextStyle: {
    fontSize: 16,
    color:'white'
  },
  iconStyle: {
    width: 20,
    height: 20,
  },
  inputSearchStyle: {
    height: 40,
    fontSize: 16,
  },
  activityIndicator: {
    position: 'absolute',
    left: 0,
    right: 0,
    top: 50,
    bottom: 0,
    alignItems: 'center',
    justifyContent: 'center',
    zIndex: 9999,
  },
});
