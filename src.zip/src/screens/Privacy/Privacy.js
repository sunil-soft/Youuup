// import AsyncStorage from '@react-native-async-storage/async-storage';
import axios from "axios";
import { useEffect, useState } from "react";
import { ActivityIndicator, ImageBackground, StatusBar, View } from "react-native";
import { KeyboardAwareScrollView } from 'react-native-keyboard-aware-scroll-view';

import RenderHtml from 'react-native-render-html';
import { useDispatch, useSelector } from "react-redux";
import { Header } from "../../components/Header";
import { getUser } from "../../selectors/UserSelectors";
// import { FONTS } from "../../theme/fonts";
//import { aboutus } from "../../actions/UserActions";
import { styles } from "./PrivacyStyles";
const tagsStyles = {
  body: {
    whiteSpace: 'normal',
    color: 'white'
  },
  a: {
  //  color: 'green'
  }
};

const Privacy = (props) => {
  const dispatch = useDispatch();
  const { navigation, route } = props;
  const { pageshow } = route.params;

  const [animating, setAnimating] = useState(false);
  const user = useSelector(getUser);
  const [privacydata, setprivacydata] = useState('');
  useEffect(() => {
    axios({
      url: "https://youuup.es/mobile-api/managepages/pages-list",
      method: "GET",
      headers: {
        Accept: "application/json",
       // Authorization: "Bearer " + datatoken,
      },
    })
      .then((response) => {
         //console.log(response.data.result)
       
         var index = response.data.result.findIndex(img => img.page_url == (pageshow == 1?'privacypolicy':'cookiepolicy'));
        
      // console.log()
      setprivacydata(response.data.result[index].page_description)
         
        // if (response.data?.paymentStatus == false) {
        //   navigation.navigate(NAVIGATION.Membership)

        // }
        // setpaymentStatus(response.data?.paymentStatus)


      })
      .catch(function (error) {
        console.log("error", error);
      });
 
}, []);
const sourcehtml = {
  html: "<div><p style='color:white;'>"+privacydata+"</p></div>"

};
  return (
    <ImageBackground
      style={{ flex: 1, }}
      resizeMode={"stretch"}
      backgroundColor={'black'}
      source={require("../../assets/images/editprofileback.png")}
    >

      <StatusBar translucent backgroundColor="transparent" />
      <Header back={true} {...props} title={pageshow == 1 ? 'Política de privacidad' : 'Política de cookies'} />
      <KeyboardAwareScrollView>
        <View style={styles.mainContainer}>
          <View style={{ marginTop: 100, marginLeft: 20, marginRight: 7 }}>
            {pageshow == 1 ?

              // <Text style={{ color: 'white', fontFamily: FONTS.PoppinsRegular, fontSize: 14 }}>
              //   POLÍTICA DE PRIVACIDAD{`\n`}
                // Hasta ahora se venía cumpliendo la LOPD para la privacidad de datos en España, ley que a partir del 25 de Mayo del 2018 queda sustituida por el Reglamento General de Protección de datos (RGPD) de la Unión Europea.
                // La presente Política de Privacidad será válida únicamente para los datos de carácter personal obtenidos en Youuup, no siendo aplicable para aquella información recabada por terceros en otras páginas web/app, incluso si éstas se encuentran enlazadas por el Sitio Web/app
                // Con ello Youuup manifiesta su compromiso por mantener y garantizar las relaciones comerciales con el Usuario particular y/o Creador de contenido de forma segura mediante la protección de sus datos personales y garantizando su derecho a la privacidad.
                // Consideramos como usuario particular aquella persona mayor de 18 años que puede abrir cuenta de perfil y podrá visualizar vídeos e interactuar en ellos y entre otros perfiles, pero no podrá crear ni publicar contenido digital alguno en Youuup app.
                // Consideramos como Creador de contenido aquella persona mayor de 18 años que puede abrir cuenta de perfil y podrá visualizar vídeos e interactuar en ellos y entre otros perfiles, y también podrá crear y publicar contenido digital en Youuup app. Así mismo podrá tratar y contratar directamente las colaboraciones publicitarias y/o divulgativas que les sean solicitadas por otros usuarios particulares y/o usuarios de marca.
                // Consideramos como Usuario de Marca y publicitado,(y tratado como usuario particular) aquella persona, entidad o empresa, cuyo representante legal y de la cuenta de Youuup, sea mayor de 18 años que puede abrir cuenta de perfil y podrá visualizar vídeos e interactuar en ellos y entre otros perfiles, pero no podrá crear ni publicar contenido digital alguno en Youuup app.Asi mismo podrá pedir y contratar colaboraciones de carácter publicitario y/o divulgativo directamente con creadores de contenido dentro de Youuup app.
                // Datos personales que requiere Youuup app:{`\n`}
                // Para poder prestar nuestros servicios necesitamos algunos datos identificativos según el servicio que Sitio Web/app te preste:
                // Nombre: para identificar al Usuario y/o creado de contenido.{`\n`}
                // Email: para conocer el email desde el que se ha hecho el registro.{`\n`}
                // Ubicación: ubicación generalizada y no geolocalizada,para experimentar búsquedas.{`\n`}
                // Si tenemos activado que los Usuarios puedan dejar comentarios:{`\n`}
                // Nombre: para identificar al Usuario y/o creador de contenido.{`\n`}
                // Email: para conocer el email desde el que se ha hecho el comentario.{`\n`}
                // Ubicación: ubicación generalizada y no geolocalizada,para experimentar búsquedas.{`\n`}
                // Nombre y/o Nick: para gestionar el perfil.{`\n`}
                // Para el área privada de clientes:{`\n`}
                // El área de clientes se trata de una zona privada. El responsable de Sitio Web/app te proporcionará un usuario y contraseña para que como Usuario puedas acceder a este servicio restringido, entendiendo que acepta todas las condiciones legales.{`\n`}
                // Para el formulario de contacto:{`\n`}
                // Nombre y/o Nick: para poder responder a la consulta.{`\n`}
                // Email: para poder responder a la consulta{`\n`}
                // Asunto y mensaje de texto para poder concretar la consulta.{`\n`}
                // Para realizar pagos online:{`\n`}
                // En caso de utilizar tarjeta de crédito o débito o una cuenta de PayPal para realizar el pago online de algún servicio o producto, los datos de carácter bancario o financiero del Usuario implicados en el pago siempre son gestionados directamente por los proveedores que se indican en el apartado Servicios ofrecidos por terceros. Sitio Web/app nunca tendrá acceso a los datos bancarios del Usuario ni Creador del contenido.
                // Para realizar pagos vía bizum, Youuup nunca tendrá acceso al número telefónico del usuario ni contenido alguno de dicha línea telefónica, los datos de carácter bancario o financiero del Usuario implicados en el pago siempre son gestionados directamente por los proveedores que se indican en el apartado Servicios ofrecidos por terceros. Sitio Web/app nunca tendrá acceso a los datos bancarios del Usuario.
                // Adicionalmente, cuando visitas nuestro Sitio Web/app determinada información se almacena automáticamente por motivos técnicos como la dirección IP asignada por tu proveedor de acceso a Internet.
                // Legitimación{`\n`}
                // Gracias al consentimiento podemos tratar tus datos, siendo este un requisito obligatorio para que puedas acceder de forma correcta a los servicios de Sitio Web/app.
                // El usuario y creador de contenido disponen de su derecho al olvido cuando quiera que todos sus datos sean eliminados de nuestras base de datos.
                // Utilizando el apartado de eliminar perfil o vía email.{`\n`}
                // Categoría de los datos{`\n`}
                // Los datos que recopila Sitio Web/app no son considerados datos sensibles o protegidos.
                // Según el artículo 9.1 del nuevo reglamento general de protección de datos de la unión europea (RGPD) se consideran datos sensibles o protegidos los datos personales que revelen:
                // El origen étnico o racial.{`\n`}
                // Las opiniones políticas.{`\n`}
                // Las convicciones religiosas o filosóficas.{`\n`}
                // La afiliación sindical.{`\n`}
                // El tratamiento de datos genéticos.{`\n`}
                // Datos biométricos dirigidos a identificar de manera unívoca a una persona física.{`\n`}
                // Datos relativos a la salud.{`\n`}
                // Datos relativos a la vida sexual o las orientación sexuales de una persona física.{`\n`}
                // Sólo trabajamos con los datos mínimos identificativos para llevar a cabo nuestra labor: nombre, pais, email, tipo de perfil como usuario particular o creador de contenido.{`\n`}
                // Tiempo de conservación de los datos{`\n`}
                // Los datos del cliente: nombre, ubicación, correo electrónico, etc. permanecerán en nuestro sistema lo que legalmente y técnicamente se requiera para la operativa normal del Sitio Web/app, a menos que el Usuario ejerza su derecho a su eliminación o actualización.{`\n`}
                // Normativa de aplicación{`\n`}
                // Desde el el 25 de mayo de 2018, Sitio Web/app se rige por el Reglamento General sobre Protección de Datos (RGPD) de la Unión Europea.{`\n`}
                // <Text onPress={() => Linking.openURL('https://www.boe.es/doue/2016/119/L00001-00088.pdf')}>https://www.boe.es/doue/2016/119/L00001-00088.pdf{`\n`} </Text>
                // Medidas de seguridad{`\n`}
                // Sitio Web/app está alojado en los sistemas operados por Bobili-Bobili Solutions SL., en adelante Youuup app, están implantadas las medidas de seguridad técnicas y organizativas necesarias para garantizar la seguridad de los datos de carácter personal del Usuario del Creador de contenido y evitar así su alteración, pérdida y tratamiento y/o acceso no autorizado. Esto habida cuenta del estado de la tecnología, la naturaleza de los datos almacenados y los riesgos a que están expuestos, ya provengan de la acción humana o del medio físico o natural. Todo ello de conformidad con lo previsto en el RGPD.{`\n`}
                // Asimismo, Youuup ha establecido medidas adicionales en orden a reforzar la confidencialidad e integridad de la información en este Sitio Web/app. Manteniendo continuamente la supervisión, control y evaluación de los procesos para asegurar el respeto a la privacidad de los datos.Pudiendo ser contratados por sitio Web app servicios de protección, alojamientos, dominios etc a terceros de manera segura y bajo relación contractual.{`\n`}
                // Concretamente, las medidas que adopta Youuup app son:{`\n`}
                // Conexión con certificado SSL en el Sitio Web/app.{`\n`}
                // Encriptación de las claves y contraseñas utilizando algoritmos criptográficos estándar.{`\n`}
                // Protección de los servidores mediante cortafuegos, aislamiento de procesos, y otras medidas de seguridad estándar.{`\n`}
                // Copias de seguridad diarias distribuidas geográficamente para garantizar la continuidad del servicio en caso de incidente.{`\n`}
                // Ejercicios de derechos{`\n`}
                // Aquel Usuario y/o Creador de contenido que haya facilitado sus datos a Sitio Web/app, podrá dirigirse al titular de la web/app con el fin de poder ejercitar gratuitamente su derecho de acceso a sus datos, rectificación o supresión, limitación y oposición respecto de los datos incorporados en sus ficheros.{`\n`}
                // El método que debe utilizar el Usuario y/o Creador de contenido para comunicarse con Sitio Web/app será mediante su cuenta de email registrada en nuestro servicio web/app, o por escrito.{`\n`}
                // El Usuario podrá ejercitar sus derechos mediante comunicación por escrito dirigida a Bobili-Bobili Solutions S.L., con la referencia “Protección de datos”,en apartado de contacto, especificando sus datos, acreditando su identidad y los motivos de su solicitud en la siguiente dirección:{`\n`}
                // <Text onPress={() => Linking.openURL('mailto:Info@youuup.com')}>Info@youuup.com{`\n`}</Text>
                // Cualquier información que necesitemos almacenar en virtud de una obligación legal, fiscal o contractual, será bloqueada y sólo utilizada para dichos fines en lugar de ser borrada.{`\n`}
                // Modificación de la política de privacidad{`\n`}
                // Youuup app se reserva el derecho de modificar la Política de Privacidad, motivado por un cambio legislativo, jurisprudencial o doctrinal de la Agencia Española de Protección de Datos.{`\n`}
                // Cualquier modificación de la Política de Privacidad será publicada al menos diez días antes de su efectiva aplicación.{`\n`}
                // El responsable del fichero de datos es el titular de Sitio Web/app.{`\n`}
                // Servicios ofrecidos por terceros:{`\n`}
                // Para prestar servicios estrictamente necesarios para su adecuado funcionamiento Sitio Web/app utiliza prestadores de servicios bajo sus correspondientes condiciones de privacidad.{`\n`}
                // Para servicios de llamadas en Youuup no se necesita ofrecer número de teléfono.{`\n`}
                // El Usuario particular y/o Creador de contenido pueden hacer servir su derecho a eliminación de cuenta en Youuup app de inmediato, utilizando la sección de " eliminar cuenta " que encontrará en en el aparato de Menú de ajustes.{`\n`}
                // Bobili-Bobili Solutions S.L es la propietaria de Youuup app y Youuup es una marca de Bobili-Bobili Solutions S.L y como tal están reservados todos los derechos de propiedad intelectual, comercial, de explotación y consumo. Mediante Copyright © y creative commons ©©
                // En Youuup app esta reservado el derecho de admisión para cualquier usuario particular y/o creador de contenido. Pudiendo ejercer Youuup el derecho de eliminación directa e inminente de la cuenta sin previo aviso (pudiendo pedir explicaciones de lo acontecido vía email a <Text onPress={() => Linking.openURL('mailto:Info@youuup.com')}>Info@youuup.com</Text>) a cualquier usuario particular y/o creador de contenido.{`\n`}

              // </Text>
              <RenderHtml
              // contentWidth={500}
              customHTMLElementModels
               source={sourcehtml}
               tagsStyles={tagsStyles}
             />  
              :
              // <Text style={{ color: 'white', fontFamily: FONTS.PoppinsRegular, fontSize: 14 }}>
              //   Política de cookies{`\n`}

                // Política de cookies (Web y app){`\n`}
                // a) Youuup utiliza Cookies, y otros mecanismos similares (en adelante, Cookies). Las Cookies son ficheros enviados a un navegador o dispositivo por medio de un servidor web app cuya finalidad es la de facilitar al Usuario un acceso más rápido a los servicios ofrecidos por Youuup app, garantizando el correcto y funcionamiento de los mismos.{`\n`}
                // Las APLICACIONES utilizan Cookies para personalizar y facilitar al máximo la navegación del Usuario por cada una de las funcionalidades ofrecidas. Las Cookies utilizadas por las APLICACIONES se asocian a un Usuario anónimo o a una cuenta de Usuario, en caso de que el Usuario esté registrado en los Servicios ofrecidos. El Usuario podría configurar su navegador para que notifique y rechace la instalación de las Cookies enviadas por las APLICACIONES, pero deshabilitar las Cookies en su navegador puede provocar que las funcionalidades y Servicios ofrecidos por las APLICACIONES se encuentren limitados y la calidad de funcionamiento pueda disminuir hasta el punto de impedir su uso. Las cookies utilizadas cuando accede a las APLICACIONES mediante las aplicaciones nativas (Android o IOS) puestas a disposición en los markets Google Play y Apple Store, son necesariamente aceptadas por el Usuario en el momento de su descarga e instalación.{`\n`}
                // b) Tipología, finalidad y funcionamiento de las Cookies{`\n`}
                // En función de quién gestiona el equipo o dominio desde las que se envían, las Cookies pueden dividirse en Cookies propias (gestionados por Youuup app) o Cookies de terceros (gestionados por terceras entidades que tratan los datos obtenidos a través de éstas). Salvo las Cookies analíticas y las Cookies de registro de redes sociales, el resto de Cookies utilizadas a las que se refiere la presente Política son Cookies propias.{`\n`}
                // COOKIES PROPIAS{`\n`}
                // Cookies de personalización: este tipo de Cookie recuerda sus preferencias, para las herramientas que se encuentran en los Servicios, por lo que no tiene que volver a configurar el Servicio cada vez que usted accede a las APLICACIONES. Estas cookies se utilizan mientras existe una sesión iniciada en las APLICACIONES o se utiliza una funcionalidad en particular. Este tipo de cookies tiene las siguientes finalidades:{`\n`}
                // Identificación del idioma del navegador para mostrar los contenidos en el lenguaje correcto;{`\n`}
                // Ajustes de volumen de emisión de sonidos;{`\n`}
                // Tipo y tamaño de fuente utilizada en las APLICACIONES;{`\n`}
                // Almacenamiento de los canales favoritos del Usuario;{`\n`}
                // Identificación de la versión del servicio que permite controlar las actualizaciones necesarias de las diferentes funcionalidades.{`\n`}
                // Este tipo de cookies se puede suprimir si el Usuario pulsa sobre la opción “cerrar sesión”. Si se suprime este tipo de cookies, el Servicio podría dejar de funcionar de forma óptima.{`\n`}
                // Cookies de registro: las Cookies de registro se generan una vez que el Usuario se ha registrado o posteriormente ha abierto su sesión. Estas cookies se utilizan mientras existe una sesión iniciada en las APLICACIONES y se utilizan para identificar al Usuario en los Servicios con las siguientes finalidades:{`\n`}
                // Mantener al Usuario identificado de forma que, si cierra un Servicio, el navegador o el dispositivo, la próxima vez que vuelva a entrar en dicho Servicio, seguirá identificado, facilitando así su navegación.{`\n`}
                // Comprobar si el Usuario está autorizado para acceder a ciertos Servicios, por ejemplo, para acceder a un canal o conjunto de canales y participar de una conversación con un colectivo.{`\n`}
                // Este tipo de cookies se puede suprimir si el Usuario pulsa sobre la opción “cerrar sesión” desde los ajustes de las APLICACIONES. Una vez suprimida, cuando el Usuario acceda nuevamente al Servicio tendrá que iniciar sesión nuevamente.{`\n`}
                // COOKIES DE TERCEROS{`\n`}
                // Cookies de registro de Youuup : cuando el Usuario se registra en un Servicio con credenciales de Youuup, autoriza a ésta a guardar una Cookie persistente que recuerda su identidad y le garantiza acceso a los Servicios hasta que expira. El Usuario puede borrar esta Cookie y revocar el acceso a los Servicios mediante Youuup actualizando sus preferencias en dicha plataforma , pero esto puede conllevar la perdida de acceso al Servicio o conjunto de Servicios relacionados ofrecidos por la Aplicación.{`\n`}
                // Cookies de análisis: son aquellas que nos permiten cuantificar el número de usuarios y así realizar la medición y análisis estadístico de la utilización que hacen los Usuarios de las APLICACIONES. Para ello se analiza su uso de las APLICACIONES con el fin de introducir mejoras en su funcionamiento y/o mejorar la oferta de productos o servicios. El origen de estas cookies es Google.{`\n`}
                // Cada vez que un Usuario accede a las APLICACIONES, una herramienta de un proveedor externo (Google) genera Cookies analíticas en el dispositivo del Usuario. Estas Cookies que sólo se generan cuando el Usuario realiza una acción, tienen carácter permanente y servirán en próximos accesos a las APLICACIONES para identificar de forma anónima al visitante. Téngase en cuenta que las cookies permanentes expiran cuando se cumple el objetivo para el que sirven o bien cuando se borran manualmente.{`\n`}
                // En particular, las Cookies analíticas utilizadas en las APLICACIONES son:{`\n`}
                // TIPO NOMBRE DESCRIPCIÓN FINALIDADES MÁS INFORMACIÓN{`\n`}
                // Cookies de análisis (Google Analytics) __utma se usa para distinguir usuarios y sesiones. La cookie se crea cuando se ejecuta la biblioteca JavaScript y no hay ninguna cookie __utma. La cookie se actualiza cada vez que se envían datos a Google Analytics{`\n`}
                // · Permitir la identificación anónima de los Usuarios navegantes a través de la “Cookie” (identifica navegadores y dispositivos, no personas) y por lo tanto la contabilización aproximada del número de visitantes y su tendencia en el tiempo.{`\n`}
                // · Identificar de forma anónima los contenidos más visitados y por lo tanto más atractivos para los Usuarios{`\n`}
                // · Saber si el Usuario que está accediendo es nuevo o repite visita.{`\n`}

                // __utmz Almacena la fuente de tráfico o la campaña que explica cómo ha llegado el usuario al sitio. La cookie se crea cuando se ejecuta la biblioteca JavaScript y se actualiza cada vez que se envían datos a Google Analytics.{`\n`}
                // <Text onPress={() => Linking.openURL('https://developers.google.com/analytics/devguides/collection/analyticsjs/cookie-usage?hl=es')}>https://developers.google.com/analytics/devguides/collection/analyticsjs/cookie-usage?hl=es{`\n`}</Text>
                // __ga Se usa para distinguir a los usuarios.
                // Estas cookies se pueden suprimir; las APLICACIONES seguirán funcionando de forma óptima y los Servicios no se verán afectados.{`\n`}
                // Más información sobre la política de privacidad de Google Analytics en  <Text onPress={() => Linking.openURL('http://www.google.com/intl/es/policies/')}>http://www.google.com/intl/es/policies/{`\n`}</Text>
                // c) Cómo deshabilitar las Cookies en los principales navegadores
                // El usuario podrá -en cualquier momento- elegir qué cookies quiere que funcionen en las APLICACIONES si accede a ellas a través de un navegador accediendo al panel de configuración de su navegador:{`\n`}
                // Internet Explorer: Herramientas {'->'} Opciones de Internet {'->'} Privacidad {'->'} Configuración.{`\n`}
                // Para más información, puede consultar el soporte de Microsoft o la Ayuda del navegador.{`\n`}
                // Firefox: Herramientas {'->'} Opciones {'->'} Privacidad {'->'} Historial {'->'} Configuración Personalizada.{`\n`}
                // Para más información, puede consultar el soporte de Mozilla o la Ayuda del navegador.{`\n`}
                // Chrome: Configuración {'->'} Mostrar opciones avanzadas {'->'} Privacidad {'->'} Configuración de contenido.{`\n`}
                // Para más información, puede consultar el soporte de Google o la Ayuda del navegador.{`\n`}
                // Safari: Preferencias {'->'} Seguridad.
                // Para más información, puede consultar el soporte de Apple o la Ayuda del navegador.{`\n`}
                // Para inhabilitar las cookies de análisis de Google Analytics para navegadores visite el siguiente enlace: <Text onPress={() => Linking.openURL('https://support.google.com/analytics/answer/181881?hl=es')}>https://support.google.com/analytics/answer/181881?hl=es{`\n`}</Text>

              // </Text>

              <RenderHtml
              // contentWidth={500}
              customHTMLElementModels
               source={sourcehtml}
               tagsStyles={tagsStyles}
             />  
            }

          </View>
        </View>
        {animating == true && (
          <ActivityIndicator
            animating
            color={'white'}
            size="large"
            style={styles.activityIndicator}
          />
        )}
      </KeyboardAwareScrollView>
    </ImageBackground>
  );
};

export default Privacy;
