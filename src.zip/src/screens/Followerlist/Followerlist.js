import { FONTS } from "@/theme/fonts";
import { useEffect, useState } from "react";
import { ActivityIndicator, FlatList, Image, ImageBackground, StatusBar, Text, View } from "react-native";
import { TouchableOpacity } from "react-native-gesture-handler";
import { KeyboardAwareScrollView } from 'react-native-keyboard-aware-scroll-view';

import AsyncStorage from '@react-native-async-storage/async-storage';
import axios from "axios";
import { useDispatch, useSelector } from "react-redux";
import { followerlistapi } from "../../actions/UserActions";
import { Header } from "../../components/Header";
import { InputField } from "../../components/InputField";
import { NAVIGATION } from "../../constants";
import { getUser } from "../../selectors/UserSelectors";
import { styles } from "./Followerliststyles";
const APIBASEURL='https://youuup.es/mobile-api/'

  const Followerlist = (props) => {
  const dispatch = useDispatch();
  const { navigation, route } = props;
  const user = useSelector(getUser);
  const { usernameshow,creater_id,tabactivestatus } = route.params;

  const [animating, setAnimating] = useState(false);
  const [activetab, setactivetab] = useState(tabactivestatus==1?2:1);
  //const [activestatus, setactivestatus] = useState(2);


  // useFocusEffect(
  //   React.useCallback(() => {
  //     const unsubscribe = followerlist(tabactivestatus);
     
  //     return () => unsubscribe;
  //   }, [])
  // );
  const addfollow = (follow_to_id,status) => {
    
    console.log({"follow_to_id":follow_to_id,"follow_status":status==true?2:1})
    AsyncStorage.getItem('auth_token').then(async (datatoken) => { 
      console.log(datatoken)
    axios({
      url: APIBASEURL+"user/follow",
      method: "POST",
      data: {"follow_to_id":follow_to_id,"follow_status":status==true?2:1},
      headers: {
        Accept: "application/json",
        Authorization:"Bearer "+datatoken,
      },
    })
    .then((response) => {
      console.log(response)
      followerlist(2)
     })
    .catch(function (error) {
      console.log("1error", error);
    });
   });
    };

  const followerlist = (activestatus) => {
    const data2 = {
      "user_id": creater_id,
      "follow_status":activestatus
  };
  console.log(data2)
    dispatch(followerlistapi(data2));
  };

  const showfollowers = () => {
   setactivetab(1)
   //setactivestatus(2)
   followerlist(2)
   };
   const showfollowing = () => {
    setactivetab(2)
  //  setactivestatus(1)
    followerlist(1)
    };



   useEffect(() => {
  console.log('fgf',user && user.followerslist)
   followerlist(tabactivestatus)
    }, []);

  return (
    <ImageBackground
      style={{ flex: 1,  }}
      backgroundColor={'black'}
      resizeMode={"stretch"}
     // source={require("../../assets/images/editprofileback.png")}
      source={require("../../assets/splash/bg.png")}
    >
      <StatusBar translucent backgroundColor="transparent" />
      <Header back={true} {...props} title={usernameshow} />
      {/* {showModal && <PopUp />} */}
  <KeyboardAwareScrollView>
  <View style={styles.mainContainer}>
    <View style={{marginTop:80,justifyContent:"space-around",flexDirection:"row"}}>
       <TouchableOpacity onPress={()=>showfollowers()} style={{backgroundColor:activetab==1?'#08DDFD':'transparent',padding:5,paddingLeft:20,paddingRight:20, borderRadius:15.5,
       }}>
         <Text style={{fontFamily:FONTS.PoppinsMedium,color:activetab==1?'#000000':'#FFFFFF',fontSize:14}}>Seguidores</Text>
       </TouchableOpacity>
       <View style={{backgroundColor:'rgba(255, 255, 255, 1)',width:0.5,height:30,alignSelf:"center"}}>

       </View>
       <TouchableOpacity onPress={()=>showfollowing()} style={{backgroundColor:activetab==2?'#08DDFD':'transparent',padding:8,paddingLeft:20,paddingRight:20, borderRadius:15.5}}>
         <Text style={{fontFamily:FONTS.PoppinsMedium,color:activetab==2?'#000000':'#FFFFFF',fontSize:14}}>Siguiendo</Text>
       </TouchableOpacity>
      </View>

      <View style={{backgroundColor:"#2A2A2A",height:0.5,marginTop:15,width:'90%',justifyContent:'center',alignSelf:'center'}}></View>
       
       <View style={{flexDirection:'row',alignItems:"center",marginTop:5,width:'90%',marginRight:50,marginRight:20}}>
          <View 
           // onPress={()=> {setisActiveviewstatus(1), setsecureText(!secureText)}} 
            style={{position:'relative', zIndex:9999999999,left:40,padding:4}} >
           <Image source={require("../../assets/Home/New/searchicon.png")} />
          </View>  
        <InputField
          placeholderColor={"white"}
          placeholder={""}
          mainViewStyle={{ width: "100%",height:40,paddingLeft:25}}
        />
      </View>
       
      <FlatList
        data={user && user.followerslist}
         renderItem={({item}) => 
      <View style={{marginTop:10, flexDirection:"row",marginLeft:15,marginRight:15, alignContent:'center',alignItems:'center'}}>
      <View style={{width:'20%'}}>
      <Image style={{width:56,height:56,borderRadius:50}} source={{uri:item.profile_photo}} />
      </View>
      <View style={{width:'43%'}}>
      <TouchableOpacity onPress={()=>navigation.navigate(NAVIGATION.Followerdetail,{creater_id:item.id,user_type_id:item.user_type_id})} >
          <Text style={{color:'#08DDFD',fontSize:14,fontWeight:"600",fontFamily:FONTS.PoppinsMedium}}>
          {item.name}
          </Text>
          <Text style={{color:'#FFFFFF',fontSize:12,fontWeight:"600",fontFamily:FONTS.PoppinsMedium}}>
          {item.bio}
          </Text>
      </TouchableOpacity>
      </View>
      <View style={{ width:'35%',justifyContent:"center",alignItems:'center',alignContent:'center'}}>
      <TouchableOpacity 
      onPress={()=>addfollow(item.id,item.follow_by_logged_user)}

      style={{width:120, backgroundColor:item.follow_by_logged_user==false?"#08DDFD":'transparent',padding:8,paddingLeft:10,paddingRight:10, borderWidth:1,borderColor:'#08DDFD', borderRadius:20,justifyContent:'center',alignContent:"center",alignItems:'center'}}>
       <Text style={{color:item.follow_by_logged_user==false?"#000000":'#08DDFD',fontSize:14,fontFamily:FONTS.PoppinsMedium}}>{item.follow_by_logged_user==true?"Siguiendo":"Seguir"}</Text>
       </TouchableOpacity>
      </View>
     </View>
        }
      />   
  </View>
          {animating == true && (
           <ActivityIndicator
            animating
           color={'black'}
           size="large"
           style={styles.activityIndicator}
           />
           )} 
           </KeyboardAwareScrollView>
   </ImageBackground>
  );
};

export default Followerlist;
