import { Apiurl } from "@/constants/Apiurl";
import { FONTS } from "@/theme/fonts";
import AsyncStorage from '@react-native-async-storage/async-storage';
import { useFocusEffect } from "@react-navigation/native";
import axios from "axios";
import React, { useEffect, useState } from 'react';
import { ActivityIndicator, FlatList, Image, ImageBackground, StatusBar, Text, View } from "react-native";
import { TouchableOpacity } from "react-native-gesture-handler";
import { KeyboardAwareScrollView } from 'react-native-keyboard-aware-scroll-view';
import { useDispatch, useSelector } from "react-redux";
import { blocklistapi } from "../../actions/UserActions";
import { Header } from "../../components/Header";
import { NAVIGATION } from "../../constants";
import { getUser } from "../../selectors/UserSelectors";
import { styles } from "./Liveuserliststyles";
//const APIBASEURL='http://103.15.67.180:4006/'
  const Liveuserlist = (props) => {
  const dispatch = useDispatch();
  const { navigation, route } = props;
  const user = useSelector(getUser);
  const [serachtext, setserachtext] = useState('');
  const [userlist, setuserlist] = useState([]);
  const [animating, setAnimating] = useState(false);
  useFocusEffect(
    React.useCallback(() => {
      liveuserlist()

    }, [])
  );
  

  const blocklist = () => {
    dispatch(blocklistapi());
  };
   useEffect(() => {
     liveuserlist()
    }, []);
   
    const liveuserlist = () => {
    // console.log({"follow_to_id":follow_to_id,"follow_status":status==true?2:1})
     AsyncStorage.getItem('auth_token').then(async (datatoken) => { 
     axios({
       url: Apiurl+"user/live-users",
       method: "GET",
      // data: {"search":text},
       headers: {
         Accept: "application/json",
         Authorization:"Bearer "+datatoken,
       },
     })
     .then((response) => {
       console.log('response3223', response.data.liveUsers)
       setuserlist(response.data?.liveUsers)
      // blocklist()
      })
     .catch(function (error) {
       console.log("error11", error);
     });
      });
     };

  return (
    <ImageBackground
      style={{ flex: 1,}}
     // resizeMode={"stretch"}
     // source={require("../../assets/images/editprofileback.png")}
      source={require("../../assets/splash/bg.png")}
    >
      <StatusBar translucent backgroundColor="transparent" />
      <Header back={true} {...props} title={'Live users'}  />
      {/* {showModal && <PopUp />} */}
  <KeyboardAwareScrollView>
  <View style={styles.mainContainer}>
 
       {userlist?.length>0 ?
      <FlatList
        data={userlist}
         renderItem={({item}) => 
    <TouchableOpacity onPress={()=>navigation.navigate(NAVIGATION.LivevideoNew,{chanelname:item.channelName,token:item.token})}  style={{marginTop:10,marginLeft:20, flexDirection:"row",marginRight:15, alignContent:'center',alignItems:'flex-start',justifyContent:"flex-start"}}>
      <View style={{width:'20%'}}>
      {/* <Image style={{width:56,height:56,borderRadius:50}} source={{uri:item.profile_photo}} /> */}
       {item?.profile_photo?
          <Image style={{width: 60, height: 60,borderRadius:50,borderColor:'#08DDFD',borderWidth:2 }} 
           source={{uri:Apiurl+item.profile_photo}}
             />
             :
             <Image style={{width: 70, height: 71,borderRadius:50 ,borderColor:'#08DDFD',borderWidth:2}} 
             source={require("../../assets/images/defaultuser.png")}
             />
          } 
           <Image style={{position:"relative",marginLeft:7,bottom:10,left:2 ,width:40.23,height:25.91}} 
             source={require("../../assets/Home/New/liveicon.png")}
             /> 
      </View>
      <View style={{width:'45%',paddingTop:10,paddingLeft:10}}>
      <TouchableOpacity>
        <Text style={{color:'#08DDFD',fontSize:14,fontWeight:"600",fontFamily:FONTS.PoppinsMedium}}>{item.name}</Text>
        <Text style={{color:'white',fontSize:12,fontWeight:"600",fontFamily:FONTS.PoppinsRegular}}>{item.bio}</Text>
      </TouchableOpacity>
      </View>
      {/* <View style={{width:'35%',justifyContent:"center",alignItems:'center',alignContent:'center'}}>
      <TouchableOpacity 
      onPress={()=>addblock(item.id,2)}

      style={{width:120, backgroundColor:"#08DDFD",padding:8,paddingLeft:10,paddingRight:10, borderWidth:1,borderColor:'#08DDFD', borderRadius:20,justifyContent:'center',alignContent:"center",alignItems:'center'}}>
       <Text style={{color:"#000000",fontSize:14,fontFamily:FONTS.PoppinsMedium}}>Desatascar</Text>
       </TouchableOpacity>
      </View> */}
     </TouchableOpacity>
        }
        keyExtractor={item => item.id}
      /> 
      :
      <View style={{justifyContent:"center",alignContent:'center',alignItems:'center',marginTop:150}}>
      <Text style={{color:'white'}}>
        No hay resultados
       </Text>
       </View>
     }  
  </View>
          {animating == true && (
           <ActivityIndicator
            animating
           color={'black'}
           size="large"
           style={styles.activityIndicator}
           />
           )} 
           </KeyboardAwareScrollView>
   </ImageBackground>
  );
};

export default Liveuserlist;
