import axios from "axios";
import { useEffect, useState } from "react";
import { ActivityIndicator, ImageBackground, StatusBar, View } from "react-native";
import { KeyboardAwareScrollView } from 'react-native-keyboard-aware-scroll-view';
import RenderHtml from 'react-native-render-html';
import { Header } from "../../components/Header";
import { styles } from "./SocialinfoStyles";
const tagsStyles = {
  body: {
    whiteSpace: 'normal',
    color: 'white'
  },
  a: {
  //  color: 'green'
  }
};
const Socialinfo = (props) => {
  const [animating, setAnimating] = useState(false);
  const [socialdata, setsocialdata] = useState('');
  useEffect(() => {
    axios({
      url: "https://youuup.es/mobile-api/managepages/pages-list",
      method: "GET",
      headers: {
        Accept: "application/json",
       // Authorization: "Bearer " + datatoken,
      },
    })
      .then((response) => {
         console.log(response.data.result)
         var index = response.data.result.findIndex(img => img.page_url == 'socialandtaxinformation');
     
       setsocialdata(response.data.result[index].page_description)
         
        // if (response.data?.paymentStatus == false) {
        //   navigation.navigate(NAVIGATION.Membership)

        // }
        // setpaymentStatus(response.data?.paymentStatus)


      })
      .catch(function (error) {
        console.log("error", error);
      });
 
}, []);
const sourcehtml = {
  html: "<div><p style='color:white;'>"+socialdata+"</p></div>"

};
  return (
    <ImageBackground
      style={{ flex: 1, }}
      resizeMode={"stretch"}
      source={require("../../assets/images/editprofileback.png")}
    >
      <StatusBar translucent backgroundColor="transparent" />
      <Header back={true} {...props} title='Información Social y Fiscal' />
      <KeyboardAwareScrollView>
        <View style={styles.mainContainer}>
          <View style={{ marginTop: 100, marginLeft: 20, marginRight: 7 }}>
            {/* <Text style={{ color: 'white', fontFamily: FONTS.PoppinsRegular, fontSize: 14 }}>
              Información Social{`\n`}
              Info Social, Fiscal y Jurídica{`\n`}
              Bobili-Bobili Solutions SL{`\n`}
              NIF: B-16.759.771{`\n`}
              Avenida de cabrera N° 36{`\n`}
              Planta baja{`\n`}
              Business Center{`\n`}
              08302 Mataró{`\n`}
              Barcelona - España{`\n`}
              Teléfono y WhatsApp de contacto:{`\n`}
              +34 644 023 000{`\n`}
              R.M de Barcelona{`\n`}
              Tomo:47965 Folio:210 Hoja:567732 Inscripción: 1{`\n`}
              Web: <Text onPress={() => Linking.openURL('https://www.bobili-bobili-solutions.com/')}>www.bobili-bobili-solutions.com{`\n`}</Text>
              Email: <Text onPress={() => Linking.openURL('mailto:Info@bobili-bobili-solutions.com')}>Info@bobili-bobili-solutions.com{`\n`}</Text>
              Derecho cancelación, devolución y reembolso antes de 14 días hábiles en:{`\n`}
              <Text onPress={() => Linking.openURL('mailto:Info@bobili-bobili-solutions.com')}>Info@bobili-bobili-solutions.com{`\n`}</Text>
              Cancelación, modificación, eliminación de privacidad de datos en:{`\n`}
              <Text onPress={() => Linking.openURL('mailto:Info@bobili-bobili-solutions.com')}>Info@bobili-bobili-solutions.com{`\n`}</Text>
              Incluido en el pago de membresía por el uso de los servicios web/app, el 21 % de impuestos sobre el valor añadido (IVA).{`\n`}
              Lea y entienda que aceptando el pago de membresía usted está de acuerdo con las condiciones de uso del sitio web/app y la política de privacidad y que ha leído y entendido las condiciones.{`\n`}
              Pasarela de pago y protección membresía Redsys y Apple Pay y Google pay{`\n`}

            </Text> */}
            <RenderHtml
     // contentWidth={500}
     customHTMLElementModels
      source={sourcehtml}
      tagsStyles={tagsStyles}
    />  
          </View>
        </View>
        {animating == true && (
          <ActivityIndicator
            animating
            color={'white'}
            size="large"
            style={styles.activityIndicator}
          />
        )}
      </KeyboardAwareScrollView>
    </ImageBackground>
  );
};

export default Socialinfo;
