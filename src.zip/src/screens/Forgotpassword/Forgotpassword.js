import { useState } from "react";
import {
  Image, ImageBackground,
  StatusBar, Text, View
} from "react-native";

import { geterror, getUser } from "@/selectors/UserSelectors";
import { showMessage } from "react-native-flash-message";
import { KeyboardAwareScrollView } from 'react-native-keyboard-aware-scroll-view';
import { useDispatch, useSelector } from "react-redux";
import { forgotpasswordsave } from "../../actions/UserActions";
import { Button } from "../../components/Button";
import { Header } from "../../components/Header";
import { InputField } from "../../components/InputField";
import { verticalScale } from "../../helper/Scale";
import { TextStyles } from "../../theme/TextStyles";
import { styles } from "./Forgotpassword.styles";

export function Forgotpassword(props) {
  const { navigation, route } = props;
  const dispatch = useDispatch();
  const [email, setEmail] = useState("");
  const user = useSelector(getUser);
  const error = useSelector(geterror);
  const [showModal, setShowModal] = useState(true);
  
  const [secureText, setsecureText] = useState(true);
  const [isActiveviewstatus, setisActiveviewstatus] = useState(2);
  const [password, setpassword] = useState('');

  
  const [radioButtonActive, SetRadioButtonActive] = useState(
  true
  );
  var validRegex =
  /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9-]+(?:\.[a-zA-Z0-9-]+)*$/;

  const Validation = () => {
    if (!email.trim()) {
      showMessage({
        message: "El campo de correo electrónico es obligatorio",
        type: "danger",
      });
    } else if (!email.match(validRegex)) {
      showMessage({
        message: "Por favor ingrese una dirección de correo electrónico válida",
        type: "danger",
      });
    }
      else {
     forgotpassword();
      //setShowModal(true);
     // props.navigation.navigate("ResetPassword");
    }
  };
  const forgotpassword = async () => {
    const data = {
      email: email,
    };
    console.log(data)
    dispatch(forgotpasswordsave(data));
    
  };

  return (
    <ImageBackground
      style={{ flex: 1,  }}
      resizeMode={"stretch"}
      backgroundColor={'black'}
      source={require("../../assets/splash/bg.png")}
    >
      <StatusBar translucent backgroundColor="transparent" />
      <Header back={true} {...props} />
      <KeyboardAwareScrollView>
      <View style={{ marginTop: verticalScale(30), alignSelf: "center" }}>
        <Image resizeMode="center" source={require("../../assets/splash/Logo.png")} />
      </View>
      <View style={styles.loginContainer}>
        {/* <Text style={TextStyles.title}>Keep it Real</Text> */}
        <Image resizeMode="center" style={{marginTop:70}} source={require("../../assets/images/emailimage.png")} />

       
        <Text style={TextStyles.titlelogin}>¿Has olvidado tu contraseña? </Text>
        <Text style={TextStyles.subtitle}>Crea una nueva contraseña. </Text>
        <Text style={TextStyles.titlereg}>
        Dirección de correo electrónico registrado
         </Text> 
        <InputField
          placeholderColor={"white"}
          //right={true}
          uri={require("../../assets/login/closeeye.png")}
          urii={require("../../assets/login/openeye.png")}
          placeholder={""}
          mainViewStyle={{ width: "90%" }}
          //title={"Email Address"}
         // onChangeText={(text) => setEmail(text)}
         value={email}
          onChangeText={(text) => setEmail(text.replace(/\s/g, ''))}

          // onFocus={() => {
          //   setisActiveviewstatus(2)
          // }}
          //defaultValue={"toprady876@gmail.com"}
         // icon={"email"}
          // color={"#05A1AB"}
        />
        
         
      
        {/* <TouchableOpacity  onPress={() => navigation.navigate(NAVIGATION.forgotpassword)} style={{marginTop:15,alignItems:"flex-start",marginRight:'40%'}}> 
          <Text style={TextStyles.forgotlabel}>*Olvidé mi contraseña </Text>
       </TouchableOpacity>  */}
       <View style={{flexDirection:'row',justifyContent:'center',alignContent:'center',alignItems:'center',margin:5,width:'72%'}}>

        </View>
        <Button
          style={{ marginTop: verticalScale(10) }}
          onPress={Validation}
         // onPress={() => navigate(NAVIGATION.otp)}
          title={"Continuar"}
        />
       
      </View>
      </KeyboardAwareScrollView>
    </ImageBackground>
  );
}
export default Forgotpassword;