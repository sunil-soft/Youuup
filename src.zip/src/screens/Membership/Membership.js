import {
  PlatformPay,
  PlatformPayButton,
  createPlatformPayPaymentMethod,
  initStripe,
  usePlatformPay,
  useStripe
} from '@stripe/stripe-react-native';
import { useEffect, useState } from 'react';
import { ActivityIndicator, Alert, Image, ImageBackground, StatusBar, Text, View } from "react-native";
//import { GooglePay } from 'react-native-google-pay';
import { Apiurl } from "@/constants/Apiurl";
import AsyncStorage from '@react-native-async-storage/async-storage';
import axios from "axios";
import { useDispatch } from "react-redux";
import { logout } from "../../actions/UserActions";
import { Header } from "../../components/Header";
import { FONTS } from "../../theme/fonts";
import { styles } from "./MembershipStyles";
const allowedCardNetworks = ['VISA', 'MASTERCARD'];
const allowedCardAuthMethods = ['PAN_ONLY', 'CRYPTOGRAM_3DS'];


const directRequestData = {
  cardPaymentMethod: {
    tokenizationSpecification: {
      type: 'DIRECT',
      publicKey: 'sk_test_51MvF3ESAf6yfFaxSeQRLu08IQP1xfX8tCzQYhsXszrC3GBcbxh5S6L0MqGcQzDAfdFSsV8kQmfOLPCxZNYxIFd1A00MkRu4swj',
    },
    allowedCardNetworks,
    allowedCardAuthMethods,
  },
  transaction: {
    totalPrice: '123',
    totalPriceStatus: 'FINAL',
    currencyCode: 'RUB',
  },
  merchantName: 'Example Merchant',
}

const stripeRequestData = {
  cardPaymentMethod: {
    tokenizationSpecification: {
      type: 'PAYMENT_GATEWAY',
      gateway: 'stripe',
      gatewayMerchantId: '',
      stripe: {
        publishableKey: 'pk_test_51MvF3ESAf6yfFaxSRD2GhueKCszmAAWlWSt3K7aNnsgpFRwLs69XRNP8B405JfT8khasezDHA25dC91zt8yFa3IR00527q0HUS',
        version: '2018-11-08',
      },
    },
    allowedCardNetworks,
    allowedCardAuthMethods,
  },
  transaction: {
    totalPrice: '0.1',
    totalPriceStatus: 'FINAL',
    currencyCode: 'RUB',
  },
  merchantName: 'Example Merchant',
}
const Membership = (props) => {
  const { confirmPayment } = useStripe();
  const dispatch = useDispatch();
  const {
   // isPlatformPaySupported,
    confirmPlatformPayPayment,
  } = usePlatformPay();
  const [animating, setAnimating] = useState(false);
  useEffect(() => {
    initStripe({
      publishableKey: 'pk_test_51MvF3ESAf6yfFaxSRD2GhueKCszmAAWlWSt3K7aNnsgpFRwLs69XRNP8B405JfT8khasezDHA25dC91zt8yFa3IR00527q0HUS',
      merchantIdentifier: 'com.youuup',
      //urlScheme: "your-url-scheme",
    });

  
   // fetchPaymentIntentClientSecret()
  }, []);
  // if (Platform.OS === 'android') {
  //  GooglePay.setEnvironment(GooglePay.ENVIRONMENT_TEST)
  // }
//}
// React.useEffect(() => {
//   (async function () {
//     if (!(await isPlatformPaySupported({ googlePay: {testEnv: true} }))) {
//       Alert.alert('Google Pay is not supported.');
//       return;
//     }
//   })();
// }, []);
// const payWithGooglePay = (requestData) => {
//   // Check if Google Pay is available
//   GooglePay.isReadyToPay(allowedCardNetworks, allowedCardAuthMethods).then((ready) => {
//     if (ready) {
//       // Request payment token
//       GooglePay.requestPayment(requestData)
//         .then(this.handleSuccess)
//         .catch(this.handleError)
//     }
//   })
// }

handleSuccess = (token) => {
  // Send a token to your payment gateway
  Alert.alert('Success', `token: ${token}`)
}

handleError = (error) => Alert.alert('Error', `${error.code}\n${error.message}`)


//Stripe//
// const pay = async () => {
//   const { error, paymentIntent } = await confirmPlatformPayPayment(
//     'sk_test_51MvF3ESAf6yfFaxSeQRLu08IQP1xfX8tCzQYhsXszrC3GBcbxh5S6L0MqGcQzDAfdFSsV8kQmfOLPCxZNYxIFd1A00MkRu4swj',
//     {
//       googlePay: {
//         testEnv: true,
//         merchantName: 'Test',
//         merchantCountryCode: 'US',
//         currencyCode: 'usd',
//         billingAddressConfig: {
//           format: PlatformPay.BillingAddressFormat.Full,
//           isPhoneNumberRequired: true,
//           isRequired: true,
//         },
//       },
//     }
//   );

//   if (error) {
//     Alert.alert('Failure', error.localizedMessage);
//   } else {
//     Alert.alert('Success', 'Check the logs for payment intent details.');
//     console.log(JSON.stringify(paymentIntent, null, 2));
//     setClientSecret(null);
//   }
// };





// const fetchPaymentIntentClientSecret = async () => {
//   // Fetch payment intent created on the server, see above
//   const response = await fetch(`https://api.stripe.com/v1/payment_intents/sk_test_51MvF3ESAf6yfFaxSeQRLu08IQP1xfX8tCzQYhsXszrC3GBcbxh5S6L0MqGcQzDAfdFSsV8kQmfOLPCxZNYxIFd1A00MkRu4swj`, {
//     method: 'POST',
//     headers: {
//       'Content-Type': 'application/json',
//     },
//     body: JSON.stringify({
//       amount:1,
//       currency: 'usd',
//     }),
//   });
//   const { clientSecret } = await response.json();
//   console.log('gfg',response)

//   return clientSecret;
// };

// const pay = async () => {
//   const clientSecret = await fetchPaymentIntentClientSecret();
//   console.log('gfg111',clientSecret)

//   const { error } = await confirmPlatformPayPayment(
   
//     {
//       googlePay: {
//         testEnv: true,
//         merchantName: 'My merchant name',
//         merchantCountryCode: 'US',
//         currencyCode: 'USD',
//         billingAddressConfig: {
//           format: PlatformPay.BillingAddressFormat.Full,
//           isPhoneNumberRequired: true,
//           isRequired: true,
//         },
//       },
//     }
//   );

//   if (error) {
//     Alert.alert(error.code, error.message);
//     // Update UI to prompt user to retry payment (and possibly another payment method)
//     return;
//   }
//   Alert.alert('Success', 'The payment was confirmed successfully.');
// };

//Pay method//s
const createPaymentMethod = async () => {
  const { error, paymentMethod } = await createPlatformPayPaymentMethod({
    googlePay: {
      amount:25.18,
      currencyCode: 'USD',
      testEnv: true,
      merchantName: 'Youuup',
      merchantCountryCode: 'US',
    },
  });

  if (error) {
    //Alert.alert(error.code, error.message);
    return;
  } else if (paymentMethod) {
    // paymentMethodId: ${paymentMethod.id}
    Alert.alert(
      'Éxito',
      `El método de pago se ha completado correctamente.`
    );
    AsyncStorage.getItem('auth_token').then(async (datatoken) => { 
      axios({
        url: Apiurl+"user/payment",
        method: "POST",
        data: {"amount":12,"payment_id":paymentMethod.id},
        headers: {
          Accept: "application/json",
          Authorization:"Bearer "+datatoken,
        },
      })
      .then((response) => {
       // console.log(response.data?.paymentStatus)
        // if(response.data?.paymentStatus==false)
        // {
        //   navigation.navigate(NAVIGATION.Membership)

        // }
        // setpaymentStatus(response.data?.paymentStatus)

    
       })
      .catch(function (error) {
        console.log("error", error);
        if(error?.response?.data?.message=='Unauthorized')
        {
       
         dispatch(logout());
        }
      });
     });
  }
};

/*
  As an alternative you can only create a paymentMethod instead of confirming the payment.
*/
// const createPaymentMethod = async () => {
//   const { error, paymentMethod } = await createPlatformPayPaymentMethod({
//     googlePay: {
//       amount: 12,
//       currencyCode: 'USD',
//       testEnv: true,
//       merchantName: 'Test',
//       merchantCountryCode: 'US',
//       billingAddressConfig: {
//         format: PlatformPay.BillingAddressFormat.Full,
//         isPhoneNumberRequired: true,
//         isRequired: true,
//       },
//       shippingAddressConfig: {
//         isRequired: true,
//       },
//       isEmailRequired: true,
//     },
//   });

//   if (error) {
//     Alert.alert('Failure', error.localizedMessage);
//   } else {
//     Alert.alert('Success', 'Check the logs for payment method details.');
//     console.log(JSON.stringify(paymentMethod, null, 2));
//   }
// };

const createToken = async () => {
  const { error, token } = await createPlatformPayToken({
    googlePay: {
      amount: 1,
      currencyCode: 'USD',
      testEnv: true,
      merchantName: 'Test',
      merchantCountryCode: 'US',
      billingAddressConfig: {
        format: PlatformPay.BillingAddressFormat.Full,
        isPhoneNumberRequired: true,
        isRequired: true,
      },
      shippingAddressConfig: {
        isRequired: true,
      },
      isEmailRequired: true,
    },
  });

  if (error) {
    Alert.alert('Failure', error.localizedMessage);
  } else {
    Alert.alert('Success', 'Check the logs for token details.');
    console.log(JSON.stringify(token, null, 2));
  }
};
//end//

  // const requestData = {
  //   cardPaymentMethod: {
  //     tokenizationSpecification: {
  //       type: 'PAYMENT_GATEWAY',
  //       // stripe (see Example):
  //       gateway: 'stripe',
  //       gatewayMerchantId: '',
  //       stripe: {
  //         publishableKey: 'pk_test_TYooMQauvdEDq54NiTphI7jx',
  //         version: '2018-11-08',
  //       },
  //       // other:
  //       gateway: 'example',
  //       gatewayMerchantId: 'exampleGatewayMerchantId',
  //     },
  //     allowedCardNetworks,
  //     allowedCardAuthMethods,
  //   },
  //   transaction: {
  //     totalPrice: '0.2',
  //     totalPriceStatus: 'FINAL',
  //     currencyCode: 'USD',
  //   },
  //   merchantName: 'Example Merchant',
  // };
  
  // Set the environment before the payment request
  // GooglePay.setEnvironment(GooglePay.ENVIRONMENT_TEST);
  
  // // Check if Google Pay is available
  // GooglePay.isReadyToPay(allowedCardNetworks, allowedCardAuthMethods)
  //   .then((ready) => {
  //     if (ready) {
  //       // Request payment token
  //       GooglePay.requestPayment(requestData)
  //         .then((token) => {
  //           // Send a token to your payment gateway
  //         })
  //         .catch((error) => console.log(error.code, error.message));
  //     }
  //   })

  return (
    <ImageBackground
    style={{ flex: 1,  }}
    resizeMode={"stretch"}
    backgroundColor={'black'}
    source={require("../../assets/images/editprofileback.png")}
  >
    <StatusBar translucent backgroundColor="transparent" />
    <Header back={true} {...props} title='Membresia' />
    <View style={styles.mainContainer}>
    <View style={{marginTop:100,margin:30, backgroundColor:'white',height:'50%',borderRadius:13}}>
    <Image  style={{height:100,width:100,alignSelf:'center',marginTop:40}} source={require("../../assets/images/logopayment.png")} />
    <View style={{alignSelf:'center', marginTop:30,borderWidth:0.2,borderRadius:5,paddingTop:20,paddingBottom:20,paddingLeft:5,paddingRight:5}}>
      <Text style={{color:'black',fontFamily:FONTS.PoppinsSemiBold,fontSize:14,textAlign:'center'}} >Precio fijo por mes</Text>
      <Text style={{color:'black',fontFamily:FONTS.PoppinsSemiBold,fontSize:18,textAlign:'center'}}>
      22,95 euros
      </Text>
    </View>
    {/* <TouchableOpacity  onPress={() => pay()} style={{alignSelf:'center',padding:13,borderRadius:25, backgroundColor:"#08DDFD",marginTop:20,width:200}}>
     <Text style={{textAlign:'center',color:'black',fontFamily:FONTS.PoppinsMedium,fontSize:14}}>Actualizar</Text>
    </TouchableOpacity> */}
    <View style={{marginTop:50,marginLeft:10,marginRight:10}} >
      <PlatformPayButton
        type={PlatformPay.ButtonType.Pay}
        onPress={createPaymentMethod}
        style={{
          width: '100%',
          height: 50,
        }}
      />
    </View>
    </View>
   {/* <StripeProvider
      publishableKey={'pk_test_TYooMQauvdEDq54NiTphI7jx'}
      merchantIdentifier="merchant.identifier" // required for Apple Pay
      urlScheme="your-url-scheme" // required for 3D Secure and bank redirects
    >
       <CardField
      postalCodeEnabled={true}
      placeholders={{
        number: '4242 4242 4242 4242',
      }}
      cardStyle={{
        backgroundColor: '#FFFFFF',
        textColor: '#000000',
      }}
      style={{
        width: '100%',
        height: 50,
        marginVertical: 30,
      }}
      onCardChange={(cardDetails) => {
        console.log('cardDetails', cardDetails);
      }}
      onFocus={(focusedField) => {
        console.log('focusField', focusedField);
      }}
    />
    </StripeProvider>  */}
    </View>
        {animating == true && (
         <ActivityIndicator
          animating
         color={'white'}
         size="large"
         style={styles.activityIndicator}
         />
         )} 
 </ImageBackground>
  );
};

export default Membership;
