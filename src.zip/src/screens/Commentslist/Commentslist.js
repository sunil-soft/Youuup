import AsyncStorage from '@react-native-async-storage/async-storage';
import axios from "axios";
import { useEffect, useState } from "react";
import { FlatList, Image, ImageBackground, StatusBar, Text, TouchableOpacity, View } from "react-native";
import { showMessage } from "react-native-flash-message";
import { useDispatch, useSelector } from "react-redux";
import { logout } from "../../actions/UserActions";
import { Header } from "../../components/Header";
import { InputField } from "../../components/InputField";
import { NAVIGATION } from "../../constants";
import { getUser } from "../../selectors/UserSelectors";
import { FONTS } from "../../theme/fonts";
import { styles } from "./Commentsliststyles";

//const APIBASEURL = 'http://103.15.67.180:4006/'
const APIBASEURL = 'https://youuup.es/mobile-api/'


const Commentslist = (props) => {

  
  const dispatch = useDispatch();
  const { navigation, route } = props;
  const user = useSelector(getUser);
  const { video_id,previous_screen,callbycommentfun } = route.params;

  const [comment, setcomment] = useState("");
  const [commentlist, setcommentlist] = useState([]);
  const [animating, setAnimating] = useState(false);
  const [btndisabled, setbtndisabled] = useState(false);


  useEffect(() => {
    commentlistapi(video_id)
  }, []);

 

  const commentlistapi = (video_id) => {
    AsyncStorage.getItem('auth_token').then(async (datatoken) => {
      if (datatoken) {
        axios({
          url: APIBASEURL + "video/video-comments",

          method: "POST",

          data: { "video_id": video_id },

          headers: {
            //  "Content-Type": "",
            Accept: "application/json",
            Authorization: "Bearer " + datatoken,
          },
        })
          .then((response) => {
            console.log(response.data.videoComments)
            setcommentlist(response.data.videoComments);
          })
          .catch(function (error) {
            if(error?.response?.data?.message=='Unauthorized')
            {
           
             dispatch(logout());
            }
            console.log("error", error);
          });
      }
    });

  };

  const Validation = () => {
    if (!comment.trim()) {
      showMessage({
        message: "Por favor ingrese un comentario",
        type: "danger",
      });
    }
    else {
      setbtndisabled(true)
      Addcomment();
      //setShowModal(true);
      // props.navigation.navigate("EditUserDetail");
    }
  };
  const Addcomment = async () => {
    AsyncStorage.getItem('auth_token').then(async (datatoken) => {


      axios({
        url: APIBASEURL + "video/add-comment",

        method: "POST",

        data: { "video_id": video_id, comment: comment },

        headers: {
          //  "Content-Type": "",
          Accept: "application/json",
          Authorization: "Bearer " + datatoken,
        },
      })
        .then((response) => {
          setcomment('')
          commentlistapi(video_id)
          setbtndisabled(false)
          callbycommentfun(video_id)
          //  setcommentlist(response.data.videos);

        })
        .catch(function (error) {

          console.log("error", error);

        });
    });

    //console.log(data)
    //dispatch(editprofileapi(data));
  };



  return (
    <ImageBackground
      style={{ flex: 1, }}
      resizeMode={"stretch"}
      backgroundColor={'black'}
      source={require("../../assets/images/editprofileback.png")}
    >

      <StatusBar translucent backgroundColor="transparent" />
      <Header back={true} {...props} title='Comentarios' />
      {/* {showModal && <PopUp />} */}
      <View style={styles.mainContainer}>

        <View style={{ paddingLeft: 20, paddingRight: 20, marginTop: 80, marginBottom: 10 }}>
          <View style={{ height: "90%" }} >
            {commentlist.length > 0 ?

              <FlatList
                data={commentlist}
                renderItem={({ item }) =>
                  <>
                    <View style={{ marginTop: 10, flexDirection: "row", marginLeft: 15, marginRight: 15, alignContent: 'center', alignItems: 'center' }}>
                      <TouchableOpacity  onPress={()=>navigation.navigate(NAVIGATION.Followerdetail,{creater_id:item.comment_by_id,user_type_id:item.user_type_id})} style={{ width: '20%' }}>
                        {item.profile_photo ?
                          <Image style={{ width: 56, height: 56, borderRadius: 50 }} source={{ uri: APIBASEURL + item.profile_photo }} />
                          :
                          <Image style={{ width: 56, height: 56, borderRadius: 50 }} source={{ uri: 'https://p16-va-default.akamaized.net/img/musically-maliva-obj/1606484041765893~c5_720x720.jpeg' }} />
                        }
                      </TouchableOpacity>
                      <View style={{ width: '55%', width: '100%' }}>
                          <TouchableOpacity
                           onPress={()=>navigation.navigate(NAVIGATION.Followerdetail,{creater_id:item.comment_by_id,user_type_id:item.user_type_id})} 
                          >
                          <Text style={{ color: '#08DDFD', fontSize: 12, fontWeight: "600", fontFamily: FONTS.PoppinsMedium }}>
                            {item.name}
                          </Text>
                          </TouchableOpacity>
                          <Text style={{ color: '#FFFFFF', fontSize: 12, fontWeight: "600", fontFamily: FONTS.PoppinsMedium }}>
                            {item.comment}
                          </Text>
                       
                      </View>
                    </View>
                    <View style={{ backgroundColor: "#2A2A2A", height: 0.5, marginTop: 5, width: '100%', justifyContent: 'center', alignSelf: 'center' }}></View>
                  </>
                }
              />
              :
              <View style={{ alignSelf: 'center', marginTop: "50%" }}>
                <Text style={{ color: 'white' }}>Sin comentarios.</Text>
              </View>
            }
          </View>

          <View style={{ height: "7%" }} >
            <View
              style={{
                position: 'relative',
                bottom: '80%',
                top: 0,
                flexDirection: "row"
              }}
            >
              <InputField
                autoFocus={true}
                onChangeText={(text) => {
                  setcomment(text)
                }}

                value={comment}
                color={"white"}
                mainViewStyle={{ width: "100%", paddingRight: 40 }}
                // icon={"account"}
                // title={"Full Name"}
                // placeholder={"Por favor ingrese un comentario"}

                placeholderColor={"white"}
              />
              <TouchableOpacity
                disabled={btndisabled}
                onPress={() => Validation()}
                style={{ height: 60, position: 'relative', right: 52, justifyContent: 'center' }}>
                <Text style={{ color: "#08DDFD" }}>Enviar</Text>
              </TouchableOpacity>
            </View>
            {/* <Text style={{color:'white'}}>comments1</Text>
          <Text style={{color:'white'}}>comments1</Text>
          <Text style={{color:'white'}}>comments1</Text> */}
          </View>
        </View>
      </View>
      {/* {animating == true && (
        <ActivityIndicator
          animating
          color={'black'}
          size="large"
          style={styles.activityIndicator}
        />
      )} */}
    </ImageBackground>
  );
};

export default Commentslist;
