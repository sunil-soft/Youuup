import { Dimensions, StyleSheet } from "react-native";
import { moderateScale, scale, verticalScale } from "../../helper/Scale";
import { FONTS } from "../../theme/fonts";
export const styles = StyleSheet.create({
  backgroundVideo: {
    width:360,
    height:500,
    marginLeft:10,
    marginRight:10,
  //  borderRadius:50
  borderRadius: moderateScale(15),
  //margin:10,
 // marginTop:7,
  //backgroundColor:"white"
    // alignItems: "center",
   //   position: "absolute",
   //  height: 300,
   //   left: 0,
   //   top: 0,
   //   right: 0,
   //   bottom: 0,
 },
  editprofilestyle: {
    color: "#43686A",
    fontSize: moderateScale(30),
    fontFamily: FONTS.PoppinsSemiBold,
    marginLeft: moderateScale(12),
    marginTop: verticalScale(10),
  },
  editprofiledetails: {
    color: "#738485",
    fontSize: moderateScale(16),
    fontFamily: FONTS.PoppinsLight,
    marginLeft: moderateScale(13),
  },
  fullnametextstyle: {
    color: "#43686A",
    fontSize: moderateScale(12),
    marginLeft: moderateScale(3),
    marginTop: verticalScale(3),
    fontFamily: FONTS.PoppinsRegular,
  },
  Adresstextstyle: {
    color: "#43686A",
    fontSize: moderateScale(12),
    marginLeft: moderateScale(3),
    marginTop: verticalScale(3),
    fontFamily: FONTS.PoppinsRegular,
  },
  adressbox: {
    backgroundColor: "#EBF0F1",
    height: scale(70),
    marginHorizontal: moderateScale(20),
    borderRadius: moderateScale(15),
    padding: verticalScale(3),
    paddingLeft: moderateScale(10),
    marginTop: verticalScale(20),
  },
  fullnamebox: {
    backgroundColor: "#EBF0F1",
    height: scale(65),
    marginHorizontal: moderateScale(20),
    borderRadius: moderateScale(15),
    padding: verticalScale(3),
    paddingLeft: moderateScale(10),
    marginTop: verticalScale(30),
    height: scale(70),
  },
  textinputstyle: {
    fontSize: moderateScale(15),
    color: "#93AFB1",
    marginLeft: moderateScale(10),
    marginHorizontal: moderateScale(30),
    bottom: scale(5),
  },
  buttonstyle: {
    width: "45%",
    backgroundColor: "#43686A",
    paddingVertical: scale(15),
    // paddingHorizontal: scale(15),
    borderRadius: moderateScale(14),
    justifyContent: "center",
    alignItems: "center",
  },
  savebuttonStyle: {
    width: "45%",
    backgroundColor: "#05A1AB",
    paddingVertical: scale(15),
    borderRadius: moderateScale(14),
    justifyContent: "center",
    alignItems: "center",
  },
  textinputtstyle: {
    fontSize: moderateScale(15),
    color: "#05A1AB",
    marginLeft: moderateScale(10),
    backgroundColor: "yellow",
  },
  mainContainer:
  {
    flex:1,
    marginTop:10
  },
  labal:
  {
    color:"#08DDFD",fontFamily:FONTS.PoppinsRegular,fontSize:14,fontWeight:'500',paddingLeft:5
  },
  placeNameTextStyle: {
    color: "#08DDFD",
    fontSize: moderateScale(12),
    fontWeight:'400',
    fontFamily: FONTS.PoppinsRegular,
   // marginLeft: moderateScale(10),
    marginTop: verticalScale(5),
   
  },
  activityIndicator: {
    position: 'absolute',
    left: 0,
    right: 0,
    top: 50,
    bottom: 0,
    alignItems: 'center',
    justifyContent: 'center',
    zIndex: 9999,
  },
  dropdown: {
    height: 70,
    paddingHorizontal: 10,
    backgroundColor:'red',
    marginTop:50,
    borderRadius:25,
    color:'white',
    position:"absolute",
    alignSelf:'center',
   // justifyContent:'left',
    width:Dimensions.get('window').width/1.1
  },
  icon: {
    marginRight: 5,
  },
  label: {
    position: 'absolute',
    backgroundColor: 'white',
    left: 22,
    top: 8,
    zIndex: 999,
    paddingHorizontal: 8,
    fontSize: 14,
  },
  placeholderStyle: {
    fontSize: 16,
  },
  selectedTextStyle: {
    fontSize: 16,
    color:'white'
  },
  iconStyle: {
    width: 20,
    height: 20,
  },
  inputSearchStyle: {
    height: 40,
    fontSize: 16,
  },

});
