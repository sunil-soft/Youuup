//import { COLORS, FONTS, SF, SH } from '@/theme';
import { useState } from "react";
import {
  Image, StatusBar,
  StyleSheet,
  Text, TouchableOpacity, View
} from "react-native";
import { scale } from "react-native-size-matters";
import Scale, { moderateScale } from "../helper/Scale";
import { FONTS } from "../theme/fonts";
export function Header(props) {
  // console.log("props---", props);
 // const appState = React.useRef(AppState.currentState);
  const [isModalVisible, setModalVisible] = useState(false);
  //const [activevideotype, setactivevideotype] = useState(2);

  // const toggleModal = () => {
  //   setModalVisible(!isModalVisible);
  // };
  // const navigation = useNavigation();
  const navigation = props.navigation;

  // const calllivefun = () => {
  //   props.calllive()
  //  // setactivevideotype(1)
  //  // props.toggleModal;
  // }
 
    const calllblinkfun = () => {
    
    setTimeout(() => {
      props.callblink()
    }, 10);
    // props.stop(props.currentbuffer)
   // setactivevideotype(1)
   // props.toggleModal;
  }
  const callallvideo = () => {
    setTimeout(() => {
      props.callallvideo()
    }, 10);
  
    
    // props.stop(props.currentbuffer)
  }
  const callshort = () => {
  setTimeout(() => {
    props.shorttype()
  }, 10);

    // props.stop(props.currentbuffer)
   // setactivevideotype(2)
   }
   const calllong = () => {
    setTimeout(() => {
      props.longtype()
    }, 10);
  
    // props.stop(props.currentbuffer)
   // setactivevideotype(3)  
   }

  return (
    <View style={styles.headercontainer}>
      <StatusBar translucent backgroundColor= {props.backcolor?props.backcolor:"transparent" }/>
      {props.back && (
        <View style={{ flexDirection: "row",alignContent:'center',width:'100%' }}>
          <View style={{width:'7%'}}>
          <TouchableOpacity
            style={[
              styles.backStyle,
              {
                padding:7,
                alignSelf: "flex-start",
                paddingHorizontal:5,
                paddingRight:20,
               // backgroundColor:'red'
              },
            ]}
            onPress={() => props.navigation.goBack()}
          >
            <Image source={props.icon} />
            <Image source={require("../assets/Home/greenarrow.png")} />
          </TouchableOpacity>
          </View>
          <View 
          style={{width:'87%',alignContent:'center',justifyContent:'center',alignItems:'center'}}
          >
          <Text
            style={{
              color: "#FFFFFF",
              fontFamily: FONTS.PoppinsRegular,
              fontSize: moderateScale(17),
           //  marginLeft: '39%',
            }}
          >
            {props.title}
          </Text>
          <Text
            style={{
              color: "#FFFFFF",
              fontFamily: FONTS.PoppinsRegular,
              fontSize: moderateScale(13),
           //  marginLeft: '39%',
            }}
          >
            {props?.subtitle}
          </Text>
          </View>
        </View>
      )}
      {!props.back && (
        <>
          <View style={{ flexDirection: "row", alignItems: "center" }}>
            {/* <View style={styles.backStyleview}>
              <TouchableOpacity
                style={styles.backStyle}
                onPress={() => props.navigation.toggleDrawer()}
              >
                <Image source={require("../assets/Home/menu.png")} />
              </TouchableOpacity>
            </View> */}
            <Text style={styles.headerTitle}>{props.title}</Text>
          </View>

          {!props.rightIcon && !props.midle && !props.selfvideostatus && (
            <View style={{ flexDirection: "row",width:'100%' }}>
              <View style={{width:"8%",justifyContent:"center"}}>
                <TouchableOpacity
                style={{justifyContent:"center",paddingTop:5,paddingBottom:5}}
               // style={{height:21,width:24}}
               // onPress={() => props.navigation.toggleDrawer()}
               onPress={callallvideo}
                
              >
                <Image resizeMode="center" tintColor={props.activevideotype==0?'#08DDFD':'white'} source={require("../assets/Home/New/HomeIcon.png")} />
              </TouchableOpacity>
              </View>
              <View style={{width:'82%',flexDirection:"row"}}>
               {/* <TouchableOpacity
               onPress={calllivefun}
                style={[styles.backStyle,{width:'20%',margin:2, backgroundColor:props.activevideotype==3?'#08DDFD':'transparent',borderRadius:15.5,padding:5,justifyContent:'center',alignContent:'center',alignItems:'center'}]}
              >
              <Text style={[styles.hlabeltext,{position:'relative'}]}>Live</Text>
              </TouchableOpacity> */}
              <TouchableOpacity
               onPress={calllblinkfun}
                style={[styles.backStyle,{width:'27%',margin:2, backgroundColor:props.activevideotype==3?'#08DDFD':'transparent',borderRadius:15.5,padding:5,justifyContent:'center',alignContent:'center',alignItems:'center'}]}
              >
              <Text style={[styles.hlabeltext,{position:'relative'}]}>Blink</Text>
              </TouchableOpacity>
              <View style={{backgroundColor:'rgba(255, 255, 255, 0.5)',width:1,opacity:0.5}}>
              </View>
              <TouchableOpacity
               onPress={callshort}
                style={[styles.backStyle,{width:'27%',margin:2,backgroundColor:props.activevideotype==1?'#08DDFD':'transparent',borderRadius:15.5,padding:3,justifyContent:'center',alignContent:'center',alignItems:'center'}]}
                
              >
              <Text style={[styles.hlabeltext,{marginLeft:0}]} >Short</Text>
              </TouchableOpacity>
              <View style={{backgroundColor:'rgba(255, 255, 255, 0.5)',width:1,opacity:0.5}}>
              </View>
              <TouchableOpacity
                style={[styles.backStyle,{width:'24%',margin:2,backgroundColor:props.activevideotype==2?'#08DDFD':'transparent',borderRadius:15.5,padding:3,justifyContent:'center',alignContent:'center',alignItems:'center'}]}
                onPress={calllong}
                
              >
              <Text style={styles.hlabeltext}>Long</Text>
              </TouchableOpacity>
               <TouchableOpacity
                style={[styles.backStyle,{ width:'15%',padding:3,justifyContent:'center',alignContent:'center',alignItems:'center'}]}
                onPress={() =>  
                  setTimeout(() => {
                    props.stop(props.callbuffer)
                    props.navigation.navigate('Searchuserlist')
                  }, 10)
                 }
                
              >
                <Image style={{tintColor:"#FFFFFF"}} source={require("../assets/Home/New/searchicon.png")} />
              </TouchableOpacity>
              <TouchableOpacity
              style={[styles.backStyle,{padding:3,justifyContent:'center',alignContent:'center',alignItems:'center'}]}
                onPress={() => 
                  setTimeout(() => {
                    props.stop(props.callbuffer)
                    props.navigation.toggleDrawer()
                  }, 10)
                  
                
                }
              >
                <Image source={require("../assets/Home/New/menu-right.png")} />
              </TouchableOpacity>
              </View>
            </View>
          )}

          {/* Self Video Header */}
        {props.selfvideostatus==true && (
            <View style={{ flexDirection: "row",width:'100%' }}>
              <View style={{width:"8%",justifyContent:"center"}}>

              
                 <TouchableOpacity
            style={[
              styles.backStyle,
              {
                padding:7,
                alignSelf: "flex-start",
                paddingHorizontal:5,
                paddingRight:20,
               // backgroundColor:'red'
              },
            ]}
            onPress={() => props.navigation.goBack()}
          >
            <Image source={props.icon} />
            <Image source={require("../assets/Home/greenarrow.png")} />
          </TouchableOpacity>
              </View>
              <View style={{width:'82%',flexDirection:"row"}}>
               {/* <TouchableOpacity
               onPress={calllivefun}
                style={[styles.backStyle,{width:'20%',margin:2, backgroundColor:props.activevideotype==3?'#08DDFD':'transparent',borderRadius:15.5,padding:5,justifyContent:'center',alignContent:'center',alignItems:'center'}]}
              >
              <Text style={[styles.hlabeltext,{position:'relative'}]}>Live</Text>
              </TouchableOpacity> */}
                <TouchableOpacity
               onPress={callallvideo}
                style={[styles.backStyle,{width:'15%', backgroundColor:props.activevideotype==0?'#08DDFD':'transparent',borderRadius:15.5,padding:5,justifyContent:'center',alignContent:'center',alignItems:'center'}]}
              >
              <Text style={[styles.hlabeltext,{position:'relative'}]}>Mix</Text>
              </TouchableOpacity>
              <TouchableOpacity
               onPress={calllblinkfun}
                style={[styles.backStyle,{width:'27%',margin:2, backgroundColor:props.activevideotype==3?'#08DDFD':'transparent',borderRadius:15.5,padding:5,justifyContent:'center',alignContent:'center',alignItems:'center'}]}
              >
              <Text style={[styles.hlabeltext,{position:'relative'}]}>Blink</Text>
              </TouchableOpacity>
              <View style={{backgroundColor:'rgba(255, 255, 255, 0.5)',width:1,opacity:0.5}}>
              </View>
              <TouchableOpacity
               onPress={callshort}
                style={[styles.backStyle,{width:'27%',margin:2,backgroundColor:props.activevideotype==1?'#08DDFD':'transparent',borderRadius:15.5,padding:3,justifyContent:'center',alignContent:'center',alignItems:'center'}]}
                
              >
              <Text style={[styles.hlabeltext,{marginLeft:0}]} >Short</Text>
              </TouchableOpacity>
              <View style={{backgroundColor:'rgba(255, 255, 255, 0.5)',width:1,opacity:0.5}}>
              </View>
              <TouchableOpacity
                style={[styles.backStyle,{width:'24%',margin:2,backgroundColor:props.activevideotype==2?'#08DDFD':'transparent',borderRadius:15.5,padding:3,justifyContent:'center',alignContent:'center',alignItems:'center'}]}
                onPress={calllong}
                
              >
              <Text style={styles.hlabeltext}>Long</Text>
              </TouchableOpacity>
               {/* <TouchableOpacity
                style={[styles.backStyle,{ width:'15%',padding:3,justifyContent:'center',alignContent:'center',alignItems:'center'}]}
                onPress={() =>   props.navigation.navigate('Searchuserlist')}
                
              >
                <Image style={{tintColor:"#FFFFFF"}} source={require("../assets/Home/New/searchicon.png")} />
              </TouchableOpacity> */}
              <TouchableOpacity
              style={[styles.backStyle,{padding:3,justifyContent:'center',alignContent:'center',alignItems:'center'}]}
                onPress={() => 
                  setTimeout(() => {
                    props.stop(props.callbuffer)
                    props.navigation.toggleDrawer()
                  
                  }, 10)
                }
              >
                <Image source={require("../assets/Home/New/menu-right.png")} />
              </TouchableOpacity>
              </View>
            </View>
          )}



    {props.midle && (
<View style={{ flexDirection: "row",width:'100%' }}>
  <View style={{width:"100%",justifyContent:"space-between",alignItems:'center',flexDirection:"row",marginTop:5}}>
    <TouchableOpacity
    style={{justifyContent:"center",padding:5}}
    onPress={() => props.navigation.goBack()}
    
  >
    <Image resizeMode="center" source={require("../assets/Home/New/HomeIcon.png")} />
  </TouchableOpacity>
  <Text style={{color:"#E9E9E9",fontSize:17,fontFamily:FONTS.PoppinsRegular,fontWeight:'600'}}>{props.midtitle}</Text>
 
  <TouchableOpacity
    style={[styles.backStyle,{  marginRight:15, padding:5,justifyContent:'center',alignContent:'center',alignItems:'center'}]}
    onPress={() => props.navigation.toggleDrawer()}
  >
    <Image source={require("../assets/Home/New/menu-right.png")} />
  </TouchableOpacity>
  </View>
  {/* <View style={{width:'77%',flexDirection:"row"}}>

  </View> */}
</View>
          )}
        </>
      )}
      {/* {props.rightButton && (
        <>
          <TouchableOpacity
            onPress={props.toggleModal}
            //  onPress={() => navigation.navigate(props.buttonAction)}
            style={styles.rtButtonView}
          >
            <Image
              source={props.imageUri}
              style={{ marginTop: verticalScale(10) }}
            />

            <Text style={[styles.rtButtonTxt, props.styless]}>
              {props.buttonTitle}
            </Text>
          </TouchableOpacity>
        </>
      )} */}
     
    
    </View>
  );
}

const styles = StyleSheet.create({
  headercontainer: {
    width: "100%",
    marginTop: StatusBar.currentHeight,
    alignItems: "center",
    paddingHorizontal: 10,
    paddingVertical: 5,
    flexDirection: "row",
    justifyContent: "space-between",
   position: 'absolute',
   backgroundColor: 'transparent',
   zIndex: 100,
   top: 0,
   left: 10,
   right: 0,
  },
  rtButtonView: {
    padding: scale(10),
    borderRadius: 5,
    alignItems: "center",
    justifyContent: "center",
  },
  rtButtonTxt: {
    fontSize: 12,
    fontFamily: FONTS.PoppinsMedium,
    color: "white",
  },
  headerTitle: {
    fontFamily: FONTS.PTBold,
    fontSize: Scale.moderateScale(22),
    color: "#FFFFFF",
  },
  backStyleview: {},
  backStyle: {
   // paddingHorizontal: moderateScale(10),
  },
  logo: {
    marginHorizontal: 10,
    alignSelf: "flex-end",
  },
  hlabeltext: {
    color:"#FFFFFF",fontSize:14,fontFamily:FONTS.PoppinsRegular,fontWeight:'600',textTransform:'uppercase'
  },
});
