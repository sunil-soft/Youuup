import { useTheme } from '@react-navigation/native';
import PropTypes from 'prop-types';
import { StyleSheet, Text, TouchableOpacity } from 'react-native';
import { verticalScale } from '../helper/Scale';
import { FONTS } from '../theme/fonts';
const styles = StyleSheet.create({
  button: {
    alignItems: 'center',
    justifyContent: 'center',
    borderRadius: 25,
marginBottom:10,
    // borderWidth: 1,
    // padding: 5,
    width: '90%',
    alignSelf: 'center',
    height: verticalScale(50),
    backgroundColor:'#08DDFD'
  },
});

export function Button({style, textStyle, title, ...rest}) {
  const {colors} = useTheme();

  return (
    <TouchableOpacity
      style={[styles.button, style]}
      {...rest}>
        {/* <LinearGradient
          colors={['#FFFFFF', '#08DDFD', '#08DDFD']}
          style={styles.button}> */}
      <Text
        style={[
          {
            color: '#121212',
            fontSize: 17,
            fontWeight: '600',
            fontFamily: FONTS.PoppinsRegular,
          },
          textStyle,
        ]}>
        {title}
      </Text>
      {/* </LinearGradient> */}
    </TouchableOpacity>
  );
}

Button.propTypes = {
  style: PropTypes.object,
  textStyle: PropTypes.object,
  title: PropTypes.string.isRequired,
};

Button.defaultProps = {
  style: null,
  textStyle: null,
};
