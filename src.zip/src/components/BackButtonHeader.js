import { View, Text } from 'react-native'
import React from 'react'

const BackButtonHeader = () => {
  return (
    <View>
      <Text>BackButtonHeader</Text>
    </View>
  )
}

export default BackButtonHeader