import { useNavigation } from "@react-navigation/native";
import { useState } from "react";
import {
  Alert, FlatList, Image, ImageBackground, Platform,
  StatusBar, StyleSheet, Text, TouchableOpacity, View
} from "react-native";
import { moderateScale } from "react-native-size-matters";
import { useDispatch, useSelector } from "react-redux";
import { logout } from "../actions/UserActions";
import { NAVIGATION } from "../constants";
import { scale } from "../helper/Scale";
import { getUser } from "../selectors/UserSelectors";
import { FONTS } from "../theme/fonts";


const CustomDrawer = (props) => {
  const dispatch = useDispatch();

  const BASE_PATH = "";
  const proileImage = "react_logo.png";
  const navigation = useNavigation();

  const [selectedIndex, setSelectedIndex] = useState(0);
  const user = useSelector(getUser);


  //dispatch(login(data));
  const logoutUser = () => {
    Alert.alert('', '¿Quieres cerrar sesión?', [
      //   { text: 'OK', onPress: () => dispatch(logout()) },
      { text: 'Sí', onPress: () => dispatch(logout()) },
      {
        text: 'Cancelar',
        onPress: () => console.log('Cancel Pressed'),
        style: 'cancel',
      },
    ]);
  };

  return (
    <ImageBackground
      imageStyle={{ resizeMode: "stretch" }}
      source={require("../assets/Drawer/drawergraphics.png")}
      style={{
        marginTop: Platform.OS == "android" ? StatusBar.currentHeight : 0,
        marginBottom: scale(10),
        height: "97%",
        width: '90%',
        marginLeft: '23%',
        // alignSelf:"flex-end",
        // justifyContent:'center',
        alignItems: 'center',
        borderRadius: 20,
        // backgroundColor:"red",
        alignItems: 'center',
        alignContent: "center",
        marginRight: 20,
        borderRadius: 20
      }}
    >
      {/* <View
            style={{
            
              marginTop: Platform.OS == "android" ? StatusBar.currentHeight : 0,
              marginBottom: scale(10),
              height: "95%",
              width:'70%',
              alignSelf:"flex-end",
              borderRadius: 20,
             // backgroundColor:"red",
              alignItems:'center',
              alignContent:"center",
              borderRadius:20
            }}
      > */}
      <View
        style={{
          marginTop: scale(20),
          alignItems: "center",
          marginRight: 20
          //  backgroundColor:"red"
        }}
      >
        <View style={{}}>
          <View
            style={{
              flexDirection: "row",
              //paddingVertical: 5,
            }}
          >
            <View style={{ justifyContent: "center", alignItems: 'center', alignContent: 'center' }}>
              <View style={{ width: '100%', alignItems: 'flex-end', alignContent: 'flex-end' }}>
                <TouchableOpacity style={{ padding: 5, width: '30%' }} onPress={() => props.navigation.toggleDrawer()}>
                  <Image
                    style={{
                      // width: scale(240),
                      // height: scale(42.53),
                      alignSelf: 'flex-end',
                      marginRight: 15,

                      // marginTop:10,
                      //resizeMode: "cover",
                    }}
                    source={require("../assets/Home/New/rightarrow.png")}
                  />
                </TouchableOpacity>
              </View>
              <View style={{}} >
                <Image
                  style={{
                    // width: scale(240),
                    // height: scale(42.53),
                    alignSelf: 'center',
                    position: "relative",
                    // bottom:10,
                    //marginTop:20,
                    // backgroundColor:"red"
                    // marginBottom:1,
                    // marginTop:15
                    //resizeMode: "cover",
                  }}
                  source={require("../assets/Drawer/Logomenu.png")}
                />
                <Text
                  style={{
                    color: "#FFFFFF",
                    fontSize: 22,
                    fontWeight: '600',
                    fontFamily: FONTS.PoppinsRegular,
                    textAlign: 'center',
                    position: "relative",
                    bottom: 30
                    // paddingHorizontal: moderateScale(10),
                  }}
                >
                  Menú
                </Text>
              </View>
            </View>
          </View>
          {/* <Text
              style={{
                color: "#FFFFFF",
                fontSize: 19,
                fontFamily: FONTS.PoppinsRegular,
                textAlign:'center'
               // paddingHorizontal: moderateScale(10),
              }}
            >
              Keep it Real
            </Text> */}
          {/* <Text
              style={{
                color: "#FFFFFF",
                fontSize: 22,
                fontWeight:'600',
                fontFamily: FONTS.PoppinsRegular,
                textAlign:'center'
               // paddingHorizontal: moderateScale(10),
              }}
            >
             Menú
            </Text> */}
        </View>
      </View>
      <View
        style={{
          flex: 1,
          alignSelf: "center",
          width: "90%",
          paddingRight: 25,
          // paddingHorizontal: moderateScale(30),
          marginTop: 60,

          // backgroundColor: 'black',
        }}
      >
        <FlatList
          data={user && user?.userinfo?.user.user_type_id == 3 ? [
            {
              title: "Perfil",
              icon: require("../assets/Drawer/userprof.png"),
              Screen: NAVIGATION.MyProfile
            },
            {
              title: "Mensajes",
              icon: require("../assets/Drawer/emailbtn.png"),
              Screen: NAVIGATION.ChatUSerList,
            },
            {
              title: "Short",
              icon: require("../assets/Drawer/shortvideo.png"),
              Screen: NAVIGATION.AddVideo,
            },
            {
              title: "Long",
              icon: require("../assets/Drawer/shortvideo.png"),
              Screen: NAVIGATION.AddVideoLong,
            },
            {
              title: "Go Blink",
              icon: require("../assets/Drawer/shortvideo.png"),
              Screen: NAVIGATION.AddVideoBlink,
            },
            // {
            //   title: "Go Live",
            //   icon: require("../assets/Drawer/shortvideo.png"),
            //   Screen: NAVIGATION.GoLive,
            // },
            {
              title: "Favoritos",
              icon: require("../assets/Drawer/fav.png"),
              Screen: NAVIGATION.Favvideo,
            },
            {
              title: "Información",
              icon: require("../assets/Drawer/info.png"),
              Screen: NAVIGATION.AboutUs,
            },
            {
              title: "Notificaciones",
              icon: require("../assets/Drawer/notification.png"),
              Screen: NAVIGATION.Notifications,
            },
            {
              title: "Denunciado",
              icon: require("../assets/Drawer/Denunc.png"),
              Screen: NAVIGATION.Reportlist,
            },
            {
              title: "Bloqueados",
              icon: require("../assets/Drawer/Block.png"),
              Screen: NAVIGATION.Blocklist,
            },
            // {
            //   title: "Preguntas",
            //   icon: require("../assets/Drawer/ques.png"),
            //   Screen: NAVIGATION.FAQ,
            // },
            {
              title: "Ajustes",
              icon: require("../assets/Drawer/settingicon.png"),
              Screen: NAVIGATION.Settings,
            },
          ] : [
            {
              title: "Perfil",
              icon: require("../assets/Drawer/userprof.png"),
              Screen: NAVIGATION.MyProfile
            },
            {
              title: "Mensajes",
              icon: require("../assets/Drawer/emailbtn.png"),
              Screen: NAVIGATION.ChatUSerList,
            },

            {
              title: "Favoritos",
              icon: require("../assets/Drawer/fav.png"),
              Screen: NAVIGATION.Favvideo,
            },
            {
              title: "Información",
              icon: require("../assets/Drawer/info.png"),
              Screen: NAVIGATION.AboutUs,
            },
            {
              title: "Notificaciones",
              icon: require("../assets/Drawer/notification.png"),
              Screen: NAVIGATION.Notifications,
            },
            {
              title: "Denunciado",
              icon: require("../assets/Drawer/Denunc.png"),
              Screen: NAVIGATION.Reportlist,
            },
            {
              title: "Bloqueados",
              icon: require("../assets/Drawer/Block.png"),
              //  Screen: NAVIGATION.MyProfile,
              Screen: NAVIGATION.Blocklist,
            },
            // {
            //   title: "Preguntas",
            //   icon: require("../assets/Drawer/ques.png"),
            //   Screen: NAVIGATION.FAQ,
            // },
            {
              title: "Ajustes",
              icon: require("../assets/Drawer/settingicon.png"),
              Screen: NAVIGATION.Settings,
            },
          ]}
          renderItem={({ item, index }) => (
            index == selectedIndex ?
              <ImageBackground
                imageStyle={{ resizeMode: "center" }}
                source={require("../assets/Drawer/btnback.png")}>
                <TouchableOpacity
                  // onPress={() => console.log('propr', props)}
                  onPress={() => {
                    //console.log(index)
                    setSelectedIndex(index);
                    navigation.navigate(item.Screen,);

                  }}
                  style={{ flexDirection: "row", alignItems: 'center' }}
                >
                  <View
                    style={{
                      paddingLeft: 15
                      // backgroundColor: "#37B4BC",
                      // alignItems: "center",
                      // // justifyContent: 'center',
                      // width: verticalScale(32),
                      // borderTopLeftRadius: index == 0 ? 8 : 0,
                      // borderTopRightRadius: index == 0 ? 8 : 0,
                      // borderBottomLeftRadius: index == 3 ? 8 : 0,
                      // borderBottomRightRadius: index == 3 ? 8 : 0,
                    }}
                  >
                    <View
                      style={{
                        //alignItems:'center',
                        //marginTop: 10,
                        // marginHorizontal: verticalScale(3),
                        //alignSelf: "center",
                        // padding: verticalScale(2),
                        //  alignItems: "center",
                        // justifyContent: "center",
                        // backgroundColor:
                        //   index == selectedIndex ? "white" : "transparent",
                        // borderRadius: 4,
                      }}
                    >

                      <Image
                        style={{
                          alignSelf: 'center',
                          tintColor: index == selectedIndex ? "#08DDFD" : "white",
                          resizeMode: "center",
                        }}
                        source={item.icon}
                      />
                    </View>
                  </View>
                  <View
                    style={{
                      alignItems: "flex-start",
                      paddingHorizontal: 20,
                      paddingVertical: 15,
                    }}
                  >
                    <Text
                      style={{
                        fontFamily:
                          index == selectedIndex
                            ? FONTS.PoppinsRegular
                            : FONTS.PoppinsRegular,
                        fontWeight: '500',
                        fontSize: 14,
                        color: index == selectedIndex ? "#08DDFD" : "#FFFFFF",
                      }}
                    >
                      {item.title}
                    </Text>
                  </View>
                </TouchableOpacity>

              </ImageBackground>
              :
              <View
              //   imageStyle={{ resizeMode: "center" }}
              //  source={require("../assets/Drawer/btnback.png")}
              >
                <TouchableOpacity
                  // onPress={() => console.log('propr', props)}
                  onPress={() => {
                    console.log("selected index", index);
                    setSelectedIndex(index);
                    navigation.navigate(item.Screen);
                  }}
                  style={{ flexDirection: "row", alignItems: 'center' }}
                >
                  <View
                    style={{
                      paddingLeft: 15
                      // backgroundColor: "#37B4BC",
                      // alignItems: "center",
                      // // justifyContent: 'center',
                      // width: verticalScale(32),
                      // borderTopLeftRadius: index == 0 ? 8 : 0,
                      // borderTopRightRadius: index == 0 ? 8 : 0,
                      // borderBottomLeftRadius: index == 3 ? 8 : 0,
                      // borderBottomRightRadius: index == 3 ? 8 : 0,
                    }}
                  >
                    <View
                      style={{
                        //alignItems:'center',
                        //marginTop: 10,
                        // marginHorizontal: verticalScale(3),
                        //alignSelf: "center",
                        // padding: verticalScale(2),
                        //  alignItems: "center",
                        // justifyContent: "center",
                        // backgroundColor:
                        //   index == selectedIndex ? "white" : "transparent",
                        // borderRadius: 4,
                      }}
                    >
                      <Image
                        style={{
                          alignSelf: 'center',
                          tintColor: index == selectedIndex ? "#08DDFD" : "white",
                          resizeMode: "center",
                        }}
                        source={item.icon}
                      />
                    </View>
                  </View>
                  <View
                    style={{
                      alignItems: "flex-start",
                      paddingHorizontal: 20,
                      paddingVertical: 15,
                    }}
                  >
                    <Text
                      style={{
                        fontFamily:
                          index == selectedIndex
                            ? FONTS.PoppinsRegular
                            : FONTS.PoppinsRegular,
                        fontSize: 14,
                        color: index == selectedIndex ? "#08DDFD" : "white",
                      }}
                    >
                      {item.title}
                    </Text>
                  </View>
                </TouchableOpacity>

              </View>
          )}
        />
      </View>
      <View style={{
        backgroundColor: '#2A2A2A',
        height: 0.1, width: '100%'
      }}>

      </View>
      <View style={{ margin: 20, width: '100%' }}>
        <TouchableOpacity
          onPress={() => logoutUser()}
          style={{
            flexDirection: "row",
            alignItems: "center",
            justifyContent: "center",
            alignSelf: "flex-start",
            bottom: scale(20),
            left: 35
            // right: scale(10),
          }}
        >
          <Image source={require("../assets/Drawer/signoutoption.png")} />
          <Text
            style={{
              fontFamily: FONTS.PoppinsLight,
              color: "white",
              fontSize: 18,
              paddingHorizontal: moderateScale(20),
              paddingVertical: moderateScale(10),
              textAlign: "center",
            }}
          >
            Cerrar sesión
          </Text>
        </TouchableOpacity>
      </View>
      {/* </View> */}
    </ImageBackground>
  );
};

const styles = StyleSheet.create({});

export default CustomDrawer;
