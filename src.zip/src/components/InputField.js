import PropTypes from "prop-types";
import { useState } from "react";
import { StyleSheet, Text, TextInput, View } from "react-native";
import { moderateScale } from "react-native-size-matters";
import Icon from "react-native-vector-icons/MaterialCommunityIcons";
import { scale, verticalScale } from "../helper/Scale";
import { FONTS } from "../theme/fonts";

export function InputField({
  mainViewStyle,
  inputViewStyle,
  textInputStyle,
  title,
  icon,
  color,
  right,
  props,
  placeholderColor,
  placeholder,
  iconSize,
  urii,
  value,
  uri,
  onChangeText,
  secureTextEntry,
  isActiveview,
  autoFocus,

  ...rest
}) {
  const [isActive, setActive] = useState(false);
  const [secureText, setsecureText] = useState(false);
  return (
    <View style={[styles.mainViewStyle, mainViewStyle,
   // {opacity:isActive   ? 0.5 : 0.09}
    {borderColor:"#08DDFD",borderWidth:isActive?1:0, backgroundColor: isActive?'rgba(26, 91, 101, 1)':'rgba(97, 156, 165, 0.09)'}
    ]}>
      {/* <Text style={{ flex: 1 }}>{title}</Text> */}
      <View style={[styles.inputViewStyle, inputViewStyle]}>
        <Icon
          name={icon}
          size={iconSize ? iconSize : 24}
          color={isActive ? "#05A1AB" : "#93AFB1"}
        />
        <TextInput
          onChangeText={onChangeText}
          autoFocus={autoFocus}
          value={value}
          onFocus={() => {
            setActive(true);
          }}
          onBlur={() =>{setActive(false)}}
          placeholder={placeholder}
          placeholderTextColor={placeholderColor}
          style={[styles.textInputStyle, textInputStyle]}
          // defaultValue={default}
          secureTextEntry={secureTextEntry}
          {...rest}
        />
        <Text>{isActiveview}</Text>
      {/* {right && <TouchableOpacity style={{backgroundColor:"red",padding:10}}><Image source={isActive ? uri : urii} /></TouchableOpacity>} */}

      </View>
    </View>
  );
}

InputField.PropTypes = {
  mainViewStyle: PropTypes.object,
  inputViewStyle: PropTypes.object,
  textInputStyle: PropTypes.object,
  title: PropTypes.string.isRequired,
};
const styles = StyleSheet.create({
  mainViewStyle: {
    backgroundColor: "#08DDFD",
    // backgroundColor: '#EBF000',
    height: verticalScale(50),
    width: scale(335),
    paddingVertical: 5,
    paddingHorizontal: 15,
    borderRadius: moderateScale(25),
    justifyContent: "center",
    marginVertical: 5,
    marginBottom:10,
  
  },
  inputViewStyle: {
    flexDirection: "row",
    flex: 2,
    alignItems: "center",
  },
  textInputStyle: {
    flex: 1,
    paddingHorizontal: 15,
    fontSize: 16,
    color: "white",
    fontFamily: FONTS.PoppinsLight,
    paddingVertical: 0,
  },
  searchIcon: {
    padding: 10,
  },
});
