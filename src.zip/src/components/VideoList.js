//import { COLORS, FONTS, SF, SH } from '@/theme';
import { useState } from "react";
import {
  StatusBar,
  StyleSheet,
  Text,
  View
} from "react-native";
import { scale } from "react-native-size-matters";
import Video from 'react-native-video';
import Scale from "../helper/Scale";
import { FONTS } from "../theme/fonts";
export function VideoList(props) {

 
  const [isModalVisible, setModalVisible] = useState(false);
 
  const navigation = props.navigation;

  const {data}=props;
  const videoData = [
    {
      id: 1,
      uri: 'https://youuup.com/youuupapi/data/videoUpload/1693084016100-video_.mp4',
    },
    {
      id: 2,
      uri: 'https://youuup.com/youuupapi/data/videoUpload/1693084016100-video_.mp4',
    },
    // Add more video objects as needed
  ];
  return (
  

      <View style={{marginTop:100}}>
    
       <Text style={{color:'white'}}>{data.url}</Text>
          <Video
            source={{ uri: data.url }}
            style={{ 
            //    alignItems: "stretch",
            // position: "absolute",
            width:500,
            height:1000,
          
       }}
          
          />
      </View>
   
   
  );
}

const styles = StyleSheet.create({
  headercontainer: {
    width: "100%",
    marginTop: StatusBar.currentHeight,
    alignItems: "center",
    paddingHorizontal: 10,
    paddingVertical: 5,
    flexDirection: "row",
    justifyContent: "space-between",
   position: 'absolute',
   backgroundColor: 'transparent',
   zIndex: 100,
   top: 0,
   left: 10,
   right: 0,
  },
  rtButtonView: {
    padding: scale(10),
    borderRadius: 5,
    alignItems: "center",
    justifyContent: "center",
  },
  rtButtonTxt: {
    fontSize: 12,
    fontFamily: FONTS.PoppinsMedium,
    color: "white",
  },
  headerTitle: {
    fontFamily: FONTS.PTBold,
    fontSize: Scale.moderateScale(22),
    color: "#FFFFFF",
  },
  backStyleview: {},
  backStyle: {
   // paddingHorizontal: moderateScale(10),
  },
  logo: {
    marginHorizontal: 10,
    alignSelf: "flex-end",
  },
  hlabeltext: {
    color:"#FFFFFF",fontSize:14,fontFamily:FONTS.PoppinsRegular,fontWeight:'600',textTransform:'uppercase'
  },
});
