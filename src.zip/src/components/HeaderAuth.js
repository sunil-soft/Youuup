//import { COLORS, FONTS, SF, SH } from '@/theme';
import Scale from '@/helper/Scale';
import { FONTS } from '@/theme/fonts';
import { Image, StatusBar, StyleSheet, Text, TouchableOpacity, View } from 'react-native';
export function HeaderAuth(props) {
  const { navigation, route } = props;

  const callallvideo = () => {
    setTimeout(() => {
      props.callallvideo()
    }, 10);
  }
  
  // const calllivefun = () => {
  //   props.calllive()
  //  // setactivevideotype(1)
  //  // props.toggleModal;
  // }
  const callshort = () => {
    setTimeout(() => {
      props.shorttype()
    }, 10);
   // setactivevideotype(2)
   }
   const calllblinkfun = () => {
    setTimeout(() => {
      props.callblink()
    }, 10);
  
  }
   const calllong = () => {
    setTimeout(() => {
      props.longtype()
    }, 10);
   // setactivevideotype(3)  
   }
  return (
    <View style={styles.headercontainer}>
     <StatusBar translucent backgroundColor= {props.backcolor?props.backcolor:"transparent" }/>
     <View style={{ flexDirection: "row" ,width:'100%',justifyContent:'flex-end',padding:10}}>
     <View style={{width:"12%",justifyContent:"center"}}>
                <TouchableOpacity
                style={{justifyContent:"center"}}
                onPress={callallvideo}
               // style={{height:21,width:24}}
             //  onPress={() =>  props.navigation.navigate("Login")}
                
              >
                <Image tintColor={props.activevideotype==0?'#08DDFD':'white'} resizeMode="center" source={require("../assets/Home/New/HomeIcon.png")} />
              </TouchableOpacity>
              </View>
       <View style={{width:'82%',flexDirection:"row"}}>
               {/* <TouchableOpacity
               onPress={calllivefun}
                style={[styles.backStyle,{width:'20%',margin:2, backgroundColor:props.activevideotype==3?'#08DDFD':'transparent',borderRadius:15.5,padding:5,justifyContent:'center',alignContent:'center',alignItems:'center'}]}
              >
              <Text style={[styles.hlabeltext,{position:'relative'}]}>Live</Text>
              </TouchableOpacity> */}
              <TouchableOpacity
               onPress={calllblinkfun}
                style={[styles.backStyle,{width:'25%',margin:2, backgroundColor:props.activevideotype==3?'#08DDFD':'transparent',borderRadius:15.5,padding:5,justifyContent:'center',alignContent:'center',alignItems:'center'}]}
              >
              <Text style={[styles.hlabeltext,{position:'relative'}]}>Blink</Text>
              </TouchableOpacity>
              <View style={{backgroundColor:'rgba(255, 255, 255, 0.5)',width:1,opacity:0.5}}>
              </View>
              <TouchableOpacity
               onPress={callshort}
                style={[styles.backStyle,{width:'27%',margin:2,backgroundColor:props.activevideotype==1?'#08DDFD':'transparent',borderRadius:15.5,padding:3,justifyContent:'center',alignContent:'center',alignItems:'center'}]}
                
              >
              <Text style={[styles.hlabeltext,{marginLeft:0}]} >Short</Text>
              </TouchableOpacity>
              <View style={{backgroundColor:'rgba(255, 255, 255, 0.5)',width:1,opacity:0.5}}>
              </View>
              <TouchableOpacity
                style={[styles.backStyle,{width:'24%',margin:2,backgroundColor:props.activevideotype==2?'#08DDFD':'transparent',borderRadius:15.5,padding:3,justifyContent:'center',alignContent:'center',alignItems:'center'}]}
                onPress={calllong}
                
              >
              <Text style={styles.hlabeltext}>Long</Text>
              </TouchableOpacity>
               <TouchableOpacity
                style={[styles.backStyle,{ width:'20%',padding:3,justifyContent:'center',alignContent:'center',alignItems:'center'}]}
                onPress={() =>    setTimeout(() => {
                  props.stop(props.callbuffer)
                  props.navigation.navigate("Login")
                }, 10)}
                
              >
                <Image style={{tintColor:"#FFFFFF"}} source={require("../assets/Home/New/searchicon.png")} />
              </TouchableOpacity>
              {/* <TouchableOpacity
              style={[styles.backStyle,{padding:3,justifyContent:'center',alignContent:'center',alignItems:'center'}]}

              onPress={() =>  props.navigation.navigate("Login")}
                
              >
                <Image source={require("../assets/Home/New/menu-right.png")} />
              </TouchableOpacity> */}
              </View>
              <TouchableOpacity
                style={{alignSelf:"center",alignItems:'center'}}
                onPress={() =>  
                  
                  
                  setTimeout(() => {
                    props.stop(props.callbuffer)
                    props.navigation.navigate("Login")
                  }, 10)
                
                }
                
              >
                <Image source={require("../assets/Home/New/menu-right.png")} />
              </TouchableOpacity>
      </View>

    </View>
  );
}

const styles = StyleSheet.create({

  headercontainer: {
    width: "100%",
    marginTop: StatusBar.currentHeight-10,
    alignItems: "center",
    paddingHorizontal: 10,
    paddingVertical: 5,
    flexDirection: "row",
    justifyContent: "space-between",
   position: 'absolute',
   backgroundColor: 'transparent',
   zIndex: 100,
   top: 0,
   left: 0,
   right: 0
  },
  headerTitle: {
    fontFamily: FONTS.PoppinsSemiBold,
    fontWeight: '600',
    fontStyle: 'normal',
    fontSize: Scale.moderateScale(18),
    color: '#000000',
    paddingLeft:5
  },
  backStyleview:
  {
    flex: 0.5,
  },
  backStyle: {
    width: '55%',
  },
  logo:
  {
    alignSelf: 'center'
  },
  hlabeltext: {
    color:"#FFFFFF",fontSize:14,fontFamily:FONTS.PoppinsRegular,fontWeight:'600',textTransform:'uppercase'
  },
});
