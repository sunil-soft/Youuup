import { createDrawerNavigator } from "@react-navigation/drawer";
import { Image, Platform, TouchableOpacity } from "react-native";
import { scale } from "react-native-size-matters";
import { useSelector } from 'react-redux';
import CustomDrawer from "../components/CustomDrawer";
import { NAVIGATION } from "../constants";
import { getUser } from '../selectors/UserSelectors';
import { HomeNavigator } from "./HomeNavigator";

const drawer = createDrawerNavigator();

export function AppNavigator() {
  const user = useSelector(getUser);
  return (
    <drawer.Navigator
     
      drawerContent={(props) => <CustomDrawer {...props} />}
      drawerStyle={{ backgroundColor: "transparent" }}
      
      screenOptions={({ navigation, route }) => ({
        swipeEnabled:false,
        headerTransparent: true,
        drawerPosition:'right',
        headerShown: false,
        headerTitleAlign: "center",
        drawerStyle: {
          backgroundColor: "transparent",
          width: "98%",
          // paddingRight: 20,
          marginLeft: -10,
         
        },
    

        headerRight: () => (
          <TouchableOpacity
            onPress={() => {
              navigation.navigate(NAVIGATION.profile);
            }}
          >
            <Image
              style={{
                height: Platform.OS === "ios" ? scale(25) : scale(35),
                right: scale(20),
              }}
              source={require("../assets/Home/msg.png")}
              resizeMode="contain"
            />
          </TouchableOpacity>
        ),

        headerLeft: () => (
          <TouchableOpacity
            onPress={() => {
              navigation.toggleDrawer();
            }}
          >
            <Image
              style={{
                height: Platform.OS === "ios" ? scale(25) : scale(35),
                left: scale(10),
              }}
              source={require("../assets/Home/menu.png")}
              resizeMode="contain"
            />
          </TouchableOpacity>
        ),

        // drawerStyle: {
        //   backgroundColor: COLOR.lightBlueD,
        //   width: '90%',
        // },
        // drawerActiveTintColor: COLOR.Black,
        // drawerLabelStyle: {
        //   fontSize: 20,
        //   fontFamily: FONTS.ModestoLightC,
        // },
        // headerStyle: {
        //   backgroundColor: COLOR.Black,
        // },
      })}
    >
      <drawer.Screen
        name={NAVIGATION.home}
        component={HomeNavigator}
        options={{
          drawerIcon: ({ color, size }) => (
            <Image
              style={{ height: 18, width: 21, left: 10 }}
              source={require("../assets/Home/menu.png")}
            />
          ),
        }}
      />
    </drawer.Navigator>
  );
}
