import { NavigationContainer } from '@react-navigation/native';
import { createNativeStackNavigator } from 'react-native-screens/native-stack';
import { useSelector } from 'react-redux';
import { AppNavigator } from '../navigation/AppNavigator';
import { AuthNavigator } from '../navigation/AuthNavigator';
import { getUser } from '../selectors/UserSelectors';
import { navigationRef } from './NavigationRef';

export function RootNavigator() {
  const user = useSelector(getUser);
  const Stack = createNativeStackNavigator();
  //console.log('user',user?.userinfo.payload.id)onReady={() => RNBootSplash.hide()}
  return (
    <NavigationContainer    ref={navigationRef}>
      {/* <AuthNavigator /> */}
      {user?.userinfo?.user.id ? <AppNavigator /> : <AuthNavigator />}
      {/* {user ?: */}
      {/* <AppNavigator /> */}
    </NavigationContainer>
  );
}
