import MyProfile from "@/screens/MyProfile/MyProfile";
import { createNativeStackNavigator } from "react-native-screens/native-stack";
import { NAVIGATION } from "../constants";
import AboutDetail from "../screens/AboutDetail/AboutDetail";
import AboutUs from "../screens/AboutUs/AboutUs";
import AddVideo from "../screens/AddVideo/AddVideo";
import AddVideoBlink from "../screens/AddVideoBlink/AddVideoBlink";
import AddVideoLong from "../screens/AddVideoLong/AddVideoLong";
import Blocklist from "../screens/Blocklist/Blocklist";
import Commentslist from "../screens/Commentslist/Commentslist";
import Reportvideo_add from "../screens/Reportvideo_add/Reportvideo_add";

import ContactUs from "../screens/ContactUs/ContactUs";
import EditProfile from "../screens/EditProfile/EditProfile";
import FAQ from "../screens/FAQ/FAQ";
import Favvideo from "../screens/Favvideo/Favvideo";
import Followerdetail from "../screens/Followerdetail/Followerdetail";
import Followerlist from "../screens/Followerlist/Followerlist";
//import GoLive from "../screens/GoLive/GoLive";
import { Home } from "../screens/Home/Home";
import Liveuserlist from "../screens/Liveuserlist/Liveuserlist";
import Membership from "../screens/Membership/Membership";
import Notifications from "../screens/Notifications/Notifications";
import Privacy from "../screens/Privacy/Privacy";
import Searchuserlist from "../screens/Searchuserlist/Searchuserlist";
import Socialinfo from "../screens/Socialinfo/Socialinfo";
import Terms from "../screens/Terms/Terms";
import UserProfile from "../screens/UserProfile/UserProfile";
import livevideo from "../screens/livevideo/livevideo";
import livevideoNew from "../screens/livevideoNew/livevideoNew";

import Changepassword from "../screens/Changepassword/Changepassword";
import Message from "../screens/Message/Message";
import Reportlist from "../screens/Reportlist/Reportlist";
import Settings from "../screens/Settings/Settings";

import ChatUSerList from "../screens/ChatUSerList/ChatUSerList";
import Selfvideolist from "../screens/Selfvideolist/Selfvideolist";
import Tutorial from "../screens/Tutorial/Tutorial";





const Stack = createNativeStackNavigator();
export function HomeNavigator() {
  return (
    <Stack.Navigator>

      <Stack.Screen
        options={{ headerShown: false }}
        name={NAVIGATION.mainHome}
        component={Home}
      />

      <Stack.Screen
        options={{ headerShown: false }}
        name={NAVIGATION.MyProfile}
        component={MyProfile}
      />
      <Stack.Screen
        options={{ headerShown: false }}
        name={NAVIGATION.Notifications}
        component={Notifications}
      />
      <Stack.Screen
        options={{ headerShown: false }}
        name={NAVIGATION.Settings}
        component={Settings}
      />

      <Stack.Screen
        options={{ headerShown: false }}
        name={NAVIGATION.livevideo}
        component={livevideo}
      />

      <Stack.Screen
        options={{ headerShown: false }}
        name={NAVIGATION.LivevideoNew}
        component={livevideoNew}
      />
      <Stack.Screen
        options={{ headerShown: false }}
        name={NAVIGATION.UserProfile}
        component={UserProfile}
      />

      <Stack.Screen
        options={{ headerShown: false }}
        name={NAVIGATION.Blocklist}
        component={Blocklist}
      />
       <Stack.Screen
        options={{ headerShown: false }}
        name={NAVIGATION.Selfvideolist}
        component={Selfvideolist}
      />
      <Stack.Screen
        options={{ headerShown: false }}
        name={NAVIGATION.EditProfile}
        component={EditProfile}
      />
      <Stack.Screen
        options={{ headerShown: false }}
        name={NAVIGATION.Followerlist}
        component={Followerlist}
      />
      <Stack.Screen
        options={{ headerShown: false }}
        name={NAVIGATION.Followerdetail}
        component={Followerdetail}
      />

      <Stack.Screen
        options={{ headerShown: false }}
        name={NAVIGATION.Favvideo}
        component={Favvideo}
      />

      <Stack.Screen
        options={{ headerShown: false }}
        name={NAVIGATION.Commentslist}
        component={Commentslist}
      />
       <Stack.Screen
        options={{ headerShown: false }}
        name={NAVIGATION.Reportvideo_add}
        component={Reportvideo_add}
      />
     
      <Stack.Screen
        options={{ headerShown: false }}
        name={NAVIGATION.AddVideo}
        component={AddVideo}
      />
      {/* <Stack.Screen
        options={{ headerShown: false }}
        name={NAVIGATION.GoLive}
        component={GoLive}
      /> */}
      <Stack.Screen
        options={{ headerShown: false }}
        name={NAVIGATION.Liveuserlist}
        component={Liveuserlist}
      />

      <Stack.Screen
        options={{ headerShown: false }}
        name={NAVIGATION.AddVideoLong}
        component={AddVideoLong}
      />
      <Stack.Screen
        options={{ headerShown: false }}
        name={NAVIGATION.AddVideoBlink}
        component={AddVideoBlink}
      />
      <Stack.Screen
        options={{ headerShown: false }}
        name={NAVIGATION.AboutUs}
        component={AboutUs}
      />
      <Stack.Screen
        options={{ headerShown: false }}
        name={NAVIGATION.ContactUs}
        component={ContactUs}
      />
      <Stack.Screen
        options={{ headerShown: false }}
        name={NAVIGATION.Privacy}
        component={Privacy}
      />
      <Stack.Screen
        options={{ headerShown: false }}
        name={NAVIGATION.Terms}
        component={Terms}
      />

      <Stack.Screen
        options={{ headerShown: false }}
        name={NAVIGATION.Socialinfo}
        component={Socialinfo}
      />

      <Stack.Screen
        options={{ headerShown: false }}
        name={NAVIGATION.AboutDetail}
        component={AboutDetail}
      />
      <Stack.Screen
        options={{ headerShown: false }}
        name={NAVIGATION.Membership}
        component={Membership}
      />

      <Stack.Screen
        options={{ headerShown: false }}
        name={NAVIGATION.FAQ}
        component={FAQ}
      />
      <Stack.Screen
        options={{ headerShown: false }}
        name={NAVIGATION.Searchuserlist}
        component={Searchuserlist}
      />

      <Stack.Screen
        options={{ headerShown: false }}
        name={NAVIGATION.Changepassword}
        component={Changepassword}
      />


      <Stack.Screen
        options={{ headerShown: false }}
        name={NAVIGATION.Reportlist}
        component={Reportlist}
      />
      <Stack.Screen
        options={{ headerShown: false }}
        name={NAVIGATION.Message}
        component={Message}
      />
      <Stack.Screen
        options={{ headerShown: false }}
        name={NAVIGATION.ChatUSerList}
        component={ChatUSerList}
      />

    <Stack.Screen
        options={{ headerShown: false }}
        name={NAVIGATION.Tutorial}
        component={Tutorial}
      />
    </Stack.Navigator>
  );
}
