import AsyncStorage from '@react-native-async-storage/async-storage';
import { useEffect, useState } from "react";
import { createNativeStackNavigator } from "react-native-screens/native-stack";
import { NAVIGATION } from "../constants";
import CreateAccount from "../screens/CreateAccount/CreateAccount";
import Forgotpassword from "../screens/Forgotpassword/Forgotpassword";
//import { Home } from "../screens/Home/Home";
import Login from "../screens/Login/Login";
import OTP from "../screens/OTP/otp";
import Privacy from "../screens/Privacy/Privacy";
import ResetPassword from "../screens/ResetPassword/ResetPassword";

//import Commentslist from "../screens/Commentslist/Commentslist";


import { AppNavigator } from "./AppNavigator";

//import Intro from "../screens/Intro/intro";

const Stack = createNativeStackNavigator();

export function AuthNavigator() {
  const [first_install, Setfirst_install] = useState("1");
  useEffect(() => {
    // alert(
    //  JSON.stringify(AsyncStorage.getItem('first_install')))
    AsyncStorage.getItem('first_install').then(async (data) => {
      //  alert(data)
      if (data) {
        // alert('data')
        Setfirst_install(data)

      }
      else {
        // alert('go')
        Setfirst_install(3)
      }
    })
  }, []);
  return (
    <Stack.Navigator>
      <Stack.Screen
        options={{ headerShown: false }}
        name={NAVIGATION.home}
        component={AppNavigator}
      />
      <Stack.Screen
        component={Login}
        name={NAVIGATION.login}
        options={{ headerShown: false }}
      />
      <Stack.Screen
        component={CreateAccount}
        name={NAVIGATION.createaccount}
        options={{ headerShown: false }}
      />
      <Stack.Screen
        component={OTP}
        name={NAVIGATION.otp}
        options={{ headerShown: false }}
      />
      <Stack.Screen
        component={Forgotpassword}
        name={NAVIGATION.forgotpassword}
        options={{ headerShown: false }}
      />

      <Stack.Screen
        component={ResetPassword}
        name={NAVIGATION.ResetPassword}
        options={{ headerShown: false }}
      />
      <Stack.Screen
        options={{ headerShown: false }}
        name={NAVIGATION.Privacy}
        component={Privacy}
      />

    </Stack.Navigator>
  );
}
