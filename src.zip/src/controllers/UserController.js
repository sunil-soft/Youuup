import AsyncStorage from '@react-native-async-storage/async-storage';
import axios from "axios";
import { showMessage } from "react-native-flash-message";
import { HttpClient } from "./HttpClient";
export class UserController {
  static async register(data) {
    return new Promise((resolve, reject) => {
      const endpoint = "user/register";
      const body = data;
      console.log('body111', body)
      HttpClient.post(endpoint, body)
        .then((response) => {
          console.log("res create account values", response);
          resolve(response);
        })
        .catch((error) => {
          reject(new Error(error.error.message));
        });
    });
  }

  static async Editprofilesave(data) {
    return new Promise((resolve, reject) => {
      const endpoint = "user/update-profile";
      console.log(endpoint)
      const body = data;
        AsyncStorage.getItem('auth_token').then(async (data2) => {
     
      HttpClient.setAuthorization(data2);
   
      HttpClient.post(endpoint, body)
        .then((response) => {
          console.log("res create shifts values", response);
          resolve(response);
          showMessage({
            message: "Tu perfil actualizado con éxito",
            type: "success",
          });
        })
        .catch((error) => {
         
          showMessage({
            message: error.message,
            type: "danger",
          });
          reject(error)
          //alert(JSON.stringify(error))
          console.log("error of create shifts", error);
          // reject(new Error(error));
        });
      })
    });
  }
  static async resetpasswordsave(data) {
    return new Promise((resolve, reject) => {
      const endpoint = "user/reset-password";
      console.log(endpoint)
      const body = data;
      HttpClient.post(endpoint, body)
        .then((response) => {
          console.log("res create shifts values", response);
          resolve(response);
          showMessage({
            message: response.message,
            type: "success",
          });
        })
        .catch((error) => {
          //  alert(error.msg)
          console.log("error of create shifts", error);
          // reject(new Error(error));
        });
    });
  }

  static async forgotpasswordsave(data) {
    return new Promise((resolve, reject) => {
      const endpoint = "user/forgot-password";
      console.log(endpoint)
      const body = data;
      HttpClient.post(endpoint, body)
        .then((response) => {
          console.log("res ", response);
          resolve(response);
          showMessage({
            message: response.message,
            type: "success",
          });
        })
        .catch((error) => {
        //  alert(error.message)
          showMessage({
            message: error.message,
            type: "danger",
          });
          // console.log("error of create shifts", error);
          // reject(new Error(error));
        });
    });
  }

  static async updateshift(data, id) {
    return new Promise((resolve, reject) => {
      const endpoint = "shifts/update/" + id;
      console.log(endpoint)
      const body = data;
      HttpClient.patch(endpoint, body)
        .then((response) => {
          console.log("res updateshift values", response);
          resolve(response);
          showMessage({
            message: "Successfully updated shift details",
            type: "success",
          });
        })
        .catch((error) => {
          alert(error.msg)
          console.log("error of updateshift", error);
          // reject(new Error(error));
        });
    });
  }
  static async updatejobstatus(data, id) {
    return new Promise((resolve, reject) => {
      const endpoint = "jobs/update/status/" + id;
      console.log(endpoint)
      const body = data;
      HttpClient.patch(endpoint, body)
        .then((response) => {
          console.log("res updatejobstatus values", response);
          resolve(response);
          showMessage({
            message: "Successfully updated job status",
            type: "success",
          });
        })
        .catch((error) => {
        //  alert(error.msg)
          console.log("error of updatejobstatus", error);
          // reject(new Error(error));
        });
    });
  }

  static async notificationmark(data, id) {
    return new Promise((resolve, reject) => {
      const endpoint = "notifications/" + id;
      console.log(endpoint)
      const body = data;
      HttpClient.patch(endpoint, body)
        .then((response) => {
          console.log("res notificationmark values", response);
          // resolve(response);

        })
        .catch((error) => {
          //  alert(error.msg)
          console.log("error of updatejobstatus", error);
          //  // reject(new Error(error));
        });
    });
  }
  static async updatenotification(data, id) {
    return new Promise((resolve, reject) => {
      const endpoint = "user_settings/" + id;
      //console.log(endpoint)
      const body = data;
      HttpClient.patch(endpoint, body)
        .then((response) => {
          console.log("res create shifts values", response.msg);
          resolve(response);
          showMessage({
            message: response.msg,
            type: "success",
          });
        })
        .catch((error) => {
          alert(error.msg)
          console.log("error of create shifts", error);
          // reject(new Error(error));
        });
    });
  }

  static async GetOtPRequestt(data, resetpass) {
    return new Promise((resolve, reject) => {
      const endpoint = "user/otp-verify";
      const body = data;
      HttpClient.post(endpoint, body)
        .then((response) => {
          // console.log("response of token", JSON.stringify(response));
          {
            // showMessage({
            //   message: "OTP matched",
            //   type: "success",
            // });
          }

          resolve(response);

        })
        .catch((error) => {
          //alert(error)
          console.log("error of create account", error.message);
          console.log("error of create account", error.message);
          {
            showMessage({
              message: error.message,
              type: "danger",
            });
          }
        });
    });
  }
  static async GetOtPresendRequestt(data) {
    return new Promise((resolve, reject) => {
      const endpoint = "user/resend-otp";
      const body = data;
      HttpClient.post(endpoint, body)
        .then((response) => {
          showMessage({
            message: 'Reenvío de OTP con éxito',
            type: "success",
          });
          resolve(response);
        })
        .catch((error) => {
          {
            showMessage({
              message: "Correo no enviado, el correo está desgastado o hay algún error",
              type: "danger",
            });
          }
        });
    });
  }
  static async login(data) {
    return new Promise((resolve, reject) => {
      const endpoint = "user/login";
      const body = data;
      HttpClient.post(endpoint, body)
        .then((response) => {
          console.log("res  account values", response);
          resolve(response);
        })
        .catch((error) => {
          // alert(error.msg)
          console.log('dfd',error)

          reject(error);
        });
    });
  }
  // static async addskills(skills) {
  //   return new Promise((resolve, reject) => {
  //     setTimeout(async () => {
  //       // const endpoint = ApiInventory.baseUrl + '' + ApiInventory.registerUser;
  //       const endpoint = "user_skills";
  //       const body = {
  //         skill: skills[0]
  //       };
  //       console.log(body)
  //       HttpClient.post(endpoint, body)
  //         .then((response) => {
  //           console.log("res create account values", response);
  //           resolve(response);
  //         })
  //         .catch((error) => {
  //           alert(error.msg)
  //           console.log("error of create account", error);
  //           // reject(new Error(error));
  //         });
  //     }, 500);
  //   });
  // }
  static async getRoles() {
    return new Promise((resolve, reject) => {
      const endpoint = "designation";

      HttpClient.get(endpoint)
        .then((response) => {
          console.log("res", response.payload);
          resolve(response.payload);
        })
        .catch((error) => {
          console.log("error", error);
        });
    });
  }

  static async getnotification() {
    return new Promise((resolve, reject) => {
      const endpoint = "notifications";

      HttpClient.get(endpoint)
        .then((response) => {
          console.log("notifications", response.payload);
          resolve(response.payload);
        })
        .catch((error) => {
          console.log("error", error);
        });
    });
  }
  static async aboutus() {
    return new Promise((resolve, reject) => {
      const endpoint = "aboutus/about";

      HttpClient.get(endpoint)
        .then((response) => {
          console.log("site", response?.aboutUs);
          resolve(response?.aboutUs);
        })
        .catch((error) => {
          console.log("error", error);
        });
    });
  }
  static async faq() {
    return new Promise((resolve, reject) => {
      const endpoint = "faq/list";

      HttpClient.get(endpoint)
        .then((response) => {
          console.log("faq", response?.faq);
          resolve(response?.faq);
        })
        .catch((error) => {
          console.log("error", error);
        });
    });
  }

  static async uploadImage(data) {
    return new Promise((resolve, reject) => {
      axios({
        url: "",

        method: "POST",

        data: data,

        headers: {
          "Content-Type": "multipart/form-data",
          Accept: "application/json",
        },
      })
        .then((resp) => {
          console.log("gauravimage", resp.data.payload.url);
          // resolve(resp.data.payload.url);
        })
        .catch((error) => console.error("opdioeueo", error));
    });
  }
  static async MyProfileRequesttt() {
    return new Promise((resolve, reject) => {
      const endpoint = "user/user-profile";
     //console.log('HttpClient',HttpClient.get())
     AsyncStorage.getItem('auth_token').then(async (data2) => {
      HttpClient.setAuthorization(data2);
     // console.log("ProfileTokenHttpClient",data)
   
 
      HttpClient.get(endpoint)
        .then((response) => {
          console.log("responffffse MyProfile", response);
          resolve(response.user);
        })
        .catch((error) => {
           reject(error);
          console.log("error of MyProfile response", error);
        });
      })
    });
  }

  static async Createrprofileget(data) {
    return new Promise((resolve, reject) => {
      const endpoint = "user/creator-profile";
      const body = data;
      HttpClient.post(endpoint, body)
        .then((response) => {
          console.log("responffffse", response);
          resolve(response.creator_profile);
        })
        .catch((error) => {
          console.log("error of Createrprofile response", error);
        });
    });
  }


  static async followerslistget(data) {
    return new Promise((resolve, reject) => {
      const endpoint = "user/follow-list";
      const body = data;
      AsyncStorage.getItem('auth_token').then(async (data2) => {
      HttpClient.setAuthorization(data2);
      HttpClient.post(endpoint, body)
        .then((response) => {
         
          console.log("responffff11", response);
          if (data.follow_status == 1) {
            console.log("responffff11", response.followings);

            resolve(response.followings);
          }
          else {
           console.log("responffff22", response.followers);

            resolve(response.followers);
          }
          // resolve(response.creator_profile);
        })
        .catch((error) => {
          reject(error)
          console.log("error of followerslistget response", error);
        });
      });
    });
  }


  static async blocklistapiget() {
    return new Promise((resolve, reject) => {
      const endpoint = "block/block-user-list";
      //  const body = data;
      AsyncStorage.getItem('auth_token').then(async (data2) => {
        HttpClient.setAuthorization(data2);
      HttpClient.get(endpoint)
        .then((response) => {
          resolve(response.blockUserList);
          // resolve(response.creator_profile);
        })
        .catch((error) => {
          reject(error)
          console.log("error of response", error);
        });
      });
    });
  }

  static async reportlistapiget() {
    return new Promise((resolve, reject) => {
      const endpoint = "report/list";
      //  const body = data;
      AsyncStorage.getItem('auth_token').then(async (data) => {
        HttpClient.setAuthorization(data);
        HttpClient.get(endpoint)
        .then((response) => {
          //console.log('erer', response.result)
          resolve(response.result);
          // resolve(response.creator_profile);
        })
        .catch((error) => {
          reject(error)
          console.log("error of response", error);
        });
      });
    });
  }
  static async Creatervideos(data) {
    return new Promise((resolve, reject) => {
      const endpoint = "video/video-by-user";
      const body = data;
      AsyncStorage.getItem('auth_token').then(async (data2) => {
        
        // console.log(data)
        HttpClient.setAuthorization(data2);
     
      HttpClient.post(endpoint, body)
        .then((response) => {
          console.log("responffffseCreatervideos", response.videos);
          resolve(response.videos);
        })
        .catch((error) => {

          console.log(error.message)
          reject(error)
          console.log("error of Creatervideos response", error);
        });
      })
    });
  }

  static async favvideos() {
    return new Promise((resolve, reject) => {
      const endpoint = "video/favourite-list";
      // const body = data;
      AsyncStorage.getItem('auth_token').then(async (data2) => {
        HttpClient.setAuthorization(data2);
      HttpClient.get(endpoint)
        .then((response) => {
           console.log("responffffsefavvideos", response.data);
          resolve(response.data);
        })
        .catch((error) => {
          //console.log("error of Creatervideos response", error);
        });
      });
    });
  }
  // static async allshiftsapi() {
  //   return new Promise((resolve, reject) => {
  //     const endpoint = "shifts";

  //     HttpClient.get(endpoint)
  //       .then((response) => {
  //         console.log("responffffse shifts", response);
  //         resolve(response);
  //       })
  //       .catch((error) => {
  //         console.log("error of shifts response", error);
  //       });
  //   });
  // }

  // static async shiftsdetail(id) {
  //   return new Promise((resolve, reject) => {
  //     const endpoint = "shifts/details/" + id;

  //     HttpClient.get(endpoint)
  //       .then((response) => {
  //         console.log("responffffse shifts", response);
  //         resolve(response);
  //       })
  //       .catch((error) => {
  //         console.log("error of shifts response", error);
  //       });
  //   });
  // }

  // static async shiftsdeleteapi(id) {
  //   return new Promise((resolve, reject) => {
  //     const endpoint = "shifts/" + id;

  //     HttpClient.delete(endpoint)
  //       .then((response) => {
  //         console.log("responffffse shiftsdeleteapi", response);
  //         resolve(response);
  //       })
  //       .catch((error) => {
  //         console.log("error of shiftsdeleteapi response", error);
  //       });
  //   });
  // }
  static async updateProfileRequesttt(data, id) {
    return new Promise((resolve, reject) => {
      console.log("body", id);
      const endpoint = "user_profiles/" + id;
      const body = data;
      HttpClient.patch(endpoint, body)
        .then((response) => {
          console.log("response", response);
          {
            showMessage({
              message: "Successfully updated user profile details",
              type: "success",
            });
          }
          resolve(response);
        })
        .catch((error) => {
          console.log("error of updateProfile response", error.response.data);
        });
    });
  }
  static async logout() {
    return new Promise((resolve) => {
      setTimeout(resolve, 500);
    });
  }
}
