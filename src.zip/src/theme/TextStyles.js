import { StyleSheet } from "react-native";
import { moderateScale } from "react-native-size-matters";
import { FONTS } from "../theme/fonts";
export const TextStyles = StyleSheet.create({
  title: {
    fontSize: 28,
    // fontWeight: '700',
    fontFamily: FONTS.PoppinsRegular,
    color: "#FFFFFF",
  //  marginTop:10,
    alignSelf:'center'
  },
  titlelogin:
  {
    fontSize: 28,
    fontWeight: '600',
    fontFamily: FONTS.PoppinsRegular,
    color: "#08DDFD",
    marginTop:10,
    alignSelf:'flex-start',
    marginLeft:30,
  },
  
  subtitle:
  {
    fontSize: 14,
    // fontWeight: '700',
    fontFamily: FONTS.PoppinsRegular,
    color: "white",
   // marginTop:10,
   marginBottom:20,
    alignSelf:'flex-start',
    marginLeft:32,
  },
  titledis:
  {
    fontSize: 14,
    // fontWeight: '700',
    fontFamily: FONTS.PoppinsRegular,
    color: "#E6E6E6",
    marginTop:10,
    alignSelf:'flex-start',
    marginLeft:10,
  },
  
  titlereg:
  {
    fontSize: 12,
    // fontWeight: '700',
    fontFamily: FONTS.PoppinsRegular,
    color: "#08DDFD",
    alignSelf:'flex-start',
    marginLeft:40,
  },
  titlereglabel:
  {
    fontSize: 28,
    // fontWeight: '700',
    fontFamily: FONTS.PoppinsRegular,
    color: "#08DDFD",
    alignSelf:'flex-start',
    marginLeft:10,
  },
  forgotlabel:
  {
    fontSize: 13,
    // fontWeight: '700',
    fontFamily: FONTS.PoppinsRegular,
    color: "#08DDFD",
   // alignSelf:'flex-start',
    textAlign:'left'

  },
  
  light: {
    justifyContent:'center',
    alignContent:'center',
    textAlign:'center',
    color: "#E6E6E6",
    fontSize: moderateScale(14),
    fontWeight: "400",
    fontFamily: FONTS.PoppinsRegular,
    width:'90%',
    marginTop:60,
    paddingLeft:40,
    paddingRight:40
  },
  resendlable: {
    justifyContent:'center',
    alignContent:'center',
    textAlign:'center',
    color: "#E6E6E6",
    fontSize: moderateScale(14),
    fontWeight: "400",
    fontFamily: FONTS.PoppinsRegular,
   // width:'90%',
  //  paddingLeft:40,
    paddingRight:1
  },
  light2: {
    justifyContent:'center',
    alignContent:'center',
    textAlign:'center',
    color: "#E6E6E6",
    fontSize: moderateScale(14),
    fontWeight: "400",
    fontFamily: FONTS.PoppinsRegular,
    //width:'90%',
    marginTop:10
  },
  terms:
  {
    justifyContent:'center',
    alignContent:'center',
    textAlign:'center',
    color: "#E6E6E6",
    fontSize: moderateScale(14),
    fontWeight: "400",
    fontFamily: FONTS.PoppinsRegular,
    marginTop:20
    //width:'90%',
  },
  text: {
    fontSize: 16,
    fontWeight: "400",
    fontFamily: FONTS.PoppinsRegular,
  },
  label: {
    fontSize: 16,
    fontWeight: "700",
    fontFamily: FONTS.PoppinsRegular,
  },
  error: {
    fontSize: 14,
    fontWeight: "400",
  },
});
