export const FONTS = {
  PoppinsRegular: 'Poppins-Regular',
  PoppinsMedium: 'Poppins-Medium',
  PoppinsBold: 'Poppins-Bold',
  PoppinsLight: 'Poppins-Light',
  PoppinsSemiBold: 'Poppins-SemiBold',
  PTSerif: 'PTSerif-Regular',
  PTBold: 'PTSerif-Bold',
  PTSerifItalic:'PTSerif-Italic'
};
