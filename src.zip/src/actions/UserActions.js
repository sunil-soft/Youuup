import { HttpClient, UserController } from "@/controllers";
import AsyncStorage from '@react-native-async-storage/async-storage';
import { showMessage } from "react-native-flash-message";
import { NAVIGATION } from "../constants";

import { goBack, navigate } from "../navigation/NavigationRef";
export const TYPES = {
  CLEAR_STORE: "CLEAR_STORE",
  LOGIN: "LOGIN",
  LOGIN_REQUEST: "LOGIN_REQUEST",
  LOGIN_ERROR: "LOGIN_ERROR",
  LOGIN_SUCCESS: "LOGIN_SUCCESS",
  REGISTER_REQUEST: "REGISTER_REQUEST",
  REGISTER_ERROR: "REGISTER_ERROR",
  REGISTER_SUCCESS: "REGISTER_SUCCESS",
  GET_ROLES_SUCCESS: "GET_ROLES_SUCCESS",
  GET_ROLES_REQUEST: "GET_ROLES_REQUEST",
  GET_ROLES_ERROR: "GET_ROLES_ERROR",

  Aboutus_SUCCESS: 'Aboutus_SUCCESS',
  Aboutus_ERROR: 'Aboutus_ERROR',

  IMAGE_UPLOAD_REQUEST: "IMAGE_UPLOAD_REQUEST",
  IMAGE_UPLOAD_SUCCESS: "IMAGE_UPLOAD_SUCCESS",
  IMAGE_UPLOAD_ERROR: "IMAGE_UPLOAD_ERROR",
  Addskills_REQUEST: "Addskills_REQUEST",
  Addskills_ERROR: "Addskills_ERROR",
  Addskills_SUCCESS: "Addskills_SUCCESS",
  OTP_REQUEST: "OTP_REQUEST",
  OTP_SUCCESS: "OTP_SUCCESS",
  OTP_ERROR: "OTP_ERROR",
  OTP_RESEND_ERROR: "OTP_RESEND_ERROR",
  OTP_RESEND_SUCCESS: "OTP_RESEND_SUCCESS",
  OTP_RESEND_REQUEST: "OTP_RESEND_REQUEST",
  Myprofile_REQUEST: 'Myprofile_REQUEST',
  Myprofile_SUCCESS: 'Myprofile_SUCCESS',
  Myprofile_ERROR: 'Myprofile_ERROR',
  shift_REQUEST: 'shift_REQUEST',
  shift_ERROR: 'shift_ERROR',
  shift_SUCCESS: "shift_SUCCESS",
  Editprofile_REQUEST: 'Editprofile_REQUEST',
  Editprofile_SUCCESS: "Editprofile_SUCCESS",
  Editprofile_ERROR: 'Editprofile_ERROR',
  Allshift_SUCCESS: 'Allshift_SUCCESS',
  Allshift_ERROR: 'Allshift_ERROR',
  updatenotification_REQUEST: 'updatenotification_REQUEST',
  updatenotification_SUCCESS: 'updatenotification_SUCCESS',
  getnotification_REQUEST: 'getnotification_REQUEST',
  getnotification_SUCCESS: 'getnotification_SUCCESS',
  getnotification_ERROR: 'getnotification_ERROR',
  shiftdetail_SUCCESS: 'shiftdetail_SUCCESS',
  shiftdetail_ERROR: 'shiftdetail_ERROR',
  updateshift_REQUEST: 'updateshift_REQUEST',
  updatejobstatus_REQUEST: 'updatejobstatus_REQUEST',
  updatejobstatus_SUCCESS: 'updatejobstatus_SUCCESS',
  resetpassword_REQUEST: 'resetpassword_REQUEST',
  resetpassword_SUCCESS: 'resetpassword_SUCCESS',
  forgotpassword_REQUEST: 'forgotpassword_REQUEST',
  forgotpassword_SUCCESS: 'forgotpassword_SUCCESS',
  Createrprofile_ERROR: 'Userprofile_ERROR',
  Createrprofile_SUCCESS: 'Userprofile_SUCCESS',
  Creatervideos_ERROR: 'Creatervideos_ERROR',
  Creatervideos_SUCCESS: 'Creatervideos_SUCCESS',
  followerslist_SUCCESS: 'followerslist_SUCCESS',
  followerslist_ERROR: 'followerslist_ERROR',
  favvideos_SUCCESS: 'favvideos_SUCCESS',
  favvideos_ERROR: 'favvideos_ERROR',
  faq_ERROR: 'faq_ERROR',
  faq_SUCCESS: 'faq_SUCCESS',
  blocklist_SUCCESS: 'blocklist_SUCCESS',
  blocklist_ERROR: 'blocklist_ERROR',
  reportlist_SUCCESS: 'reportlist_SUCCESS',
  reportlistapi_ERROR: 'reportlistapi_ERROR'
};

const loginRequest = () => ({
  type: TYPES.LOGIN_REQUEST,
  payload: null,
});

const loginError = (error) => ({
  type: TYPES.LOGIN_ERROR,
  payload: { error },
});

const loginSuccess = (user) => ({
  type: TYPES.LOGIN_SUCCESS,
  payload: { user },
});

const registerRequest = () => ({
  type: TYPES.REGISTER_REQUEST,
  payload: null,
});

const registerError = (error) => ({
  type: TYPES.REGISTER_ERROR,
  payload: { error },
});

const registerSuccess = (user) => ({
  type: TYPES.REGISTER_SUCCESS,
  payload: { user },
});
const addskillsRequest = () => ({
  type: TYPES.Addskills_REQUEST,
  payload: null,
});
const addskillsError = (error) => ({
  type: TYPES.Addskills_ERROR,
  payload: { error },
});
const addskillsSuccess = (user) => ({
  type: TYPES.Addskills_SUCCESS,
  payload: { user },
});
const shiftdetailError = (error) => ({
  type: TYPES.shiftdetail_ERROR,
  payload: { error },
});
const shiftdetailSuccess = (user) => ({
  type: TYPES.shiftdetail_SUCCESS,
  payload: { user },
});
const MyprofileRequest = () => ({
  type: TYPES.Myprofile_REQUEST,
  payload: null,
});
const MyprofileError = (error) => ({
  type: TYPES.Myprofile_ERROR,
  payload: { error },
});
const MyprofileSuccess = (user) => ({
  type: TYPES.Myprofile_SUCCESS,
  payload: { user },
});

const CreaterprofileError = (error) => ({
  type: TYPES.Createrprofile_ERROR,
  payload: { error },
});
const CreaterprofileSuccess = (user) => ({
  type: TYPES.Createrprofile_SUCCESS,
  payload: { user },
});



const followerslistError = (error) => ({
  type: TYPES.followerslist_ERROR,
  payload: { error },
});
const followerslistSuccess = (user) => ({
  type: TYPES.followerslist_SUCCESS,
  payload: { user },
});

const blocklistapiError = (error) => ({
  type: TYPES.blocklist_ERROR,
  payload: { error },
});
const blocklistapiSuccess = (user) => ({
  type: TYPES.blocklist_SUCCESS,
  payload: { user },
});


const CreatervideosError = (error) => ({
  type: TYPES.Creatervideos_ERROR,
  payload: { error },
});
const CreatervideosSuccess = (user) => ({
  type: TYPES.Creatervideos_SUCCESS,
  payload: { user },
});

const favvideosError = (error) => ({
  type: TYPES.favvideos_ERROR,
  payload: { error },
});
const favvideosSuccess = (user) => ({
  type: TYPES.favvideos_SUCCESS,
  payload: { user },
});

const getnotificationRequest = () => ({
  type: TYPES.getnotification_REQUEST,
  payload: null,
});
const getnotificationError = (error) => ({
  type: TYPES.getnotification_ERROR,
  payload: { error },
});
const getnotificationSuccess = (user) => ({
  type: TYPES.getnotification_SUCCESS,
  payload: { user },
});

const allshiftError = (error) => ({
  type: TYPES.Allshift_ERROR,
  payload: { error },
});
const allshiftSuccess = (user) => ({
  type: TYPES.Allshift_SUCCESS,
  payload: { user },
});

const getRolesRequest = () => ({
  type: TYPES.GET_ROLES_REQUEST,
  payload: null,
});

const getRolesError = (error) => ({
  type: TYPES.GET_ROLES_ERROR,
  payload: { error },
});

const getRolesSuccess = (user) => ({
  type: TYPES.GET_ROLES_SUCCESS,
  payload: { user },
});




const aboutusError = (error) => ({
  type: TYPES.Aboutus_ERROR,
  payload: { error },
});
const aboutusSuccess = (user) => ({
  type: TYPES.Aboutus_SUCCESS,
  payload: { user },
});


const reportlistapiSuccess = (user) => ({
  type: TYPES.reportlist_SUCCESS,
  payload: { user },
});
const reportlistapiError = (error) => ({
  type: TYPES.reportlistapi_ERROR,
  payload: { error },
});

const faqError = (error) => ({
  type: TYPES.faq_ERROR,
  payload: { error },
});
const faqSuccess = (user) => ({
  type: TYPES.faq_SUCCESS,
  payload: { user },
});

const imageUploadRequest = () => ({
  type: TYPES.IMAGE_UPLOAD_REQUEST,
  payload: null,
});
const imageUploadSuccess = (uploadphoto) => ({
  type: TYPES.IMAGE_UPLOAD_SUCCESS,
  payload: { uploadphoto },
});
const imageUploadError = () => ({
  type: TYPES.IMAGE_UPLOAD_ERROR,
  payload: user,
});
const OtpError = (error) => ({
  type: TYPES.OTP_ERROR,
  payload: { error },
});
const OtpRequest = (user) => ({
  type: TYPES.OTP_REQUEST,
  payload: { user },
});
const OtpSuccess = (user) => ({
  type: TYPES.OTP_SUCCESS,
  payload: { user },
});
const OtpResendError = (error) => ({
  type: TYPES.OTP_RESEND_ERROR,
  payload: { error },
});
const OtpresendRequest = (user) => ({
  type: TYPES.OTP_RESEND_REQUEST,
  payload: { user },
});
const OtpResendSuccess = (user) => ({
  type: TYPES.OTP_RESEND_SUCCESS,
  payload: { user },
});
const clearStore = () => ({
  type: TYPES.CLEAR_STORE,
  payload: null,
});
const shiftRequest = () => ({
  type: TYPES.shift_REQUEST,
  payload: null,
});

const shiftError = (error) => ({
  type: TYPES.shift_ERROR,
  payload: { error },
});

const shiftSuccess = (successdata) => ({
  type: TYPES.shift_SUCCESS,
  payload: { successdata },
});
const editprofileRequest = () => ({
  type: TYPES.Editprofile_REQUEST,
  payload: null,
});

const resetpasswordRequest = () => ({
  type: TYPES.resetpassword_REQUEST,
  payload: null,
});
const resetpasswordSuccess = (user) => ({
  type: TYPES.resetpassword_SUCCESS,
  payload: { user },
});

const forgotpasswordRequest = () => ({
  type: TYPES.forgotpassword_REQUEST,
  payload: null,
});
const forgotpasswordSuccess = (user) => ({
  type: TYPES.forgotpassword_SUCCESS,
  payload: { user },
});

const editprofileError = (error) => ({
  type: TYPES.Editprofile_ERROR,
  payload: { error },
});

const editprofileSuccess = (user) => ({
  type: TYPES.Editprofile_SUCCESS,
  payload: { user },
});

const updatenotificationRequest = () => ({
  type: TYPES.updatenotification_REQUEST,
  payload: null,
});
const updatenotificationSuccess = (user) => ({
  type: TYPES.updatenotification_SUCCESS,
  payload: { user },
});
const updatejobstatusRequest = () => ({
  type: TYPES.updatejobstatus_REQUEST,
  payload: null,
});
const updatejobstatusSuccess = (user) => ({
  type: TYPES.updatejobstatus_SUCCESS,
  payload: { user },
});
const updateshiftRequest = () => ({
  type: TYPES.updateshift_REQUEST,
  payload: null,
});
export const login = (data) => async (dispatch) => {
  //AsyncStorage.removeItem('auth_token')
  dispatch(loginRequest());
  try {
    const user = await UserController.login(data);
    console.log('userdagta Response', user)
    console.log('Login', user)
    console.log('otp_verify', user.user.otp_verify)

    if (!user.user.otp_verify) {
      navigate(NAVIGATION.otp, { data: data })
    }
    else {
      dispatch(loginSuccess(user));
      console.log('login tokrn', user.accessToken)
      AsyncStorage.setItem('auth_token', user.accessToken)
      //navigate(NAVIGATION.home)
    }
  } catch (error) {
    console.log("error of  account1", error.message);
    //console.log("error of  account1", error.message);
    //  console.log("error of  account", error);
if(error.message=="your profile is locked, Please contact your administrator")
{
  showMessage({
    message: 'Su perfil está bloqueado, póngase en contacto con su administrador',
    type: "danger",
  });
}
else{
    showMessage({
      message: 'Correo electrónico / contraseña no válida',
      type: "danger",
    });
  }
  }
};

export const Myprofile = () => async (dispatch) => {
  dispatch(MyprofileRequest());
  try {
    //  AsyncStorage.getItem('auth_token').then(async (data) => {
    //    console.log("ProfileToken",data)
    //   HttpClient.setAuthorization(data);
    // })
      const user = await UserController.MyProfileRequesttt();
      console.log('fdf',user)
      dispatch(MyprofileSuccess(user));
   

    // AsyncStorage.setItem('auth_token',user.payload.token)
    //  navigate(NAVIGATION.EditUserDetail);

  } catch (error) {
    //alert(error.message)
  //console.log(error.message)
   if(error.message=='Unauthorized')
   {
    dispatch(logout());
   }
   // dispatch(MyprofileError(error));
  }
};
export const popupoff = () => async (dispatch) => {
  dispatch(loginError(''))

};
export const GetOtPRequestt = (data, resetpass) => async (dispatch) => {
  dispatch(OtpRequest());
  console.log("otp request");
  try {
    const user = await UserController.GetOtPRequestt(data, resetpass);
    console.log('userotp', user)
    AsyncStorage.setItem('auth_token', user.accessToken)
    if (resetpass != 1) {
      dispatch(OtpSuccess(user));
    }
    if (resetpass == 1) {
      navigate(NAVIGATION.ResetPassword, { dataroot: user ? user.user.id : '' });
    }
    else {
      navigate(NAVIGATION.home);
    }
  } catch (error) {
    dispatch(OtpResendError(error.message));
  }
};

export const resendOtp = (data) => async (dispatch) => {
  dispatch(OtpresendRequest());
  try {
    const user = await UserController.GetOtPresendRequestt(data);
    dispatch(OtpResendSuccess(user));
  } catch (error) {
    dispatch(OtpError(error.message));
  }
};
export const register = (data) => async (dispatch) => {
  // AsyncStorage.removeItem('auth_token')
  dispatch(registerRequest());
  console.log("data", data);
  try {
    const user = await UserController.register(data);
    console.log('user', user)
    navigate(NAVIGATION.otp, { data: data })
  } catch (error) {
    alert(error.message)
    //  dispatch(registerError(error.message));
  }
};
export const resetpassword = (data) => async (dispatch) => {
  dispatch(resetpasswordRequest());
  try {
    // AsyncStorage.getItem('auth_token').then(async (data22) => {
    //console.log(data22)
    // HttpClient.setAuthorization(data22);
    const userdata = await UserController.resetpasswordsave(data);
    //goBack()
    navigate(NAVIGATION.login)

    dispatch(resetpasswordSuccess(userdata));
    //  })

  } catch (error) {
    alert(error.message)
    // dispatch(editprofileError(error.message));
  }
};

export const forgotpasswordsave = (data) => async (dispatch) => {
  dispatch(forgotpasswordRequest());
  try {
    // AsyncStorage.getItem('auth_token').then(async (data22) => {
    //console.log(data22)
    // HttpClient.setAuthorization(data22);
    const userdata = await UserController.forgotpasswordsave(data);
    navigate(NAVIGATION.otp, { data: data, resetpass: 1 })
    //goBack()
    dispatch(forgotpasswordSuccess(userdata));
    //  })

  } catch (error) {
    alert(error.message)
    // dispatch(editprofileError(error.message));
  }
};
export const editprofileapi = (data) => async (dispatch) => {
  dispatch(editprofileRequest());
  try {
   // AsyncStorage.getItem('auth_token').then(async (data22) => {
      // console.log(data22)
     // HttpClient.setAuthorization(data22);
      const userdata = await UserController.Editprofilesave(data);
      
      dispatch(editprofileSuccess(userdata));
      goBack()
   // })

  } catch (error) {
   // alert('fdf')
   if(error.message=='Unauthorized')
   {
    dispatch(logout());
   }
   // dispatch(editprofileError(error.message));
  }
};

export const updatenotificationapi = (data, uid) => async (dispatch) => {
  dispatch(updatenotificationRequest());
  try {
    AsyncStorage.getItem('auth_token').then(async (data22) => {
      console.log(data22)
      HttpClient.setAuthorization(data22);
      const userdata = await UserController.updatenotification(data, uid);
      //  goBack()
      dispatch(updatenotificationSuccess(userdata));
    })

  } catch (error) {
    alert(error.message)
    // dispatch(updatenotificationError(error.message));
  }
};

export const updatejobstatus = (data, notifyid, id) => async (dispatch) => {
  dispatch(updatejobstatusRequest());
  try {
    AsyncStorage.getItem('auth_token').then(async (data22) => {
      console.log(data22)
      console.log(data)
      HttpClient.setAuthorization(data22);
      const userdata = await UserController.updatejobstatus(data, id);
      if (userdata) {
        dispatch(notificationmark(notifyid));
      }
      if (data.status == 5) {
        goBack()
      }
      dispatch(updatejobstatusSuccess(userdata));
    })

  } catch (error) {
    alert(error.message)
    // dispatch(updatenotificationError(error.message));
  }
};
export const notificationmark = (id) => async (dispatch) => {
  // dispatch(updatejobstatusRequest());
  try {
    AsyncStorage.getItem('auth_token').then(async (data22) => {
      console.log(data22)
      HttpClient.setAuthorization(data22);
      const data = {
        "is_read": 1
      };
      const userdata = await UserController.notificationmark(data, id);

      // dispatch(updatejobstatusSuccess(userdata));
    })

  } catch (error) {
    alert(error.message)
    // dispatch(updatenotificationError(error.message));
  }
};
export const shifteditapi = (data, id) => async (dispatch) => {
  dispatch(updateshiftRequest());
  try {
    AsyncStorage.getItem('auth_token').then(async (data22) => {
      console.log(data22)
      HttpClient.setAuthorization(data22);
      const userdata = await UserController.updateshift(data, id);
      goBack()
      // dispatch(updatenotificationSuccess(userdata));
    })

  } catch (error) {
    alert(error.message)
    // dispatch(updatenotificationError(error.message));
  }
};
// export const addskills = (data) => async (dispatch) => {
//   AsyncStorage.getItem('auth_token').then(async (data) => {
//     //alert(data)
//     HttpClient.setAuthorization(data);
//   })
//   dispatch(addskillsRequest());
//   //console.log("data", data);
//   try {
//     const user = await UserController.addskills(data);
//     // AsyncStorage.setItem('auth_token',user.payload.token)
//     //  navigate(NAVIGATION.EditUserDetail);
//     dispatch(addskillsSuccess(user));
//   } catch (error) {
//     alert(error.message)
//     dispatch(addskillsError(error.message));
//   }
// };


export const Createrprofileapi = (datareq) => async (dispatch) => {

  try {
    AsyncStorage.getItem('auth_token').then(async (data) => {
      HttpClient.setAuthorization(data);
      const user = await UserController.Createrprofileget(datareq);
      dispatch(CreaterprofileSuccess(user));
    })

    // AsyncStorage.setItem('auth_token',user.payload.token)
    //  navigate(NAVIGATION.EditUserDetail);

  } catch (error) {
    // alert(error.message)
    //dispatch(CreaterprofileError(error.message));
  }
};

export const followerlistapi = (datareq) => async (dispatch) => {

  try {
    // AsyncStorage.getItem('auth_token').then(async (data) => {
    //   HttpClient.setAuthorization(data);
    // })
      const user = await UserController.followerslistget(datareq);
      dispatch(followerslistSuccess(user));
   

    // AsyncStorage.setItem('auth_token',user.payload.token)
    //  navigate(NAVIGATION.EditUserDetail);

  } catch (error) {
    // alert(error.message)
    if(error.message=='Unauthorized')
    {
     dispatch(logout());
    }
    dispatch(followerslistError(error.message));
  }
};

export const blocklistapi = () => async (dispatch) => {

  try {
    // AsyncStorage.getItem('auth_token').then(async (data) => {
      
    //   HttpClient.setAuthorization(data);
    // })
      const user = await UserController.blocklistapiget();
      dispatch(blocklistapiSuccess(user));
   

    // AsyncStorage.setItem('auth_token',user.payload.token)
    //  navigate(NAVIGATION.EditUserDetail);

  } catch (error) {
    // alert(error.message)
    if(error.message=='Unauthorized')
    {
     dispatch(logout());
    }
    dispatch(blocklistapiError(error.message));
  }
};


export const Reportedlistapi = () => async (dispatch) => {

  try {
    // AsyncStorage.getItem('auth_token').then(async (data) => {
    //   HttpClient.setAuthorization(data);
    // })
      const user = await UserController.reportlistapiget();
      dispatch(reportlistapiSuccess(user));
   

    // AsyncStorage.setItem('auth_token',user.payload.token)
    //  navigate(NAVIGATION.EditUserDetail);

  } catch (error) {
    // alert(error.message)
    if(error.message=='Unauthorized')
    {
     dispatch(logout());
    }
    dispatch(reportlistapiError(error.message));
  }
};


export const Creatervideosapi = (datareq) => async (dispatch) => {

  try {
    // AsyncStorage.getItem('auth_token').then(async (data) => {
    //   // console.log(data)
    //   HttpClient.setAuthorization(data);
    // })
      const user = await UserController.Creatervideos(datareq);
      // console.log('fdf',user)

      // for ( var index=0; index<user.length; index++ ) {

      //   console.log(user[index].url)
      //    user[index]['dfd']='fdfd'

      //          createThumbnail({
      //           url: user[index].url
      //         })
      //              .then( (response) => {
      //               console.log(response.path)
      //              if(response.path)
      //              {
      //               user[index]['dfd']=response.path
      //              }
      //              else
      //              {
      //               user[index]['dfd']=''

      //              }
      //         })

      // if ( user[index] == "Valid" ) {
      // tempData.push( 'dsd' );
      //}
      //}
      //user = tempData;


      //  let dfgdf= user.map((item, i) => {
      //     console.log('test');
      //     item['thumbimage']='xcfdf'
      //     // createThumbnail({
      //     //   url: item.url
      //     // })
      //     //      .then((response) => {
      //     //      if(response.path)
      //     //      {
      //     //       user[i]['thumbimage']=response.path
      //     //      }
      //     //      else
      //     //      {
      //     //       user[i]['thumbimage']=''

      //     //      }
      //     // })
      //   })

      //   user.map(function(e,index){
      //     createThumbnail({
      //       url: e.url
      //     })
      //          .then((response) => {
      //         //  if(response.path)
      //         //  {
      //         //   user['thumbimage']=response.path
      //         //  }
      //         //  else
      //         //  {
      //         //   user['thumbimage']=''

      //         //  }
      //          return Object.assign({thumbimage:'dff'},e);
      //     })

      // });

      // console.log('new',user)

      dispatch(CreatervideosSuccess(user));
   

    // AsyncStorage.setItem('auth_token',user.payload.token)
    //  navigate(NAVIGATION.EditUserDetail);

  } catch (error) {
    // alert(error.message)
    if(error.message=='Unauthorized')
    {
     dispatch(logout());
    }
    dispatch(CreatervideosError(error.message));
  }
};

export const favvideosapi = () => async (dispatch) => {

  try {
    // AsyncStorage.getItem('auth_token').then(async (data) => {
    // })
      // console.log(data)
      //HttpClient.setAuthorization(data);
      const user = await UserController.favvideos();
      dispatch(favvideosSuccess(user));
    

    // AsyncStorage.setItem('auth_token',user.payload.token)
    //  navigate(NAVIGATION.EditUserDetail);

  } catch (error) {
    if(error.message=='Unauthorized')
    {
     dispatch(logout());
    }
    // alert(error.message)
    // dispatch(favvideosError(error.message));
  }
};



// export const allshifts = () => async (dispatch) => {

//   try {
//     AsyncStorage.getItem('auth_token').then(async (data) => {
//       HttpClient.setAuthorization(data);
//       const user = await UserController.allshiftsapi(data);

//       dispatch(allshiftSuccess(user));
//     })

//     // AsyncStorage.setItem('auth_token',user.payload.token)
//     //  navigate(NAVIGATION.EditUserDetail);

//   } catch (error) {
//     //  alert(error.message)
//     dispatch(allshiftError(error.message));
//   }
// };

// export const shiftsdetail = (id) => async (dispatch) => {

//   try {
//     AsyncStorage.getItem('auth_token').then(async (data) => {
//       HttpClient.setAuthorization(data);
//       const user = await UserController.shiftsdetail(id);
//       dispatch(shiftdetailSuccess(user));
//     })

//     // AsyncStorage.setItem('auth_token',user.payload.token)
//     //  navigate(NAVIGATION.EditUserDetail);

//   } catch (error) {
//     //  alert(error.message)
//     dispatch(shiftdetailError(error.message));
//   }
// };

// export const shiftsdelete = (id) => async (dispatch) => {

//   try {
//     AsyncStorage.getItem('auth_token').then(async (data) => {
//       HttpClient.setAuthorization(data);
//       const user = await UserController.shiftsdeleteapi(id);
//       //  dispatch(shiftdetailSuccess(user));
//     })

//     // AsyncStorage.setItem('auth_token',user.payload.token)
//     //  navigate(NAVIGATION.EditUserDetail);

//   } catch (error) {
//     //  alert(error.message)
//     // dispatch(shiftdetailError(error.message));
//   }
// };
export const getRoles = (data) => async (dispatch) => {
  dispatch(getRolesRequest());
  console.log("data", data);
  try {
    const user = await UserController.getRoles(data);
    dispatch(getRolesSuccess(user));
  } catch (error) {
    dispatch(getRolesError(error.message));
  }
};

export const getnotification = (data) => async (dispatch) => {
  dispatch(getnotificationRequest());

  try {
    AsyncStorage.getItem('auth_token').then(async (data22) => {
      console.log("databbb", data22);
      HttpClient.setAuthorization(data22);
      const user = await UserController.getnotification(data);
      dispatch(getnotificationSuccess(user));
    })
  } catch (error) {
    dispatch(getnotificationError(error.message));
  }
};
export const aboutus = (data) => async (dispatch) => {
  // dispatch(aboutusRequest());
  try {
    const user = await UserController.aboutus();
    dispatch(aboutusSuccess(user));
  } catch (error) {
    dispatch(aboutusError(error.message));
  }
};

export const faq = (data) => async (dispatch) => {
  // dispatch(aboutusRequest());
  try {
    const user = await UserController.faq();
    dispatch(faqSuccess(user));
  } catch (error) {
    dispatch(faqError(error.message));
  }
};

export const imageuploadServer = (data) => async (dispatch) => {
  dispatch(imageUploadRequest());
  // console.log("uploaded image", data);
  try {
    const user = await UserController.uploadImage(data);
    //alert(user)
    dispatch(imageUploadSuccess(user));
  } catch (error) {
    dispatch(imageUploadError(error.message));
  }
};

export const logout = () => async (dispatch) => {
  try {
    await UserController.logout();
    AsyncStorage.removeItem('auth_token');
  } finally {
    dispatch(clearStore());
    AsyncStorage.removeItem('auth_token');
   // navigate(NAVIGATION.login);
  }
};
