export const COLOR = {
  AppColor: '#08DDFD',
  HeadingColor: '#43686A',
  Black: '#2C2B31',
  Blue: '#1F39FF',
  lightBlue: '#87BDF6',
  white: '#F8E6D2',
  red: '#BF0A00',
  lightBlueD: '#BCE0FD',
  darkRed: '#FF001D',
};
