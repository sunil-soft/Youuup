import { TYPES } from "../actions/UserActions";

export const userReducer = (state = {}, { payload, type }) => {
  switch (type) {
    case TYPES.LOGIN_SUCCESS:
      // return { ...state, ...payload.user };
      return { ...state, userinfo: payload.user };
    case TYPES.LOGIN_ERROR:
      // alert(JSON.stringify(payload.error.payload.is_admin_approved))
      return { ...state, loginerror: payload.error.payload };
    case TYPES.REGISTER_SUCCESS:
      return { ...state, REGISTERSUCCESS: payload.user };
    case TYPES.OTP_SUCCESS:
      return { ...state, userinfo: payload.user };
    case TYPES.Creatervideos_SUCCESS:
      return { ...state, creatervideos: payload.user };
    case TYPES.Createrprofile_SUCCESS:
      return { ...state, creator_profile: payload.user };
    case TYPES.followerslist_SUCCESS:
      return { ...state, followerslist: payload.user };
    case TYPES.Aboutus_SUCCESS:
      return { ...state, Aboutus: payload.user };
    case TYPES.faq_SUCCESS:
      return { ...state, Faq: payload.user };
    case TYPES.blocklist_SUCCESS:
      return { ...state, blockUserList: payload.user };
    case TYPES.reportlist_SUCCESS:
      return { ...state, ReportList: payload.user };
    case TYPES.Myprofile_SUCCESS:
      return { ...state, profileinfo: payload.user };

    case TYPES.favvideos_SUCCESS:
      return { ...state, favvideos: payload.user };

    case TYPES.getnotification_SUCCESS:
      return { ...state, notificationlist: payload.user };

    case TYPES.Allshift_SUCCESS:
      return { ...state, Allshiftlist: payload.user };

    //  case TYPES.shiftdetail_SUCCESS:
    //  return { ...state,shiftdetail: payload.user };

    // case TYPES.GET_ROLES_SUCCESS:
    //   return { ...state, ...payload.user };
    case TYPES.PLACE_NAME_SUCCESS:
      return { ...state, ...payload.user };

    case TYPES.IMAGE_UPLOAD_SUCCESS:
      //  alert('df'+JSON.stringify(payload))
      return { ...state, ...payload.user };
    case TYPES.shift_SUCCESS:
      return { ...state, shiftSUCCESS: payload.user };
    case TYPES.CLEAR_STORE:
      return {};
    default:
      return state;
  }
};
